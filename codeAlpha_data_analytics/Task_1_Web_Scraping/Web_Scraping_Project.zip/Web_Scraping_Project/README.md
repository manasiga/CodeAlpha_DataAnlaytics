# Product Data Collection and Web Scraping System

A beginner-friendly Python project that collects real book data from the practice website
**[Books to Scrape](https://books.toscrape.com/)**, cleans it with **Pandas**, saves it as a **CSV** file,
prints statistics and draws charts with **Matplotlib**.

---

## 1. What this project does

| Step | What happens | File |
|------|--------------|------|
| 1 | Connects to the website and downloads every catalogue page (50 pages) | `scraper.py` |
| 2 | Extracts title, price, rating and availability for every book (1,000 books) | `scraper.py` |
| 3 | Puts the data in a Pandas DataFrame, converts text to numbers, handles missing values, removes duplicates | `data_cleaning.py` |
| 4 | Saves `output/books_data.csv` and `output/summary_report.txt` | `data_cleaning.py` |
| 5 | Creates 4 charts in `output/charts/` | `visualization.py` |
| ★ | Runs all of the above in the correct order | `main.py` |

---

## 2. Project structure

```
Web_Scraping_Project/
│
├── scraper.py            # downloads pages + extracts raw book data
├── data_cleaning.py      # cleans data, removes duplicates, saves CSV, statistics
├── visualization.py      # draws and saves charts
├── main.py               # the "start button" - runs everything
├── requirements.txt      # list of libraries to install
├── README.md             # this guide
└── output/
    ├── books_data.csv          # final clean dataset
    ├── summary_report.txt      # statistical summary
    └── charts/
        ├── price_distribution.png
        ├── rating_distribution.png
        ├── avg_price_by_rating.png
        └── price_by_rating_boxplot.png
```

> The `output` folder already contains results from a real run. Running `main.py` again
> overwrites them with freshly scraped data.

---

## 3. Step-by-step: run it in VS Code

### Step 1 – Install the tools (one time only)
1. Install **Python 3.13** from <https://www.python.org/downloads/>.
   On Windows, tick **"Add python.exe to PATH"** during installation.
2. Install **VS Code** from <https://code.visualstudio.com/>.
3. Open VS Code → click the **Extensions** icon (left bar) → search **"Python"** (by Microsoft) → **Install**.

### Step 2 – Open the project
1. Unzip the project somewhere easy, e.g. your Desktop.
2. In VS Code: **File → Open Folder…** → choose `Web_Scraping_Project`.
3. Open a terminal: **Terminal → New Terminal** (or press <kbd>Ctrl</kbd> + <kbd>`</kbd>).

### Step 3 – Create a virtual environment (recommended)
A virtual environment keeps this project's libraries separate from the rest of your computer.

**Windows**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS / Linux**
```bash
python3 -m venv venv
source venv/bin/activate
```

You will see `(venv)` at the start of the terminal line when it is active.
If VS Code asks *"We noticed a new environment… select it for the workspace?"* click **Yes**.

> Windows tip: if you get *"running scripts is disabled"*, run
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once in PowerShell, then try again.

### Step 4 – Install the libraries
```bash
pip install -r requirements.txt
```

### Step 5 – Run the project
Quick test (first 2 pages, about 5 seconds):
```bash
python main.py --pages 2
```

Full run (all 50 pages / 1,000 books, about 1–2 minutes because we wait 1 second between pages):
```bash
python main.py
```

Other options:
```bash
python main.py --delay 2     # wait 2 seconds between pages (even more polite)
python scraper.py            # test only the scraper on page 1
```

### Step 6 – See the results
In the VS Code Explorer, open the `output` folder:
- `books_data.csv` – click it to view (install the **"Rainbow CSV"** extension for colours), or open it in Excel.
- `summary_report.txt` – the statistics.
- `charts/*.png` – click any image to view the chart.

---

## 4. How the project works (beginner explanation)

### 4.1 The big idea
A web page is just a text file written in **HTML**. Your browser turns that HTML into
something pretty. A web scraper downloads the same HTML and **reads it with code** to pick out
the information you want.

On Books to Scrape every book looks like this in HTML:

```html
<article class="product_pod">
  <p class="star-rating Three"></p>
  <h3><a href="a-light-in-the-attic_1000/index.html" title="A Light in the Attic">A Light in the ...</a></h3>
  <div class="product_price">
    <p class="price_color">£51.77</p>
    <p class="instock availability">In stock</p>
  </div>
</article>
```

So the recipe is: *find every `article.product_pod`, then inside each one read the title,
price, rating and availability.*

> Tip: on any website, right-click an element → **Inspect** to see its HTML. That is how
> you discover which tags and classes to target.

### 4.2 `scraper.py` – collecting the data
| Function | What it does |
|----------|--------------|
| `is_scraping_allowed()` | Reads `robots.txt` (the site's rules for bots). This site has none, which means no restrictions. |
| `fetch_page()` | Downloads one page with **Requests**. Uses a timeout, retries up to 3 times, and catches timeouts, connection errors and HTTP errors so the program never crashes. |
| `parse_book()` | Uses **BeautifulSoup** `select_one()` with CSS selectors to read each field. If something is missing it stores `None` instead of crashing. |
| `scrape_books()` | Starts at page 1, scrapes it, finds the **"next"** button, follows it, waits 1 second, and repeats until there is no "next" button. |

Key ideas:
- `requests.get(url)` → downloads the page.
- `BeautifulSoup(html, "html.parser")` → turns HTML text into an object you can search.
- `soup.select("article.product_pod")` → finds all book cards (CSS selector: tag `article` with class `product_pod`).
- The rating is not text – it is hidden in the class name (`star-rating Three`), so we read the class list.
- The title on screen is shortened, so we read the full title from the link's `title` attribute.

### 4.3 `data_cleaning.py` – making the data usable
Raw data is text. You cannot calculate an average of `"£51.77"`. This file:
1. **Creates a DataFrame** – a table, like an Excel sheet, in Python.
2. **Price** `"£51.77"` → `51.77` (removes everything that is not a digit or dot, then `pd.to_numeric`).
3. **Rating** `"Three"` → `3` (using a dictionary `{"One": 1, ... "Five": 5}`).
4. **Availability** – trims spaces and adds a `True/False` `in_stock` column.
5. **Missing values** – drops rows with no title, labels missing availability as `"Unknown"`,
   and leaves missing numbers as empty (NaN) instead of inventing values.
6. **Duplicates** – removes rows with the same product URL or identical details.
7. **Saves the CSV** and builds a **statistical summary** using `describe()`, `value_counts()`
   and `groupby()`.

### 4.4 `visualization.py` – drawing charts
Uses Matplotlib to create and save 4 PNG charts:
- **Price distribution (histogram)** – how many books in each price range, with the average marked.
- **Rating distribution (bar chart)** – how many books have 1–5 stars.
- **Average price by rating (bar chart)** – do better-rated books cost more?
- **Price spread by rating (box plot)** – median, middle 50% and min/max price for each rating.

### 4.5 `main.py` – the conductor
It imports the functions from the other three files and calls them in order:
`scrape → DataFrame → clean → save CSV → summary → charts`.
It also reads options like `--pages 3` using `argparse`.

### 4.6 `if __name__ == "__main__":`
You will see this line at the bottom of `main.py` and `scraper.py`. It means
*"run this code only when this file is run directly"*. When `main.py` **imports** `scraper.py`,
the test code at the bottom of `scraper.py` is skipped.

---

## 5. Results from a real run

Real scrape of all 50 pages:

- **1,000** unique books collected, **0** duplicates, **0** missing values
- Prices range from **£10.00** to **£59.99**, average **£35.07**, median **£35.98**
- Average rating **2.92** stars; 1-star is the most common rating (226 books)
- Average price is almost the same for every rating (£34.56 – £36.09) → on this site,
  **rating does not predict price**
- All 1,000 books show **"In stock"** on the catalogue pages

CSV columns:

| Column | Meaning |
|--------|---------|
| `title` | Full book title |
| `price_gbp` | Price as a number (British pounds) |
| `rating_stars` | Rating as a number 1–5 |
| `rating_text` | Original rating word from the site |
| `availability` | Availability text, e.g. "In stock" |
| `in_stock` | True / False |
| `page_number` | Catalogue page the book was found on |
| `product_url` | Link to the book's page |

---

## 6. Ethical scraping practices used
- Only scrapes **books.toscrape.com**, a site made for scraping practice.
- Checks **robots.txt** before starting.
- Sends an honest **User-Agent** that says this is an educational project.
- Waits **1 second between pages** (`--delay` to change it).
- Uses **timeouts** and a small number of **retries** with back-off.
- Uses no paid APIs and no fake data – everything comes from the live site.

When you scrape other websites later: read their Terms of Service, respect robots.txt,
never scrape personal data, and prefer an official API if one exists.

---

## 7. Troubleshooting

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError: No module named 'requests'` | Activate the virtual environment, then `pip install -r requirements.txt`. In VS Code, choose the `venv` interpreter (<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd> → *Python: Select Interpreter*). |
| `'python' is not recognized` | Reinstall Python with "Add to PATH" ticked, or try `py main.py` on Windows. |
| Connection / timeout warnings | Check your internet connection and run again. |
| Prices show `Â£` | Already handled in `fetch_page()` by forcing UTF-8. |
| Stop the program early | Press <kbd>Ctrl</kbd> + <kbd>C</kbd>. |

---

## 8. Ideas to practise next
1. Open each book's page and also scrape its **category**, **description** and **exact stock count**.
2. Save the data to an **Excel** file with `df.to_excel()`.
3. Add a chart of the **10 most expensive books**.
4. Scrape <https://quotes.toscrape.com/> using the same structure.
