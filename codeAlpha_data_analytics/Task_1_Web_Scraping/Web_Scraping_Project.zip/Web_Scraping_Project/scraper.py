"""
scraper.py
==========
PURPOSE:
    This file is responsible for ONE job: downloading web pages from
    https://books.toscrape.com/ and pulling out (extracting) the raw book
    information from the HTML.

    It does NOT clean the data or draw charts. Keeping each file focused on a
    single job makes the project easier to read, test and fix.

WHAT IT EXTRACTS FOR EVERY BOOK:
    - title          (e.g. "A Light in the Attic")
    - price          (raw text, e.g. "£51.77")
    - rating         (raw word, e.g. "Three")
    - availability   (raw text, e.g. "In stock")
    - product_url    (link to the book's own page)
    - page_number    (which catalogue page the book was found on)

ETHICAL SCRAPING PRACTICES USED HERE:
    1. We identify ourselves with a clear User-Agent header.
    2. We check robots.txt before scraping.
    3. We wait (sleep) between requests so we never overload the server.
    4. We use timeouts and a limited number of retries.
    5. We only scrape a site that is BUILT for scraping practice.
"""

# --------------------------------------------------------------------------
# 1. IMPORTS
# --------------------------------------------------------------------------
import time                                  # used to pause between requests
from urllib.parse import urljoin             # safely joins relative links
from urllib.robotparser import RobotFileParser  # reads robots.txt rules

import requests                              # downloads web pages
from bs4 import BeautifulSoup                # parses (reads) HTML


# --------------------------------------------------------------------------
# 2. SETTINGS (constants)
#    Constants are written in UPPER_CASE so they are easy to spot and change.
# --------------------------------------------------------------------------
BASE_URL = "https://books.toscrape.com/"
FIRST_PAGE_URL = urljoin(BASE_URL, "catalogue/page-1.html")

# A polite, honest User-Agent tells the website who is visiting.
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; BeginnerBookScraper/1.0; "
        "educational project for learning web scraping)"
    )
}

REQUEST_TIMEOUT = 15     # seconds to wait for the server before giving up
MAX_RETRIES = 3          # how many times to retry a page that fails
DEFAULT_DELAY = 1.0      # seconds to wait between page requests (politeness)


# --------------------------------------------------------------------------
# 3. ROBOTS.TXT CHECK
# --------------------------------------------------------------------------
def is_scraping_allowed(url: str) -> bool:
    """
    Check the website's robots.txt file to see if we are allowed to visit `url`.

    robots.txt is a plain-text file where website owners list the pages
    automated programs may or may not visit. If the file does not exist
    (HTTP 404), the standard convention is that everything is allowed.
    """
    robots_url = urljoin(BASE_URL, "robots.txt")
    try:
        response = requests.get(robots_url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
    except requests.RequestException as error:
        # If we cannot even reach robots.txt, we warn but continue,
        # because the main requests will fail anyway if the site is down.
        print(f"[WARNING] Could not read robots.txt ({error}). Continuing carefully.")
        return True

    if response.status_code == 404:
        print("[INFO] No robots.txt found (404) -> no restrictions are published.")
        return True

    parser = RobotFileParser()
    parser.parse(response.text.splitlines())
    allowed = parser.can_fetch(HEADERS["User-Agent"], url)
    print(f"[INFO] robots.txt says scraping is {'ALLOWED' if allowed else 'NOT allowed'}.")
    return allowed


# --------------------------------------------------------------------------
# 4. DOWNLOADING A PAGE (with error handling + retries)
# --------------------------------------------------------------------------
def fetch_page(url: str, session: requests.Session) -> BeautifulSoup | None:
    """
    Download one web page and return it as a BeautifulSoup object.

    Returns None if the page could not be downloaded after MAX_RETRIES tries.
    This means the rest of the program can keep running even if one page fails.
    """
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = session.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)

            # 404 = page does not exist. Retrying will not help, so stop here.
            if response.status_code == 404:
                print(f"[INFO] Page not found (404): {url}")
                return None

            # raise_for_status() turns other bad codes (500, 503...) into errors.
            response.raise_for_status()

            # This site sends UTF-8, but does not always say so in its headers.
            # Without this line the "£" symbol can turn into "Â£".
            response.encoding = "utf-8"

            # "html.parser" is Python's built-in parser (nothing extra to install).
            return BeautifulSoup(response.text, "html.parser")

        except requests.Timeout:
            print(f"[WARNING] Timeout on attempt {attempt}/{MAX_RETRIES}: {url}")
        except requests.ConnectionError:
            print(f"[WARNING] Connection problem on attempt {attempt}/{MAX_RETRIES}: {url}")
        except requests.HTTPError as error:
            print(f"[WARNING] HTTP error on attempt {attempt}/{MAX_RETRIES}: {error}")

        # Wait a little longer after each failure ("back-off") before retrying.
        time.sleep(2 * attempt)

    print(f"[ERROR] Giving up on {url} after {MAX_RETRIES} attempts.")
    return None


# --------------------------------------------------------------------------
# 5. EXTRACTING DATA FROM ONE BOOK
# --------------------------------------------------------------------------
def parse_book(book_tag, page_url: str, page_number: int) -> dict:
    """
    Pull the details out of ONE book card (<article class="product_pod">).

    Every lookup is protected: if something is missing on the page we store
    None instead of crashing. data_cleaning.py deals with those None values.
    """
    # --- Title -------------------------------------------------------------
    # The visible title is often shortened ("A Light in the ..."), but the
    # full title is stored in the link's "title" attribute.
    link_tag = book_tag.select_one("h3 a")
    title = link_tag.get("title") if link_tag else None

    # --- Product URL -------------------------------------------------------
    # Links are relative (e.g. "a-light-in-the-attic_1000/index.html"),
    # so we join them with the page URL to make a full, clickable link.
    product_url = urljoin(page_url, link_tag["href"]) if link_tag and link_tag.get("href") else None

    # --- Price -------------------------------------------------------------
    price_tag = book_tag.select_one("p.price_color")
    price = price_tag.get_text(strip=True) if price_tag else None

    # --- Rating ------------------------------------------------------------
    # The rating is hidden in the CSS class, e.g. <p class="star-rating Three">
    rating = None
    rating_tag = book_tag.select_one("p.star-rating")
    if rating_tag:
        # classes looks like ["star-rating", "Three"]; we want the word that is
        # NOT "star-rating".
        words = [c for c in rating_tag.get("class", []) if c != "star-rating"]
        rating = words[0] if words else None

    # --- Availability ------------------------------------------------------
    availability_tag = book_tag.select_one("p.availability")
    availability = availability_tag.get_text(strip=True) if availability_tag else None

    return {
        "title": title,
        "price": price,
        "rating": rating,
        "availability": availability,
        "product_url": product_url,
        "page_number": page_number,
    }


# --------------------------------------------------------------------------
# 6. SCRAPING MANY PAGES AUTOMATICALLY
# --------------------------------------------------------------------------
def scrape_books(max_pages: int | None = None, delay: float = DEFAULT_DELAY) -> list[dict]:
    """
    Scrape the catalogue page by page and return a list of book dictionaries.

    How pagination works:
        Each page has a "next" button. We keep following it until there is no
        "next" button (last page) or until we reach `max_pages`.

    Parameters:
        max_pages: stop after this many pages (None = scrape every page).
        delay:     seconds to wait between pages (be polite to the server).
    """
    if not is_scraping_allowed(FIRST_PAGE_URL):
        print("[STOP] The website does not allow scraping this page. Exiting.")
        return []

    all_books: list[dict] = []
    current_url: str | None = FIRST_PAGE_URL
    page_number = 1

    # A Session re-uses the same network connection -> faster and lighter
    # for the server than opening a new connection for every page.
    with requests.Session() as session:
        while current_url:
            # Stop if the user asked for a limited number of pages.
            if max_pages is not None and page_number > max_pages:
                break

            print(f"[SCRAPING] Page {page_number}: {current_url}")
            soup = fetch_page(current_url, session)
            if soup is None:
                print("[INFO] Stopping because the page could not be loaded.")
                break

            # Every book on the page lives inside <article class="product_pod">
            book_tags = soup.select("article.product_pod")
            if not book_tags:
                print("[WARNING] No books found on this page. Stopping.")
                break

            for book_tag in book_tags:
                all_books.append(parse_book(book_tag, current_url, page_number))

            print(f"           -> found {len(book_tags)} books (total so far: {len(all_books)})")

            # Find the "next" button. On the last page it does not exist.
            next_link = soup.select_one("li.next a")
            current_url = urljoin(current_url, next_link["href"]) if next_link else None
            page_number += 1

            # Be polite: wait before asking for the next page.
            if current_url:
                time.sleep(delay)

    print(f"[DONE] Scraping finished. Collected {len(all_books)} raw records.")
    return all_books


# --------------------------------------------------------------------------
# 7. QUICK SELF-TEST
#    This block only runs when you execute `python scraper.py` directly.
#    It is skipped when main.py imports this file.
# --------------------------------------------------------------------------
if __name__ == "__main__":
    sample = scrape_books(max_pages=1)
    for book in sample[:5]:
        print(book)
