"""
main.py
=======
PURPOSE:
    This is the START BUTTON of the project. It does not scrape, clean or plot
    anything itself - it calls the other files in the right order:

        scraper.py        ->  collect raw data from the website
        data_cleaning.py  ->  clean it, remove duplicates, save CSV, summarise
        visualization.py  ->  draw and save charts

HOW TO RUN (from the project folder):
    python main.py                 # scrape ALL pages (50 pages, 1000 books)
    python main.py --pages 3       # scrape only the first 3 pages (quick test)
    python main.py --delay 2       # wait 2 seconds between pages
"""

# --------------------------------------------------------------------------
# 1. IMPORTS
# --------------------------------------------------------------------------
import argparse          # reads options typed in the terminal (e.g. --pages 3)
import sys
from pathlib import Path

# Our own modules (the other .py files in this folder)
from scraper import scrape_books, DEFAULT_DELAY
from data_cleaning import create_dataframe, clean_data, save_to_csv, generate_summary
from visualization import create_all_charts

# All results go into the "output" folder next to this file, no matter
# which folder you run the command from.
PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_DIR / "output"
CSV_PATH = OUTPUT_DIR / "books_data.csv"
SUMMARY_PATH = OUTPUT_DIR / "summary_report.txt"
CHARTS_DIR = OUTPUT_DIR / "charts"


# --------------------------------------------------------------------------
# 2. COMMAND-LINE OPTIONS
# --------------------------------------------------------------------------
def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Scrape books from books.toscrape.com")
    parser.add_argument("--pages", type=int, default=None,
                        help="How many catalogue pages to scrape (default: all)")
    parser.add_argument("--delay", type=float, default=DEFAULT_DELAY,
                        help=f"Seconds to wait between pages (default: {DEFAULT_DELAY})")
    return parser.parse_args()


# --------------------------------------------------------------------------
# 3. THE MAIN WORKFLOW
# --------------------------------------------------------------------------
def main() -> int:
    args = parse_arguments()

    print("\n=== STEP 1: SCRAPING THE WEBSITE ===")
    raw_records = scrape_books(max_pages=args.pages, delay=args.delay)
    if not raw_records:
        print("[STOP] No data was collected. Check your internet connection and try again.")
        return 1   # a non-zero number tells the terminal "something went wrong"

    print("\n=== STEP 2: CLEANING THE DATA ===")
    raw_df = create_dataframe(raw_records)
    clean_df = clean_data(raw_df)

    print("\n=== STEP 3: SAVING THE CSV FILE ===")
    save_to_csv(clean_df, CSV_PATH)
    print("\nFirst 5 rows of the clean dataset:")
    print(clean_df.head().to_string())

    print("\n=== STEP 4: STATISTICAL SUMMARY ===")
    summary = generate_summary(clean_df)
    print(summary)
    SUMMARY_PATH.write_text(summary, encoding="utf-8")
    print(f"[SAVED] Summary report written to: {SUMMARY_PATH}")

    print("\n=== STEP 5: CREATING CHARTS ===")
    create_all_charts(clean_df, CHARTS_DIR)

    print("\nAll done! Open the 'output' folder to see your CSV, report and charts.")
    return 0


# --------------------------------------------------------------------------
# 4. ENTRY POINT
#    This line means: "only run main() when this file is executed directly".
# --------------------------------------------------------------------------
if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        # Lets you stop the program with Ctrl + C without an ugly error.
        print("\n[STOPPED] Scraping cancelled by user.")
        sys.exit(130)
