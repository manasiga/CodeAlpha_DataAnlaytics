"""
visualization.py
================
PURPOSE:
    Turn the clean data into pictures (charts) so patterns are easy to see.
    Every chart is saved as a PNG image inside output/charts/.

CHARTS CREATED:
    1. price_distribution.png   - histogram: how many books fall in each price range
    2. rating_distribution.png  - bar chart: how many books have 1, 2, 3, 4, 5 stars
    3. avg_price_by_rating.png  - bar chart: average price for each star rating
    4. price_by_rating_boxplot.png - box plot: price spread for each star rating
"""

# --------------------------------------------------------------------------
# 1. IMPORTS
# --------------------------------------------------------------------------
from pathlib import Path

import matplotlib

# "Agg" is a backend that draws charts straight into image files without
# opening a window. This makes the script work everywhere (VS Code terminal,
# servers, etc.). Open the PNG files afterwards to view the charts.
matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402  (must come after matplotlib.use)
import pandas as pd               # noqa: E402

# One consistent colour for all charts keeps the report looking tidy.
MAIN_COLOR = "#2a7f62"
ACCENT_COLOR = "#e07a3f"


# --------------------------------------------------------------------------
# 2. HELPER: save a figure safely
# --------------------------------------------------------------------------
def _save_figure(fig, folder: Path, file_name: str) -> Path:
    """Save a Matplotlib figure, close it (frees memory) and return the path."""
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / file_name
    fig.tight_layout()                     # stop labels from overlapping
    fig.savefig(path, dpi=120)
    plt.close(fig)                         # important when creating many charts
    print(f"[CHART] Saved {path}")
    return path


# --------------------------------------------------------------------------
# 3. INDIVIDUAL CHARTS
# --------------------------------------------------------------------------
def plot_price_distribution(df: pd.DataFrame, folder: Path) -> Path:
    """Histogram of book prices."""
    fig, ax = plt.subplots(figsize=(9, 5))
    prices = df["price_gbp"].dropna()
    ax.hist(prices, bins=20, color=MAIN_COLOR, edgecolor="white")
    # A dashed line marks the average price.
    ax.axvline(prices.mean(), color=ACCENT_COLOR, linestyle="--", linewidth=2,
               label=f"Average: £{prices.mean():.2f}")
    ax.set_title("Distribution of Book Prices")
    ax.set_xlabel("Price (£)")
    ax.set_ylabel("Number of books")
    ax.legend()
    return _save_figure(fig, folder, "price_distribution.png")


def plot_rating_distribution(df: pd.DataFrame, folder: Path) -> Path:
    """Bar chart showing how many books received each star rating."""
    counts = df["rating_stars"].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(counts.index.astype(str), counts.values, color=MAIN_COLOR)
    ax.bar_label(bars)                     # write the number on top of each bar
    ax.set_title("Number of Books per Star Rating")
    ax.set_xlabel("Rating (stars)")
    ax.set_ylabel("Number of books")
    return _save_figure(fig, folder, "rating_distribution.png")


def plot_avg_price_by_rating(df: pd.DataFrame, folder: Path) -> Path:
    """Bar chart of the average price for each rating."""
    avg = df.groupby("rating_stars")["price_gbp"].mean().sort_index()
    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(avg.index.astype(str), avg.values, color=ACCENT_COLOR)
    ax.bar_label(bars, fmt="£%.2f")
    ax.set_title("Average Book Price by Star Rating")
    ax.set_xlabel("Rating (stars)")
    ax.set_ylabel("Average price (£)")
    return _save_figure(fig, folder, "avg_price_by_rating.png")


def plot_price_boxplot_by_rating(df: pd.DataFrame, folder: Path) -> Path:
    """Box plot: shows the median, spread and extremes of price per rating."""
    ratings = sorted(df["rating_stars"].dropna().unique())
    data = [df.loc[df["rating_stars"] == r, "price_gbp"].dropna() for r in ratings]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.boxplot(data, tick_labels=[str(r) for r in ratings], patch_artist=True,
               boxprops={"facecolor": MAIN_COLOR, "alpha": 0.6})
    ax.set_title("Price Spread by Star Rating")
    ax.set_xlabel("Rating (stars)")
    ax.set_ylabel("Price (£)")
    return _save_figure(fig, folder, "price_by_rating_boxplot.png")


# --------------------------------------------------------------------------
# 4. CREATE ALL CHARTS AT ONCE
# --------------------------------------------------------------------------
def create_all_charts(df: pd.DataFrame, output_folder: str | Path = "output/charts") -> list[Path]:
    """Create every chart. Errors in one chart do not stop the others."""
    folder = Path(output_folder)
    if df.empty:
        print("[CHART] No data to plot.")
        return []

    saved = []
    for chart_function in (
        plot_price_distribution,
        plot_rating_distribution,
        plot_avg_price_by_rating,
        plot_price_boxplot_by_rating,
    ):
        try:
            saved.append(chart_function(df, folder))
        except Exception as error:   # keep going even if one chart fails
            print(f"[CHART ERROR] {chart_function.__name__} failed: {error}")
    return saved
