"""
data_cleaning.py
================
PURPOSE:
    Raw scraped data is messy. Prices are text like "£51.77", ratings are words
    like "Three", and some values could be missing. This file turns that raw
    data into a clean, analysis-ready Pandas DataFrame, then saves it as CSV
    and produces statistical summaries.

STEPS PERFORMED (in order):
    1. Build a DataFrame from the list of dictionaries.
    2. Clean the text columns (strip extra spaces).
    3. Convert price text  -> number (float).
    4. Convert rating word -> number (1 to 5).
    5. Standardise availability and add a True/False "in_stock" column.
    6. Handle missing values.
    7. Remove duplicate records.
"""

# --------------------------------------------------------------------------
# 1. IMPORTS
# --------------------------------------------------------------------------
from pathlib import Path   # modern, cross-platform way to work with file paths

import pandas as pd        # the main data analysis library


# The website writes ratings as English words inside a CSS class.
# This dictionary "maps" each word to a number.
RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}


# --------------------------------------------------------------------------
# 2. CREATE THE DATAFRAME
# --------------------------------------------------------------------------
def create_dataframe(records: list[dict]) -> pd.DataFrame:
    """Turn a list of dictionaries (one per book) into a Pandas DataFrame."""
    df = pd.DataFrame(records)
    print(f"[CLEANING] Raw DataFrame created with {len(df)} rows and {len(df.columns)} columns.")
    return df


# --------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR INDIVIDUAL COLUMNS
# --------------------------------------------------------------------------
def clean_price_column(price_series: pd.Series) -> pd.Series:
    """
    Convert prices like "£51.77" into numbers like 51.77.

    - str.replace(...) removes every character that is NOT a digit or a dot.
    - pd.to_numeric(..., errors="coerce") turns anything that still is not a
      valid number into NaN (Not a Number) instead of crashing.
    """
    cleaned = price_series.astype("string").str.replace(r"[^0-9.]", "", regex=True)
    return pd.to_numeric(cleaned, errors="coerce")


def clean_rating_column(rating_series: pd.Series) -> pd.Series:
    """Convert rating words ("One"..."Five") into integers (1...5)."""
    # .map() replaces each word with its number. Unknown words become NaN.
    # "Int64" (capital I) is a Pandas integer type that ALLOWS missing values.
    return rating_series.map(RATING_MAP).astype("Int64")


def clean_availability_column(availability_series: pd.Series) -> pd.Series:
    """Tidy the availability text, e.g. '  In stock ' -> 'In stock'."""
    return (
        availability_series.astype("string")
        .str.strip()
        .str.replace(r"\s+", " ", regex=True)   # collapse repeated spaces
    )


# --------------------------------------------------------------------------
# 4. MAIN CLEANING PIPELINE
# --------------------------------------------------------------------------
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Run every cleaning step and return a NEW, clean DataFrame."""
    # Work on a copy so the original raw data stays untouched.
    df = df.copy()

    if df.empty:
        print("[CLEANING] DataFrame is empty - nothing to clean.")
        return df

    # ---- Step A: tidy the title text -------------------------------------
    df["title"] = df["title"].astype("string").str.strip()

    # ---- Step B: keep the raw price text, then create a numeric column ----
    df["price_gbp"] = clean_price_column(df["price"])

    # ---- Step C: numeric rating ------------------------------------------
    df["rating_stars"] = clean_rating_column(df["rating"])

    # ---- Step D: availability --------------------------------------------
    df["availability"] = clean_availability_column(df["availability"])
    df["in_stock"] = df["availability"].str.contains("In stock", case=False, na=False)

    # ---- Step E: handle missing values -----------------------------------
    print("[CLEANING] Missing values BEFORE handling:")
    print(df[["title", "price_gbp", "rating_stars", "availability"]].isna().sum().to_string())

    # A book with no title is useless -> drop that row.
    rows_before = len(df)
    df = df.dropna(subset=["title"])
    print(f"[CLEANING] Dropped {rows_before - len(df)} rows without a title.")

    # Missing availability -> label it clearly instead of leaving it blank.
    df["availability"] = df["availability"].fillna("Unknown")

    # We deliberately DO NOT invent prices or ratings. Missing numbers stay as
    # NaN so they are ignored by averages instead of distorting them.

    # ---- Step F: remove duplicates ---------------------------------------
    # Two rows with the same product URL are the exact same book.
    rows_before = len(df)
    df = df.drop_duplicates(subset=["product_url"], keep="first")
    # Also drop rows that are 100% identical in the important columns.
    df = df.drop_duplicates(subset=["title", "price_gbp", "rating_stars", "availability"])
    print(f"[CLEANING] Removed {rows_before - len(df)} duplicate rows.")

    # ---- Step G: final column order + tidy index -------------------------
    df = df[
        ["title", "price_gbp", "rating_stars", "rating", "availability",
         "in_stock", "page_number", "product_url"]
    ].rename(columns={"rating": "rating_text"})
    df = df.reset_index(drop=True)

    print(f"[CLEANING] Clean dataset has {len(df)} rows.")
    return df


# --------------------------------------------------------------------------
# 5. SAVE TO CSV
# --------------------------------------------------------------------------
def save_to_csv(df: pd.DataFrame, file_path: str | Path) -> Path:
    """Save the DataFrame to a CSV file (creates the folder if needed)."""
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)   # make "output/" folder
    # utf-8-sig adds a small marker so Excel shows special characters correctly.
    df.to_csv(file_path, index=False, encoding="utf-8-sig")
    print(f"[SAVED] CSV file written to: {file_path.resolve()}")
    return file_path


# --------------------------------------------------------------------------
# 6. STATISTICAL SUMMARY
# --------------------------------------------------------------------------
def generate_summary(df: pd.DataFrame) -> str:
    """
    Build a human-readable text report with basic statistics.
    Returns the report as a string (main.py prints it and saves it to a file).
    """
    if df.empty:
        return "No data available to summarise."

    lines = []
    lines.append("=" * 60)
    lines.append("BOOKS TO SCRAPE - STATISTICAL SUMMARY")
    lines.append("=" * 60)
    lines.append(f"Total unique books : {len(df)}")
    lines.append(f"Books in stock     : {int(df['in_stock'].sum())}")
    lines.append("")

    # describe() gives count, mean, std, min, quartiles and max in one call.
    lines.append("PRICE STATISTICS (GBP)")
    lines.append("-" * 60)
    lines.append(df["price_gbp"].describe().round(2).to_string())
    lines.append("")

    lines.append("RATING STATISTICS (1-5 stars)")
    lines.append("-" * 60)
    lines.append(df["rating_stars"].astype("float").describe().round(2).to_string())
    lines.append("")

    lines.append("NUMBER OF BOOKS PER RATING")
    lines.append("-" * 60)
    lines.append(df["rating_stars"].value_counts().sort_index().to_string())
    lines.append("")

    # groupby() splits the data by rating, then we calculate stats per group.
    lines.append("PRICE BY RATING")
    lines.append("-" * 60)
    by_rating = df.groupby("rating_stars")["price_gbp"].agg(["count", "mean", "min", "max"]).round(2)
    lines.append(by_rating.to_string())
    lines.append("")

    lines.append("TOP 5 MOST EXPENSIVE BOOKS")
    lines.append("-" * 60)
    lines.append(df.nlargest(5, "price_gbp")[["title", "price_gbp", "rating_stars"]].to_string(index=False))
    lines.append("")

    lines.append("TOP 5 CHEAPEST BOOKS")
    lines.append("-" * 60)
    lines.append(df.nsmallest(5, "price_gbp")[["title", "price_gbp", "rating_stars"]].to_string(index=False))
    lines.append("")

    lines.append("AVAILABILITY")
    lines.append("-" * 60)
    lines.append(df["availability"].value_counts().to_string())
    lines.append("=" * 60)

    return "\n".join(lines)
