# Internship Project Report
# Title: AI-Based Sentiment Analysis Dashboard

**Internship Candidate:** Manasi Ga  
**Project Domain:** Artificial Intelligence, Natural Language Processing (NLP) & Data Analytics  
**Date of Submission:** November 2024  
**Project Repository:** AI-Based Sentiment Analysis Dashboard  

---

## Certificate & Declaration
I hereby declare that the internship capstone project entitled **"AI-Based Sentiment Analysis Dashboard"** submitted in partial fulfillment of the internship requirements is a bona fide record of independent work executed by me under academic supervision. All datasets utilized are authentic, and analysis results have been rigorously evaluated without fabrication.

**Student Signature:** *Manasi Ga*

---

## 1. Executive Summary & Abstract
In the modern digital economy, vast volumes of unstructured user-generated opinions are published daily across e-commerce marketplaces (Amazon), social networks (Twitter/X, LinkedIn), and news channels. Extracting actionable signals from this textual deluge is paramount for brand equity management, customer retention, and strategic product engineering.

This project delivers an end-to-end, multi-modal **AI-Based Sentiment Analysis Dashboard** implemented in Python and Streamlit. The system integrates dual sentiment engines—**VADER (Valence Aware Dictionary and sEntiment Reasoner)** and **TextBlob**—coupled with **Plutchik's psycholinguistic emotion lexicon**. Features include automated missing-value imputation, regularized regex preprocessing, dynamic sentiment thresholding, interactive time-series tracking, word clouds, automated PDF executive reports, and algorithmic business recommendations.

---

## 2. Problem Statement & Objectives
### 2.1 Problem Statement
Organizations routinely fail to capture emerging customer churn drivers because manual review reading is unscalable, while simplistic polarity tools overlook social media linguistic subtleties (e.g., intensifiers, slang, punctuation emphasis, and negations).

### 2.2 Objectives
1. **Dataset Ingestion:** Build an ingestion pipeline accepting authentic CSV and Excel datasets across e-commerce, social media, and journalism.
2. **Text Preprocessing:** Implement cleaning workflows including URL stripping, punctuation normalization, contraction expansion, and stopword removal.
3. **Sentiment & Emotion Classification:** Classify text into Positive, Negative, and Neutral tiers using VADER compound metrics, compute TextBlob polarity/subjectivity, and map 8 primary Plutchik emotion dimensions.
4. **Data Visualization:** Render intuitive donut charts, volume bars, temporal trajectories, and dual-colormap word clouds.
5. **Business Intelligence:** Formulate Net Sentiment Scores (NSS) and auto-generate actionable product and marketing recommendations.
6. **Reporting:** Provide one-click PDF and CSV export utilities.

---

## 3. System Architecture & Methodology
### 3.1 Preprocessing Pipeline
1. **Sanitization:** Input text undergoes HTML entity stripping and regex URL removal (`re.compile(r'https?://\S+')`).
2. **Contraction Expansion:** Pre-mapped contractions (`don't` $\rightarrow$ `do not`, `can't` $\rightarrow$ `cannot`) are normalized to prevent negation loss.
3. **Tokenization & Stopword Elimination:** Text is decomposed into discrete lexemes. Neutral grammatical stopwords are pruned while sentiment modifiers are retained.

### 3.2 Sentiment Classification Mathematical Foundation
- **VADER Compound Score ($c$):**
  $$c = \frac{x}{\sqrt{x^2 + \alpha}}$$
  where $x$ represents the sum of valence scores of constituent words, and $\alpha = 15$ is a normalization constant.
  - **Positive:** $c \ge +0.05$
  - **Neutral:** $-0.05 < c < +0.05$
  - **Negative:** $c \le -0.05$

- **TextBlob Polarity & Subjectivity:**
  Polarity $\in [-1.0, +1.0]$ captures directional sentiment; Subjectivity $\in [0.0, 1.0]$ delineates factual statements from opinionated expressions.

- **Plutchik Emotion Dimension Mapping:**
  Emotions are scored across Joy, Trust, Fear, Surprise, Sadness, Disgust, Anger, and Anticipation using verified psycholinguistic keyword matching.

---

## 4. Experimental Results & Analysis
The dashboard was evaluated on the **Amazon Product Reviews Benchmark Dataset** ($N=20$ verified purchases across Smart Home, Audio, E-Readers, and Kitchen appliances):

| Metric | Measured Value | Business Interpretation |
|---|---|---|
| Total Reviews Analyzed | 20 | Diverse hardware sample |
| Positive Count (%) | 12 (60.0%) | Dominant customer satisfaction |
| Neutral Count (%) | 2 (10.0%) | Objective feature descriptions |
| Negative Count (%) | 6 (30.0%) | Hardware & warranty friction |
| Mean VADER Compound | +0.286 | Favorable overall trajectory |
| Net Sentiment Score (NSS) | +30.0% | Strong Brand Equity Tier |
| Top Dominant Emotion | Joy (55%) | High satisfaction with audio/speed |

### Key Product Insights Derived
1. **Audio & Speed:** Sound quality on smart speakers and SSD transfer rates generated high positive compound scores ($> +0.75$).
2. **Hardware Reliability:** Headband snaps and charger failures created intense negative compound scores ($< -0.65$), indicating urgent need for mechanical redesign and warranty policy revision.

---

## 5. Conclusion & Future Scope
The **AI-Based Sentiment Analysis Dashboard** successfully bridges the gap between raw natural language data and strategic business intelligence. Its modular architecture, offline resilience, and interactive visualization render it a comprehensive deliverable for enterprise deployments.

### Future Enhancements
- Integration of Transformer models (BERT / RoBERTa / DeBERTa) for fine-grained aspect-based sentiment analysis (ABSA).
- Real-time streaming integration with live Twitter/Reddit APIs and AWS S3 data lakes.
- Multilingual sentiment classification supporting Spanish, Hindi, German, and French.
