# System Architecture Specification
## AI-Based Sentiment Analysis Dashboard

```text
+---------------------------------------------------------------------------------+
|                                 USER INTERFACE                                  |
|         Streamlit Dashboard (Browser: localhost:8501 / Web Application)        |
+---------------------------------------------------------------------------------+
                                       |
                   +-------------------+-------------------+
                   |                                       |
          [ Preloaded Datasets ]                  [ User File Ingestion ]
          - Amazon Reviews CSV                    - CSV / TSV Upload
          - Social Media CSV                      - Excel (.xlsx, .xls)
          - News Headlines CSV                    - Raw Single Text Prompt
                   |                                       |
                   +-------------------+-------------------+
                                       |
                                       v
+---------------------------------------------------------------------------------+
|                       MODULE 1: DATA INGESTION & SANITIZATION                  |
|                        (src/preprocessor.py: TextPreprocessor)                  |
|  - Missing Value Null-Coalescing & Type Casting                                |
|  - HTML Tag & URL Regex Stripping                                               |
|  - Contraction Expansion ('don't' -> 'do not')                                  |
|  - Punctuation Normalization & Lowercasing                                      |
|  - Stopword Removal & Tokenization                                              |
+---------------------------------------------------------------------------------+
                                       |
                   +-------------------+-------------------+
                   |                                       |
                   v                                       v
+------------------------------------+   +------------------------------------+
|  MODULE 2: SENTIMENT ANALYSIS      |   |   MODULE 3: EMOTION LEXICON        |
|  (src/sentiment_analyzer.py)       |   |   (src/emotion_detector.py)        |
|  - VADER Valence Intensity Engine  |   |   - Plutchik 8-Emotion Dimensions  |
|    * pos, neu, neg, compound (-1..1)|   |     (Joy, Trust, Fear, Surprise,   |
|  - TextBlob Pattern Analyzer       |   |      Sadness, Disgust, Anger,      |
|    * polarity, subjectivity        |   |      Anticipation)                 |
|  - Consensus & Agreement Scoring   |   |   - Normalized Intensity Radar     |
+------------------------------------+   +------------------------------------+
                   |                                       |
                   +-------------------+-------------------+
                                       |
                                       v
+---------------------------------------------------------------------------------+
|                   MODULE 4: ANALYTICS & INSIGHTS ENGINE                         |
|                   (src/insights_generator.py: InsightsGenerator)               |
|  - Metric Aggregation: Counts, Percentages, Mean Compound Score                 |
|  - Net Sentiment Score (NSS = % Positive - % Negative)                          |
|  - Brand Health Rating Classification                                           |
|  - Actionable Product & Marketing Recommendation Extraction                     |
+---------------------------------------------------------------------------------+
                                       |
                   +-------------------+-------------------+
                   |                                       |
                   v                                       v
+------------------------------------+   +------------------------------------+
|   MODULE 5: DATA VISUALIZATIONS    |   |     MODULE 6: REPORT EXPORTER      |
|   (src/visualizer.py)              |   |     (src/report_generator.py)      |
|   - Sentiment Donut / Pie Chart    |   |   - PDF Report Document Builder    |
|   - Sentiment Frequency Bars       |   |   - Classified Dataset CSV Export  |
|   - Temporal Trend Line Chart      |   |   - Statistical Summary JSON       |
|   - Dual Word Clouds (Pos vs Neg)  |   |                                    |
|   - Polarity vs Subjectivity Plot  |   |                                    |
+------------------------------------+   +------------------------------------+
```

### Module Interactions & Design Patterns
1. **Loose Coupling & Separation of Concerns:**
   Every module in `src/` is an independent Python class with zero circular dependencies. The UI layer (`app.py`) serves solely as an orchestration controller.
2. **Graceful Fallback & Offline Resilience:**
   `SentimentAnalyzer`, `TextPreprocessor`, and `EmotionDetector` contain zero-dependency fallback rules ensuring error-free execution even in constrained environments without external network downloads.
3. **Dataframe Vectorization:**
   Data processing handles batch frames efficiently through Pandas operations, supporting tens of thousands of rows with fast sub-second completion times.
