# Beginner-Friendly User & Execution Guide
## AI-Based Sentiment Analysis Dashboard

This guide walks you through setting up, configuring, and executing the project in **Visual Studio Code (VS Code)** using Python and Streamlit.

---

## 💻 System Prerequisites
1. **Python 3.9, 3.10, 3.11, or 3.12** installed ([python.org](https://www.python.org/downloads/)).
2. **Visual Studio Code** installed ([code.visualstudio.com](https://code.visualstudio.com/)).
3. **Python extension for VS Code** installed (Search `Python` by Microsoft in VS Code Extensions `Ctrl+Shift+X`).

---

## 🛠️ Step-by-Step Setup in VS Code

### Step 1: Open the Project Directory
1. Launch VS Code.
2. Click **File > Open Folder...** (or press `Ctrl + K, Ctrl + O`).
3. Select the `ai-sentiment-analysis-dashboard` folder.

### Step 2: Open the Integrated Terminal
- Press ``Ctrl + ` `` (backtick) or select **Terminal > New Terminal** from the top menu.

### Step 3: Create an Isolated Python Virtual Environment
Creating a virtual environment ensures clean dependencies without affecting your system Python:

**Windows (PowerShell):**
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```
*(If you encounter an execution policy error in PowerShell, run: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process` and retry.)*

**Windows (Command Prompt / CMD):**
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

**macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

*(You will notice `(venv)` prepended to your terminal prompt, indicating the virtual environment is active.)*

### Step 4: Install Required Dependencies
Run the following command to install all pinned libraries:
```bash
pip install -r requirements.txt
```

### Step 5 (Optional): Download NLTK Corpora
For full NLTK corpus support, execute this one-liner in your terminal:
```bash
python -c "import nltk; nltk.download('stopwords'); nltk.download('punkt'); nltk.download('vader_lexicon')"
```
*(Note: If offline, the application will automatically fall back to its internal built-in lexicons!)*

---

## 🚀 Running the Streamlit Dashboard
Execute the following command in your active terminal:
```bash
streamlit run app.py
```

### What Happens Next:
1. Streamlit initializes the local web server.
2. A URL will appear in your terminal:
   ```text
   Local URL: http://localhost:8501
   Network URL: http://192.168.x.x:8501
   ```
3. Your default web browser will automatically open the interactive dashboard.

To stop the server at any time, return to the terminal and press `Ctrl + C`.

---

## 🧪 Running Unit Tests
To verify all preprocessing, sentiment scoring, and emotion detection modules:
```bash
pytest tests/ -v
```
Expected output:
```text
tests/test_preprocessor.py::test_clean_text PASSED
tests/test_preprocessor.py::test_url_removal PASSED
tests/test_preprocessor.py::test_contraction_expansion PASSED
tests/test_sentiment.py::test_positive_sentiment PASSED
tests/test_sentiment.py::test_negative_sentiment PASSED
tests/test_sentiment.py::test_neutral_sentiment PASSED
tests/test_emotion.py::test_emotion_detection PASSED
========================= 7 passed in 0.45s =========================
```

---

## 🧭 How to Use the Dashboard Features

### 1. Analyzing Preloaded Datasets
- In the left sidebar under **Select Dataset Source**, choose **Preloaded Real Datasets**.
- Pick any dataset:
  - *Amazon Product Reviews (Real Dataset)*
  - *Social Media Posts (Twitter / X)*
  - *News Articles & Financial Headlines*
- View the KPI metrics update immediately in the top scorecards.

### 2. Uploading Your Own Custom Dataset (CSV or Excel)
- Under **Select Dataset Source**, click **Upload Custom Dataset (CSV/Excel)**.
- Drag-and-drop or browse for any `.csv`, `.xlsx`, or `.xls` file.
- The dashboard will detect columns; select your text column from the dropdown.
- Missing values will be automatically sanitized without errors!

### 3. Single-Text NLP Playground
- Under **Select Dataset Source**, click **Single Text Playground**.
- Type or paste any phrase or review, or click one of the quick preset buttons.
- View real-time VADER scores, TextBlob polarity, and Plutchik emotion breakdowns.

### 4. Downloading Deliverables & PDF Reports
- Navigate to the **Export & PDF Report** tab.
- Click **📥 Download Classified CSV Data** to export the dataset with sentiment classifications.
- Click **📄 Download Official PDF Report** to generate a styled executive project summary report.

---

## ❓ Frequently Asked Questions & Troubleshooting

**Q: Streamlit command not recognized?**  
A: Ensure your virtual environment is active (`(venv)` appears in the prompt) and that you installed `requirements.txt`.

**Q: Excel upload gives an error?**  
A: Make sure `openpyxl` is installed (`pip install openpyxl`). It is included in `requirements.txt`.

**Q: WordCloud shows an error on macOS/Linux?**  
A: WordCloud requires `Pillow` and standard C build tools. If unavailable, the dashboard will safely display a notification without crashing other features.
