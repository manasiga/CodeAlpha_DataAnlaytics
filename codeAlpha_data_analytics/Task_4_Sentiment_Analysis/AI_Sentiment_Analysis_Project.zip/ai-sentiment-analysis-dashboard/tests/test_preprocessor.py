"""
Unit tests for TextPreprocessor module.
"""

import pytest
from src.preprocessor import TextPreprocessor


@pytest.fixture
def preprocessor():
    return TextPreprocessor()


def test_clean_text(preprocessor):
    raw = "   <b>Amazing</b> product! Works very well...   "
    cleaned = preprocessor.clean_text(raw)
    assert "amazing" in cleaned
    assert "<b>" not in cleaned
    assert "works" in cleaned


def test_url_removal(preprocessor):
    raw = "Check our store at https://amazon.com/item123 for discounts!"
    cleaned = preprocessor.clean_text(raw, remove_urls=True)
    assert "https" not in cleaned
    assert "amazon.com" not in cleaned
    assert "discounts" in cleaned


def test_contraction_expansion(preprocessor):
    raw = "I won't buy this again, it isn't durable."
    cleaned = preprocessor.clean_text(raw)
    assert "will not" in cleaned or "not" in cleaned


def test_empty_and_null_handling(preprocessor):
    assert preprocessor.clean_text(None) == ""
    assert preprocessor.clean_text("") == ""
    assert preprocessor.clean_text("nan") == ""
    assert preprocessor.tokenize("") == []


def test_tokenization_and_stopwords(preprocessor):
    tokens = preprocessor.tokenize("This is a truly magnificent wireless headphone")
    filtered = preprocessor.remove_stopwords(tokens)
    assert "magnificent" in filtered
    assert "headphone" in filtered
    assert "is" not in filtered
    assert "a" not in filtered
