"""
Unit tests for EmotionDetector module.
"""

import pytest
from src.emotion_detector import EmotionDetector


@pytest.fixture
def detector():
    return EmotionDetector()


def test_joy_detection(detector):
    text = "We loved this delicious meal! Pure bliss, wonderful celebration."
    result = detector.detect_emotions(text)
    assert result["has_emotional_charge"] is True
    assert result["dominant_emotion"] == "Joy"
    assert result["raw_counts"]["Joy"] >= 2


def test_anger_detection(detector):
    text = "This terrible scam is infuriating and unacceptable! Absolute rip-off."
    result = detector.detect_emotions(text)
    assert result["has_emotional_charge"] is True
    assert result["dominant_emotion"] == "Anger"
    assert result["raw_counts"]["Anger"] >= 2


def test_neutral_handling(detector):
    text = "The bus route number 42 departs at 10 AM."
    result = detector.detect_emotions(text)
    assert result["has_emotional_charge"] is False
