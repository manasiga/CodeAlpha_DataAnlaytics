"""
Unit tests for SentimentAnalyzer module.
"""

import pytest
from src.sentiment_analyzer import SentimentAnalyzer


@pytest.fixture
def analyzer():
    return SentimentAnalyzer()


def test_positive_sentiment(analyzer):
    text = "The sound quality is astonishingly crisp and rich with bass. Best purchase ever!"
    result = analyzer.analyze_text(text)
    assert result["sentiment"] == "Positive"
    assert result["vader"]["compound"] > 0.05


def test_negative_sentiment(analyzer):
    text = "Terrible build quality. Snapped after 2 weeks, support was rude and refused refund."
    result = analyzer.analyze_text(text)
    assert result["sentiment"] == "Negative"
    assert result["vader"]["compound"] < -0.05


def test_neutral_sentiment(analyzer):
    text = "The package arrived on Tuesday at 4 PM in a rectangular cardboard box."
    result = analyzer.analyze_text(text)
    assert result["sentiment"] == "Neutral"
    assert -0.2 <= result["vader"]["compound"] <= 0.2


def test_textblob_scores(analyzer):
    text = "This is a remarkably brilliant and delightful invention."
    scores = analyzer.analyze_textblob(text)
    assert scores["polarity"] > 0
    assert scores["subjectivity"] > 0


def test_empty_string_handling(analyzer):
    result = analyzer.analyze_text("")
    assert result["sentiment"] == "Neutral"
    assert result["vader"]["compound"] == 0.0
