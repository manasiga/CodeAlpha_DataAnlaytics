# AI-Based Sentiment Analysis Dashboard
> **Internship Capstone Project | Final Submission**  
> **Author:** Manasi Ga  
> **Technologies:** Python, Streamlit, Pandas, NumPy, NLTK, VADER Sentiment, TextBlob, Matplotlib, Seaborn, WordCloud, ReportLab

---

## 🎯 Project Overview & Objective
The **AI-Based Sentiment Analysis Dashboard** is a multi-modal Natural Language Processing (NLP) system designed to analyze and classify opinions from real-world textual data—including **Amazon product reviews, social media feeds (Twitter/X), and news articles**—into **Positive**, **Negative**, and **Neutral** sentiments.

In addition to traditional polarity classification, this system incorporates **Plutchik's psycholinguistic emotion detection** (Joy, Trust, Fear, Surprise, Sadness, Disgust, Anger, Anticipation), temporal trend tracking, word clouds, automated executive **PDF reporting**, and automated **business intelligence recommendations** for marketing and product development teams.

---

## 🏗️ Project Architecture & Directory Structure
```text
ai-sentiment-analysis-dashboard/
│
├── app.py                      # Main Streamlit interactive web application
├── requirements.txt            # Pinned, production-tested Python dependencies
├── README.md                   # Comprehensive internship project documentation
│
├── data/                       # Authentic, real datasets (No fabricated data)
│   ├── amazon_reviews.csv      # Real Amazon customer reviews across categories
│   ├── social_media_posts.csv  # Real tweets/social posts with engagement stats
│   ├── news_headlines.csv      # Real tech & financial news headlines
│   └── sample_custom_reviews.csv # Quick upload testing dataset
│
├── src/                        # Modularized Python backend package
│   ├── __init__.py             # Package declaration
│   ├── preprocessor.py         # Regex cleaning, URL stripping, contractions, tokenization
│   ├── sentiment_analyzer.py   # VADER + TextBlob dual engines with consensus logic
│   ├── emotion_detector.py     # 8-dimensional Plutchik emotion lexicon engine
│   ├── visualizer.py           # Matplotlib/Seaborn charts and WordCloud generators
│   ├── insights_generator.py   # Net Sentiment Score (NSS) & marketing insights
│   └── report_generator.py     # Automated executive PDF report builder
│
├── docs/                       # Formal Academic & Internship Documentation
│   ├── PROJECT_REPORT.md       # Complete academic report with methodology & evaluation
│   ├── SYSTEM_ARCHITECTURE.md  # Detailed pipeline dataflow diagrams
│   └── USER_GUIDE.md           # Step-by-step VS Code execution & troubleshooting guide
│
├── reports/                    # Generated project artifacts
│   └── Sentiment_Analysis_Internship_Report.pdf # Sample executive PDF report
│
├── tests/                      # Automated Unit Test Suites
│   ├── test_preprocessor.py    # Preprocessing and cleaning validation
│   ├── test_sentiment.py       # VADER and TextBlob classification tests
│   └── test_emotion.py         # Emotion lexicon detection tests
│
└── sample_output/              # Generated Sample Deliverables
    ├── sentiment_summary_metrics.json
    ├── classified_amazon_reviews_sample.csv
    └── sample_insights.txt
```

---

## ⚙️ Key Features

### 1. Dataset Management
- Preloaded with authentic datasets from **Amazon**, **Twitter/X**, and **Global News**.
- Robust **custom CSV and Excel (.xlsx, .xls)** upload system.
- Automatic **missing value handling** (null imputation and clean substitution) ensuring zero runtime crashes.

### 2. Multi-Stage Text Preprocessing
- Removal of URLs (`http://`, `https://`, `www.`).
- Elimination of HTML artifacts and extraneous whitespace.
- Expansion of English contractions (e.g., `don't` $\rightarrow$ `do not`, `won't` $\rightarrow$ `will not`).
- Stopword removal with NLTK corpus support and zero-dependency fallbacks.
- Discrete tokenization and punctuation normalization.

### 3. Dual-Engine Sentiment Analysis & Emotion Detection
- **VADER Sentiment**: Optimized for sentiment in social media and reviews; evaluates capitalization, punctuation intensifiers (`!`), and sentiment shifters.
- **TextBlob**: Provides sentence-level Polarity ($-1.0$ to $+1.0$) and Subjectivity ($0.0$ to $1.0$).
- **Model Consensus Engine**: Flags agreement or divergence between VADER and TextBlob.
- **Plutchik Emotion Lexicon**: Quantifies intensities across 8 psychological dimensions: *Joy, Trust, Fear, Surprise, Sadness, Disgust, Anger, Anticipation*.

### 4. Rich Data Visualizations
- **Sentiment Distribution Donut / Pie Chart**
- **Volume Comparison Bar Chart** with annotated data labels
- **Temporal Sentiment Trajectory Chart** over time
- **Dual-Colormap Word Clouds** for positive vs. negative vocabulary
- **Emotion Lexicon Frequency Chart**
- **Polarity vs. Subjectivity Scatter Plot**

### 5. Interactive Business Intelligence & Insights
- Calculation of **Net Sentiment Score (NSS)** = `% Positive - % Negative`.
- Real-time Brand Health Status tiering.
- Auto-generated **Product Improvement Action Items** derived from negative reviews.
- Auto-generated **Marketing & Campaign Recommendations** derived from customer praise.

### 6. Deliverables & Report Exports
- Instant **CSV Export** with all sentiment tags, scores, and emotions.
- Downloadable **Executive PDF Project Report** containing statistical summaries, tables, and action items.

---

## 🚀 Quickstart Guide for VS Code

### Prerequisites
- Python 3.9, 3.10, 3.11, or 3.12 installed on your machine.
- Visual Studio Code with the Python extension installed.

### Step 1: Clone or Unzip the Project
Open VS Code, navigate to `File > Open Folder...` and select the unzipped project folder:
```bash
cd ai-sentiment-analysis-dashboard
```

### Step 2: Create a Virtual Environment (Recommended)
Open the integrated terminal in VS Code (`Ctrl + ~` or `Cmd + ~`):
```bash
# On Windows:
python -m venv venv
venv\Scripts\activate

# On macOS / Linux:
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Streamlit Dashboard
```bash
streamlit run app.py
```
Streamlit will automatically launch the dashboard in your default web browser at `http://localhost:8501`.

### Step 5: Run Automated Unit Tests
To verify all NLP modules and classification rules:
```bash
pytest tests/ -v
```

---

## 📊 Summary of Experimental Results
Analyzed on the **Amazon Product Reviews Dataset** ($N=20$ multi-category reviews):
- **Positive Sentiment:** 60.0% (12 reviews)
- **Negative Sentiment:** 30.0% (6 reviews)
- **Neutral Sentiment:** 10.0% (2 reviews)
- **Net Sentiment Score (NSS):** $+30.0\%$ (Healthy brand equity with isolated hardware durability concerns)
- **Dominant Emotion Identified:** *Joy* (highest frequency: 18 occurrences), followed by *Trust* (12 occurrences).

---

## 📜 Academic Integrity & License
This project was designed and built as a formal internship deliverable by **Manasi Ga**.  
Released under the **MIT License**.
