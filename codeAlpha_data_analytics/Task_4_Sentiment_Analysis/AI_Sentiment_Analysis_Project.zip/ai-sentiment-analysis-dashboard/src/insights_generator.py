"""
Insights and Recommendation Generation Module.
Synthesizes sentiment metrics, top praise themes, critical friction points,
and produces actionable business recommendations for marketing and product development teams.
"""

from typing import Dict, List, Any
import collections
import re


class InsightsGenerator:
    """Generates structured business and product intelligence from sentiment data."""

    def __init__(self):
        pass

    def extract_key_themes(self, texts: List[str], sentiment_type: str = "Negative") -> List[str]:
        """Extracts high-frequency phrases or recurring keywords from specific sentiment segments."""
        if not texts:
            return []

        stopwords = {
            'the', 'and', 'for', 'with', 'this', 'that', 'have', 'from', 'was',
            'are', 'not', 'but', 'all', 'out', 'after', 'only', 'too', 'when',
            'even', 'than', 'into', 'they', 'them', 'their', 'were', 'been',
            'what', 'will', 'about', 'just', 'more', 'some', 'could', 'would'
        }

        words = []
        for text in texts:
            cleaned = re.sub(r'[^\w\s]', '', str(text).lower())
            tokens = [w for w in cleaned.split() if len(w) > 3 and w not in stopwords]
            words.extend(tokens)

        counts = collections.Counter(words)
        return [word for word, count in counts.most_common(6)]

    def generate_executive_insights(self, dataset_summary: Dict[str, Any]) -> Dict[str, Any]:
        """
        Produces detailed marketing, product, and customer satisfaction insights.
        Calculates Net Sentiment Score (NSS = % Pos - % Neg).
        """
        total = dataset_summary.get("total_records", 0)
        pos = dataset_summary.get("positive_count", 0)
        neg = dataset_summary.get("negative_count", 0)
        neu = dataset_summary.get("neutral_count", 0)

        pos_pct = round((pos / total * 100), 1) if total > 0 else 0.0
        neg_pct = round((neg / total * 100), 1) if total > 0 else 0.0
        neu_pct = round((neu / total * 100), 1) if total > 0 else 0.0

        # Net Sentiment Score (NSS): akin to Net Promoter Score (-100 to +100)
        net_sentiment_score = round(pos_pct - neg_pct, 1)

        # Health status tier
        if net_sentiment_score >= 40:
            health_status = "Very Healthy / Strong Brand Equity"
            tone = "Optimistic"
        elif net_sentiment_score >= 10:
            health_status = "Moderate / Positive Leaning"
            tone = "Cautiously Favorable"
        elif net_sentiment_score >= -10:
            health_status = "Neutral / Mixed Public Opinion"
            tone = "Divided"
        else:
            health_status = "Critical Risk / High Detractor Volume"
            tone = "Urgent Attention Required"

        # Actionable recommendations
        marketing_recommendations = [
            f"Capitalize on positive sentiment ({pos_pct}% favorable) in digital ad creatives by highlighting verified customer praise and testimonials.",
            "Promote high-trust attributes in value proposition messaging to convert neutral browsers (representing " + str(neu_pct) + "% of the audience).",
            "Target influencer and community advocacy campaigns around the top-praised features."
        ]

        product_recommendations = [
            f"Prioritize immediate engineering triage on friction points driving {neg_pct}% negative feedback.",
            "Conduct root-cause analysis on recurring defect patterns and failure modes highlighted in customer reports.",
            "Implement in-app feedback triggers right after high-friction workflows to intercept negative sentiment early."
        ]

        customer_success_recommendations = [
            "Establish proactive outreach protocols for users registering negative compound scores (<= -0.50).",
            "Empower tier-1 support agents with rapid-resolution compensation authorities (discounts/replacements) to mitigate churn.",
            "Publish transparent changelogs and firmware/software updates addressing known complaints to restore customer trust."
        ]

        return {
            "total_analyzed": total,
            "positive_percentage": pos_pct,
            "negative_percentage": neg_pct,
            "neutral_percentage": neu_pct,
            "net_sentiment_score": net_sentiment_score,
            "brand_health_status": health_status,
            "overall_tone": tone,
            "marketing_action_items": marketing_recommendations,
            "product_action_items": product_recommendations,
            "customer_success_items": customer_success_recommendations,
        }
