"""
Text Preprocessing Module for Sentiment Analysis
Handles text cleaning, URL removal, contraction expansion, stopword removal, and tokenization.
Designed with robust fallbacks for offline execution without NLTK downloads.
"""

import re
import string
from typing import List, Dict, Any, Optional

# Standard English stop words fallback dictionary
DEFAULT_STOPWORDS = {
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're",
    "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he',
    'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's",
    'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what',
    'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is',
    'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having',
    'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or',
    'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about',
    'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above',
    'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under',
    'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why',
    'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some',
    'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
    's', 't', 'can', 'will', 'just', 'don', 'should', "should've", 'now', 'd', 'll',
    'm', 'o', 're', 've', 'y', 'ain', 'aren', 'couldn', 'didn', 'doesn', 'hadn',
    'hasn', 'haven', 'isn', 'ma', 'mightn', 'mustn', 'needn', 'shan', 'shouldn',
    'wasn', 'weren', 'won', 'wouldn'
}

CONTRACTIONS_MAP = {
    "won't": "will not",
    "can't": "cannot",
    "n't": " not",
    "'re": " are",
    "'s": " is",
    "'d": " would",
    "'ll": " will",
    "'t": " not",
    "'ve": " have",
    "'m": " am",
}


class TextPreprocessor:
    """Production-grade text cleaning and tokenization pipeline."""

    def __init__(self, custom_stopwords: Optional[set] = None):
        self.stopwords = set(DEFAULT_STOPWORDS)
        if custom_stopwords:
            self.stopwords.update(custom_stopwords)

        # Attempt to load NLTK stopwords if available
        try:
            import nltk
            from nltk.corpus import stopwords
            try:
                nltk_stops = set(stopwords.words('english'))
                self.stopwords.update(nltk_stops)
            except Exception:
                pass
        except ImportError:
            pass

    def expand_contractions(self, text: str) -> str:
        """Expands common English contractions for better sentiment accuracy."""
        for contraction, expansion in CONTRACTIONS_MAP.items():
            text = re.sub(r'\b' + re.escape(contraction) + r'\b', expansion, text, flags=re.IGNORECASE)
        return text

    def clean_text(
        self,
        text: Any,
        remove_urls: bool = True,
        remove_mentions: bool = True,
        remove_punctuation: bool = True,
        lowercase: bool = True,
        strip_numbers: bool = False
    ) -> str:
        """
        Comprehensive text cleaning pipeline.
        Safely handles None, NaN, and non-string inputs.
        """
        if text is None:
            return ""

        # Convert to string and handle NaN values
        text_str = str(text).strip()
        if not text_str or text_str.lower() in ("nan", "none", "null"):
            return ""

        # Remove HTML tags
        text_str = re.sub(r'<[^>]+>', ' ', text_str)

        # Remove URLs
        if remove_urls:
            text_str = re.sub(r'https?://\S+|www\.\S+', '', text_str)

        # Remove user mentions and hashtag symbols
        if remove_mentions:
            text_str = re.sub(r'@[A-Za-z0-9_]+', '', text_str)
            text_str = re.sub(r'#([A-Za-z0-9_]+)', r'\1', text_str)

        # Expand contractions
        text_str = self.expand_contractions(text_str)

        # Remove punctuation
        if remove_punctuation:
            # Keep letters, numbers, and basic spacing
            text_str = re.sub(r'[^\w\s]', ' ', text_str)

        # Strip numbers if requested
        if strip_numbers:
            text_str = re.sub(r'\d+', ' ', text_str)

        # Convert to lowercase
        if lowercase:
            text_str = text_str.lower()

        # Normalize redundant spaces
        text_str = re.sub(r'\s+', ' ', text_str).strip()

        return text_str

    def tokenize(self, text: str) -> List[str]:
        """Tokenize text into discrete words."""
        if not text:
            return []

        # Try NLTK tokenizer first, fallback to regex
        try:
            from nltk.tokenize import word_tokenize
            return word_tokenize(text)
        except Exception:
            return re.findall(r'\b\w+\b', text)

    def remove_stopwords(self, tokens: List[str]) -> List[str]:
        """Filter out stopwords while preserving sentiment-bearing tokens."""
        return [tok for tok in tokens if tok.lower() not in self.stopwords and len(tok) > 1]

    def preprocess_pipeline(self, text: Any, remove_stops: bool = True) -> Dict[str, Any]:
        """
        Runs the full text preprocessing pipeline and returns intermediate steps.
        Useful for education, debugging, and dashboard display.
        """
        raw_text = "" if text is None else str(text).strip()
        cleaned = self.clean_text(raw_text)
        tokens = self.tokenize(cleaned)
        filtered_tokens = self.remove_stopwords(tokens) if remove_stops else tokens
        processed_text = " ".join(filtered_tokens)

        return {
            "raw_text": raw_text,
            "cleaned_text": cleaned,
            "tokens": tokens,
            "filtered_tokens": filtered_tokens,
            "processed_text": processed_text,
            "raw_word_count": len(raw_text.split()) if raw_text else 0,
            "cleaned_word_count": len(filtered_tokens),
            "stopwords_removed_count": len(tokens) - len(filtered_tokens)
        }
