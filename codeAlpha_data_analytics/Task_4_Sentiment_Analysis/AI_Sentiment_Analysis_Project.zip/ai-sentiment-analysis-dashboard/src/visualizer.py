"""
Data Visualization Module for Sentiment Analysis.
Generates Matplotlib/Seaborn figures and WordClouds for the Streamlit dashboard and PDF reports.
"""

from typing import Dict, List, Any, Optional
import io
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Headless backend safe for web servers

# Color Palette
PALETTE = {
    "Positive": "#10B981",  # Emerald Green
    "Negative": "#EF4444",  # Crimson Red
    "Neutral": "#6B7280",   # Slate Grey
    "Accent": "#3B82F6",    # Blue
    "Background": "#F9FAFB",
    "Text": "#111827"
}


class SentimentVisualizer:
    """Produces publication-ready charts and word clouds."""

    def __init__(self):
        plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')

    def plot_sentiment_pie(self, counts: Dict[str, int]) -> plt.Figure:
        """Generates a modern donut/pie chart showing sentiment distribution."""
        fig, ax = plt.subplots(figsize=(6, 5), dpi=100)
        labels = [k for k in ["Positive", "Neutral", "Negative"] if counts.get(k, 0) > 0]
        values = [counts.get(k, 0) for k in labels]
        colors = [PALETTE.get(k, "#9CA3AF") for k in labels]

        if not values or sum(values) == 0:
            ax.text(0.5, 0.5, "No Sentiment Data Available", ha='center', va='center', fontsize=12)
            return fig

        wedges, texts, autotexts = ax.pie(
            values,
            labels=labels,
            autopct='%1.1f%%',
            startangle=140,
            colors=colors,
            pctdistance=0.75,
            wedgeprops=dict(width=0.45, edgecolor='white', linewidth=2)
        )

        for text in autotexts:
            text.set_color('white')
            text.set_weight('bold')
            text.set_fontsize(11)

        ax.set_title("Overall Sentiment Distribution", fontsize=14, weight='bold', pad=15)
        fig.tight_layout()
        return fig

    def plot_sentiment_bars(self, counts: Dict[str, int]) -> plt.Figure:
        """Generates an aesthetic bar chart comparing Positive, Neutral, and Negative counts."""
        fig, ax = plt.subplots(figsize=(7, 4.5), dpi=100)
        categories = ["Positive", "Neutral", "Negative"]
        values = [counts.get(cat, 0) for cat in categories]
        colors = [PALETTE[cat] for cat in categories]

        bars = ax.bar(categories, values, color=colors, width=0.55, edgecolor='#E5E7EB', linewidth=1)

        # Add data labels on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.annotate(
                f'{height}',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 4),
                textcoords="offset points",
                ha='center', va='bottom',
                fontweight='bold', fontsize=11
            )

        ax.set_ylabel("Count of Records", fontsize=11, fontweight='medium')
        ax.set_title("Sentiment Volume Comparison", fontsize=14, weight='bold', pad=15)
        ax.grid(axis='y', linestyle='--', alpha=0.7)
        fig.tight_layout()
        return fig

    def plot_sentiment_trend(self, df_with_dates) -> plt.Figure:
        """Generates a time-series trend line of average compound sentiment over dates."""
        fig, ax = plt.subplots(figsize=(8, 4.2), dpi=100)

        if 'date' not in df_with_dates.columns or 'compound' not in df_with_dates.columns:
            ax.text(0.5, 0.5, "Date or Compound score column not found", ha='center', va='center')
            return fig

        # Sort and group by date
        sorted_df = df_with_dates.dropna(subset=['date', 'compound']).sort_values('date')
        if sorted_df.empty:
            ax.text(0.5, 0.5, "No temporal sentiment data available", ha='center', va='center')
            return fig

        daily = sorted_df.groupby('date')['compound'].mean().reset_index()

        ax.plot(daily['date'], daily['compound'], marker='o', color='#3B82F6', linewidth=2.5, markersize=6, label='Daily Compound Score')
        ax.axhline(0.05, color='#10B981', linestyle=':', alpha=0.7, label='Positive Threshold (+0.05)')
        ax.axhline(-0.05, color='#EF4444', linestyle=':', alpha=0.7, label='Negative Threshold (-0.05)')
        ax.axhline(0, color='#9CA3AF', linestyle='-', linewidth=0.8, alpha=0.5)

        ax.set_title("Temporal Sentiment Trajectory", fontsize=14, weight='bold', pad=15)
        ax.set_ylabel("Mean Compound Score (-1 to +1)", fontsize=11)
        ax.set_xlabel("Date", fontsize=11)
        ax.tick_params(axis='x', rotation=45)
        ax.legend(loc='lower right', frameon=True)
        ax.grid(True, linestyle='--', alpha=0.5)
        fig.tight_layout()
        return fig

    def plot_emotion_distribution(self, emotion_totals: Dict[str, int]) -> plt.Figure:
        """Generates a bar chart of Plutchik emotion intensities."""
        fig, ax = plt.subplots(figsize=(8, 4.5), dpi=100)
        emotions = list(emotion_totals.keys())
        counts = [emotion_totals[e] for e in emotions]

        colors = ['#10B981', '#3B82F6', '#EF4444', '#F59E0B', '#6366F1', '#84CC16', '#DC2626', '#8B5CF6']
        bars = ax.barh(emotions, counts, color=colors[:len(emotions)], height=0.6)

        for bar in bars:
            width = bar.get_width()
            ax.annotate(
                f'{width}',
                xy=(width, bar.get_y() + bar.get_height() / 2),
                xytext=(4, 0),
                textcoords="offset points",
                ha='left', va='center',
                fontweight='bold', fontsize=10
            )

        ax.set_xlabel("Frequency in Dataset", fontsize=11)
        ax.set_title("NLP Emotion Lexicon Breakdown", fontsize=14, weight='bold', pad=15)
        ax.grid(axis='x', linestyle='--', alpha=0.6)
        fig.tight_layout()
        return fig

    def generate_wordcloud(self, text_corpus: str) -> Optional[Any]:
        """Generates a WordCloud object if library is installed, otherwise None."""
        if not text_corpus or not text_corpus.strip():
            return None

        try:
            from wordcloud import WordCloud, STOPWORDS
            wc = WordCloud(
                width=800,
                height=420,
                background_color='white',
                colormap='viridis',
                stopwords=STOPWORDS,
                max_words=120,
                contour_width=1,
                contour_color='#E5E7EB'
            ).generate(text_corpus)
            return wc
        except ImportError:
            return None
