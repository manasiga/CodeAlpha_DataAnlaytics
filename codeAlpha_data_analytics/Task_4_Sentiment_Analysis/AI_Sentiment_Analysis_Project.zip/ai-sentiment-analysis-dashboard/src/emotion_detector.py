"""
Emotion Detection Module using Psychological NLP Lexicons.
Classifies text into Plutchik's primary emotion dimensions:
Joy, Trust, Fear, Surprise, Sadness, Disgust, Anger, Anticipation.
"""

from typing import Dict, Any, List
import re

EMOTION_LEXICON = {
    "Joy": {
        "love", "loved", "delighted", "happy", "joy", "bliss", "excited", "wonderful",
        "awesome", "fantastic", "great", "excellent", "superb", "brilliant", "smooth",
        "crisp", "rich", "pleased", "celebrate", "uplifting", "satisfying", "flawlessly",
        "enjoy", "tasty", "delicious", "heartfelt", "perfection", "cherish", "favorite"
    },
    "Trust": {
        "recommend", "reliable", "durable", "solid", "accurate", "authentic", "secure",
        "guarantee", "certified", "trusted", "loyal", "consistent", "verified", "true",
        "honest", "integrity", "faith", "confidence", "stable", "dependable", "safe"
    },
    "Fear": {
        "danger", "risk", "hazard", "threat", "scared", "fear", "dread", "alarm",
        "anxious", "panic", "toxic", "failure", "fail", "breach", "ransomware", "damage",
        "collapse", "loss", "vulnerable", "warning", "strained", "strangling", "horror"
    },
    "Surprise": {
        "astonishingly", "mindblowing", "unexpected", "shocking", "unbelievable", "surpassed",
        "sudden", "amazed", "astonished", "wow", "marvel", "breakthrough", "record",
        "miracle", "stumbled", "unforeseen", "startling", "remarkable"
    },
    "Sadness": {
        "sad", "sorrow", "grief", "depressed", "unhappy", "crying", "tears", "disappointed",
        "disappointing", "regret", "lost", "neglected", "lonely", "hopeless", "melancholy",
        "mourn", "hurt", "despair", "misfortune", "ruined", "heartbroken"
    },
    "Disgust": {
        "disgusting", "revolting", "nasty", "gross", "sickening", "vile", "foul", "stink",
        "smell", "sticky", "peeling", "rotten", "repulsive", "filthy", "dirty", "odor",
        "hateful", "toxic", "unbearable", "garbage", "trash"
    },
    "Anger": {
        "angry", "furious", "outrage", "terrible", "awful", "horrible", "annoying",
        "frustrating", "scam", "cheat", "rip-off", "unacceptable", "refused", "rude",
        "dismissive", "hateful", "infuriating", "irritated", "rage", "mad", "bitter"
    },
    "Anticipation": {
        "eager", "expecting", "looking forward", "anticipate", "hope", "ready", "upcoming",
        "next-gen", "promising", "future", "prepare", "wait", "scheduled", "curious",
        "seeking", "aspire", "envision", "explore", "opportunity"
    }
}


class EmotionDetector:
    """Detects multi-label emotion intensities from text tokens."""

    def __init__(self):
        self.lexicon = EMOTION_LEXICON

    def detect_emotions(self, text: Any) -> Dict[str, Any]:
        """
        Analyzes the given text against Plutchik's emotion lexicons.
        Returns score per emotion category and the dominant emotion.
        """
        text_str = "" if text is None else str(text).lower()
        words = re.findall(r'\b[a-z]{3,}\b', text_str)

        total_words = max(1, len(words))
        raw_scores: Dict[str, int] = {emotion: 0 for emotion in self.lexicon}
        matched_words: Dict[str, List[str]] = {emotion: [] for emotion in self.lexicon}

        for word in words:
            for emotion, vocab in self.lexicon.items():
                if word in vocab:
                    raw_scores[emotion] += 1
                    matched_words[emotion].append(word)

        # Normalize to percentage / relative intensity
        max_count = max(raw_scores.values()) if any(raw_scores.values()) else 0
        normalized_scores = {}
        for emotion, count in raw_scores.items():
            if max_count > 0:
                normalized_scores[emotion] = round((count / max_count) * 100, 1)
            else:
                normalized_scores[emotion] = 0.0

        # Dominant emotion determination
        if max_count > 0:
            dominant_emotion = max(raw_scores, key=lambda k: raw_scores[k])
        else:
            dominant_emotion = "Neutral / Balanced"

        return {
            "dominant_emotion": dominant_emotion,
            "raw_counts": raw_scores,
            "intensities": normalized_scores,
            "matched_keywords": matched_words,
            "has_emotional_charge": max_count > 0
        }
