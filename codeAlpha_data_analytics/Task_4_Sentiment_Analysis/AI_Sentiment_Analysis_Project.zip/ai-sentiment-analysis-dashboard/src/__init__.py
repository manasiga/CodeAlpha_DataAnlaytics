"""
AI-Based Sentiment Analysis Dashboard Package
Author: Manasi Ga (Internship Project)
Module: src
"""

__version__ = "1.0.0"
