"""
AI-Based Sentiment Analysis Dashboard
Internship Project Main Application
Author: Manasi Ga
Technologies: Python, Streamlit, Pandas, NumPy, NLTK, VADER, TextBlob, Matplotlib, Seaborn, WordCloud
"""

import streamlit as st
import pandas as pd
import numpy as np
import os
import io
import datetime

# Internal modular imports
from src.preprocessor import TextPreprocessor
from src.sentiment_analyzer import SentimentAnalyzer
from src.emotion_detector import EmotionDetector
from src.visualizer import SentimentVisualizer
from src.insights_generator import InsightsGenerator
from src.report_generator import ReportGenerator

# Page configuration
st.set_page_config(
    page_title="AI-Based Sentiment Analysis Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .main-title {
        font-size: 2.2rem;
        font-weight: 800;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 16px;
        text-align: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #1E293B;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .badge-pos {
        background-color: #DCFCE7;
        color: #166534;
        padding: 4px 10px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 0.8rem;
    }
    .badge-neg {
        background-color: #FEE2E2;
        color: #991B1B;
        padding: 4px 10px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 0.8rem;
    }
    .badge-neu {
        background-color: #F1F5F9;
        color: #475569;
        padding: 4px 10px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 0.8rem;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_nlp_engines():
    """Initializes and caches the NLP processing engines."""
    return (
        TextPreprocessor(),
        SentimentAnalyzer(),
        EmotionDetector(),
        SentimentVisualizer(),
        InsightsGenerator(),
        ReportGenerator()
    )


preprocessor, analyzer, emotion_detector, visualizer, insights_gen, report_gen = load_nlp_engines()

# Predefined datasets dictionary
DATASET_PATHS = {
    "Amazon Product Reviews (Real Dataset)": "data/amazon_reviews.csv",
    "Social Media Posts (Twitter / X)": "data/social_media_posts.csv",
    "News Articles & Financial Headlines": "data/news_headlines.csv",
    "Sample Custom Customer Reviews": "data/sample_custom_reviews.csv",
}

# ---------------------------------------------------------
# SIDEBAR CONTROLS
# ---------------------------------------------------------
st.sidebar.image("https://img.icons8.com/fluency/96/artificial-intelligence.png", width=64)
st.sidebar.title("Configuration & Data")
st.sidebar.markdown("**AI-Based Sentiment Dashboard**")
st.sidebar.caption("Internship Final Project | Manasi Ga")

data_source = st.sidebar.radio(
    "Select Dataset Source:",
    ["Preloaded Real Datasets", "Upload Custom Dataset (CSV/Excel)", "Single Text Playground"]
)

loaded_df = None
dataset_title = ""
text_col = "review_text"

if data_source == "Preloaded Real Datasets":
    selected_name = st.sidebar.selectbox("Choose Dataset:", list(DATASET_PATHS.keys()))
    file_path = DATASET_PATHS[selected_name]
    dataset_title = selected_name
    if os.path.exists(file_path):
        loaded_df = pd.read_csv(file_path)
    else:
        st.sidebar.error(f"Dataset file {file_path} not found.")

elif data_source == "Upload Custom Dataset (CSV/Excel)":
    uploaded_file = st.sidebar.file_uploader(
        "Upload CSV or Excel file",
        type=["csv", "xlsx", "xls"],
        help="Upload customer feedback, product reviews, or tweets"
    )
    if uploaded_file is not None:
        try:
            if uploaded_file.name.endswith(".csv"):
                loaded_df = pd.read_csv(uploaded_file)
            else:
                loaded_df = pd.read_excel(uploaded_file)
            dataset_title = uploaded_file.name
            st.sidebar.success(f"Loaded {len(loaded_df)} records successfully!")
        except Exception as e:
            st.sidebar.error(f"Error reading file: {e}")

st.sidebar.markdown("---")
st.sidebar.subheader("Preprocessing Options")
opt_clean_urls = st.sidebar.checkbox("Remove URLs & Links", value=True)
opt_clean_punct = st.sidebar.checkbox("Remove Punctuation", value=True)
opt_remove_stops = st.sidebar.checkbox("Remove Stopwords", value=True)
opt_lowercase = st.sidebar.checkbox("Convert to Lowercase", value=True)

st.sidebar.markdown("---")
st.sidebar.subheader("Sentiment Thresholds")
pos_threshold = st.sidebar.slider("Positive Threshold (Compound >= )", 0.01, 0.50, 0.05, 0.01)
neg_threshold = st.sidebar.slider("Negative Threshold (Compound <= )", -0.50, -0.01, -0.05, 0.01)

# ---------------------------------------------------------
# MAIN APP BODY
# ---------------------------------------------------------
st.markdown('<div class="main-title">AI-Based Sentiment Analysis Dashboard</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Multi-modal NLP classification and business intelligence for Amazon product reviews, social media streams, and news articles.</div>', unsafe_allow_html=True)

if data_source == "Single Text Playground":
    st.subheader("Interactive Single-Text NLP Inspector")
    st.markdown("Enter any product review, tweet, or sentence below to perform live real-time analysis using VADER, TextBlob, and Plutchik Emotion Lexicons.")

    sample_texts = [
        "The sound quality on this new Echo Dot is astonishingly crisp and rich with bass! Flawless setup.",
        "Terrible hinge build quality. The headband snapped after only 4 months and support refused warranty.",
        "The battery lasts around 8 hours, which is average. Screen brightness is adequate for indoor use."
    ]
    col_preset1, col_preset2, col_preset3 = st.columns(3)
    preset_choice = ""
    if col_preset1.button("Preset: Positive Review"):
        preset_choice = sample_texts[0]
    if col_preset2.button("Preset: Negative Review"):
        preset_choice = sample_texts[1]
    if col_preset3.button("Preset: Neutral Review"):
        preset_choice = sample_texts[2]

    user_input = st.text_area(
        "Text to Analyze:",
        value=preset_choice if preset_choice else sample_texts[0],
        height=100
    )

    if user_input:
        prep_result = preprocessor.preprocess_pipeline(user_input, remove_stops=opt_remove_stops)
        sent_result = analyzer.analyze_text(user_input)
        emot_result = emotion_detector.detect_emotions(user_input)

        col_m1, col_m2, col_m3, col_m4 = st.columns(4)
        sentiment_label = sent_result["sentiment"]
        badge_class = "badge-pos" if sentiment_label == "Positive" else ("badge-neg" if sentiment_label == "Negative" else "badge-neu")

        with col_m1:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Sentiment Classification</div><div class="metric-value"><span class="{badge_class}">{sentiment_label}</span></div></div>', unsafe_allow_html=True)
        with col_m2:
            st.markdown(f'<div class="metric-card"><div class="metric-label">VADER Compound Score</div><div class="metric-value">{sent_result["vader"]["compound"]:+.3f}</div></div>', unsafe_allow_html=True)
        with col_m3:
            st.markdown(f'<div class="metric-card"><div class="metric-label">TextBlob Polarity</div><div class="metric-value">{sent_result["textblob"]["polarity"]:+.3f}</div></div>', unsafe_allow_html=True)
        with col_m4:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Dominant Emotion</div><div class="metric-value" style="font-size:1.4rem;">{emot_result["dominant_emotion"]}</div></div>', unsafe_allow_html=True)

        st.markdown("### Detailed Score Breakdown")
        tab_vader, tab_textblob, tab_emotion, tab_preproc = st.tabs(["VADER Scores", "TextBlob Analysis", "Emotion Lexicons", "Preprocessing Pipeline"])

        with tab_vader:
            v_cols = st.columns(4)
            v_cols[0].metric("Positive Weight", f"{sent_result['vader']['positive']:.3f}")
            v_cols[1].metric("Neutral Weight", f"{sent_result['vader']['neutral']:.3f}")
            v_cols[2].metric("Negative Weight", f"{sent_result['vader']['negative']:.3f}")
            v_cols[3].metric("Compound Score", f"{sent_result['vader']['compound']:+.4f}")
            st.progress(max(0.0, min(1.0, (sent_result['vader']['compound'] + 1.0) / 2.0)), text="Sentiment Polarity Spectrum (-1.0 Negative to +1.0 Positive)")

        with tab_textblob:
            tb_cols = st.columns(3)
            tb_cols[0].metric("Polarity", f"{sent_result['textblob']['polarity']:+.3f}")
            tb_cols[1].metric("Subjectivity", f"{sent_result['textblob']['subjectivity']:.3f}")
            tb_cols[2].metric("Models Agreement", "Agreed" if sent_result['models_agree'] else "Divergent")
            st.caption("Subjectivity: 0.0 is entirely objective/factual, 1.0 is highly subjective/opinionated.")

        with tab_emotion:
            emot_chart = visualizer.plot_emotion_distribution(emot_result['raw_counts'])
            st.pyplot(emot_chart)
            st.write("**Matched Emotion Tokens:**", emot_result['matched_keywords'])

        with tab_preproc:
            st.write("**Raw Text:**", prep_result['raw_text'])
            st.write("**Cleaned Text:**", prep_result['cleaned_text'])
            st.write("**Filtered Tokens:**", prep_result['filtered_tokens'])
            st.caption(f"Word Count: {prep_result['raw_word_count']} raw -> {prep_result['cleaned_word_count']} cleaned ({prep_result['stopwords_removed_count']} stopwords removed).")

else:
    # Dataset Mode
    if loaded_df is None or loaded_df.empty:
        st.warning("Please select or upload a dataset using the sidebar to begin analysis.")
        st.stop()

    # Column selection
    candidate_cols = [c for c in loaded_df.columns if loaded_df[c].dtype == object or "text" in c.lower() or "review" in c.lower() or "headline" in c.lower()]
    default_index = 0
    for idx, c in enumerate(candidate_cols):
        if any(term in c.lower() for term in ["review_text", "headline", "post_text", "feedback_text", "text", "review"]):
            default_index = idx
            break

    col_select1, col_select2 = st.columns([2, 1])
    with col_select1:
        st.info(f"Target Dataset: **{dataset_title}** ({len(loaded_df)} records)")
    with col_select2:
        text_column = st.selectbox(
            "Select Text Column to Analyze:",
            options=candidate_cols if candidate_cols else loaded_df.columns,
            index=default_index if candidate_cols else 0
        )

    # Missing Value Handling
    missing_count = loaded_df[text_column].isnull().sum()
    if missing_count > 0:
        st.warning(f"Detected {missing_count} missing values in '{text_column}'. Replacing with empty strings to guarantee data integrity.")
        loaded_df[text_column] = loaded_df[text_column].fillna("")

    # RUN BATCH SENTIMENT & PREPROCESSING PIPELINE
    with st.spinner("Processing text and computing sentiment engines..."):
        # Process and classify
        clean_texts = []
        compounds = []
        pos_scores = []
        neu_scores = []
        neg_scores = []
        sentiments = []
        polarities = []
        subjectivities = []
        dominant_emotions = []

        for val in loaded_df[text_column]:
            c_text = preprocessor.clean_text(
                val,
                remove_urls=opt_clean_urls,
                remove_punctuation=opt_clean_punct,
                lowercase=opt_lowercase
            )
            vader_res = analyzer.analyze_vader(val)
            tb_res = analyzer.analyze_textblob(val)
            emot_res = emotion_detector.detect_emotions(val)

            c_score = vader_res["compound"]
            label = analyzer.classify_sentiment(c_score, positive_threshold=pos_threshold, negative_threshold=neg_threshold)

            clean_texts.append(c_text)
            compounds.append(c_score)
            pos_scores.append(vader_res["pos"])
            neu_scores.append(vader_res["neu"])
            neg_scores.append(vader_res["neg"])
            sentiments.append(label)
            polarities.append(tb_res["polarity"])
            subjectivities.append(tb_res["subjectivity"])
            dominant_emotions.append(emot_res["dominant_emotion"])

        analyzed_df = loaded_df.copy()
        analyzed_df["cleaned_text"] = clean_texts
        analyzed_df["sentiment"] = sentiments
        analyzed_df["compound"] = compounds
        analyzed_df["pos_score"] = pos_scores
        analyzed_df["neu_score"] = neu_scores
        analyzed_df["neg_score"] = neg_scores
        analyzed_df["polarity"] = polarities
        analyzed_df["subjectivity"] = subjectivities
        analyzed_df["dominant_emotion"] = dominant_emotions

    # COMPUTE SUMMARY METRICS
    total_count = len(analyzed_df)
    pos_count = int((analyzed_df["sentiment"] == "Positive").sum())
    neu_count = int((analyzed_df["sentiment"] == "Neutral").sum())
    neg_count = int((analyzed_df["sentiment"] == "Negative").sum())
    avg_compound = float(analyzed_df["compound"].mean()) if total_count > 0 else 0.0

    pos_pct = round((pos_count / total_count) * 100, 1) if total_count > 0 else 0.0
    neu_pct = round((neu_count / total_count) * 100, 1) if total_count > 0 else 0.0
    neg_pct = round((neg_count / total_count) * 100, 1) if total_count > 0 else 0.0

    metrics_dict = {
        "total_records": total_count,
        "positive_count": pos_count,
        "negative_count": neg_count,
        "neutral_count": neu_count,
        "avg_compound": avg_compound,
    }
    insights_dict = insights_gen.generate_executive_insights(metrics_dict)

    # KPI METRIC CARDS
    st.markdown("---")
    m_col1, m_col2, m_col3, m_col4, m_col5 = st.columns(5)
    with m_col1:
        st.markdown(f'<div class="metric-card"><div class="metric-label">Total Analyzed</div><div class="metric-value">{total_count}</div></div>', unsafe_allow_html=True)
    with m_col2:
        st.markdown(f'<div class="metric-card"><div class="metric-label">Positive Sentiment</div><div class="metric-value" style="color:#10B981;">{pos_count} <span style="font-size:1rem;">({pos_pct}%)</span></div></div>', unsafe_allow_html=True)
    with m_col3:
        st.markdown(f'<div class="metric-card"><div class="metric-label">Neutral Sentiment</div><div class="metric-value" style="color:#6B7280;">{neu_count} <span style="font-size:1rem;">({neu_pct}%)</span></div></div>', unsafe_allow_html=True)
    with m_col4:
        st.markdown(f'<div class="metric-card"><div class="metric-label">Negative Sentiment</div><div class="metric-value" style="color:#EF4444;">{neg_count} <span style="font-size:1rem;">({neg_pct}%)</span></div></div>', unsafe_allow_html=True)
    with m_col5:
        st.markdown(f'<div class="metric-card"><div class="metric-label">Net Sentiment Score</div><div class="metric-value" style="color:#2563EB;">{insights_dict["net_sentiment_score"]:+.1f}%</div></div>', unsafe_allow_html=True)

    # TABS FOR WORKSPACES
    tab_overview, tab_charts, tab_wordcloud, tab_records, tab_insights, tab_report = st.tabs([
        "📊 Dashboard Overview",
        "📈 Detailed Visualizations",
        "☁️ Word Cloud",
        "🔍 Data Explorer & Filter",
        "💡 Business Insights",
        "📄 Export & PDF Report"
    ])

    with tab_overview:
        c1, c2 = st.columns(2)
        with c1:
            pie_fig = visualizer.plot_sentiment_pie({"Positive": pos_count, "Neutral": neu_count, "Negative": neg_count})
            st.pyplot(pie_fig)
        with c2:
            bar_fig = visualizer.plot_sentiment_bars({"Positive": pos_count, "Neutral": neu_count, "Negative": neg_count})
            st.pyplot(bar_fig)

    with tab_charts:
        st.subheader("Statistical Distributions & Trends")
        c_trend, c_emot = st.columns(2)
        with c_trend:
            if "date" in analyzed_df.columns:
                trend_fig = visualizer.plot_sentiment_trend(analyzed_df)
                st.pyplot(trend_fig)
            else:
                st.info("Time-series trend requires a 'date' column in dataset.")

        with c_emot:
            emot_counts = analyzed_df["dominant_emotion"].value_counts().to_dict()
            emot_fig = visualizer.plot_emotion_distribution(emot_counts)
            st.pyplot(emot_fig)

        st.markdown("#### TextBlob Polarity vs Subjectivity")
        st.scatter_chart(analyzed_df, x="polarity", y="subjectivity", color="sentiment")

    with tab_wordcloud:
        st.subheader("Text Corpus Word Clouds")
        wc_filter = st.radio("Generate WordCloud for:", ["All Reviews", "Positive Only", "Negative Only"], horizontal=True)

        if wc_filter == "Positive Only":
            corpus_subset = analyzed_df[analyzed_df["sentiment"] == "Positive"]["cleaned_text"]
        elif wc_filter == "Negative Only":
            corpus_subset = analyzed_df[analyzed_df["sentiment"] == "Negative"]["cleaned_text"]
        else:
            corpus_subset = analyzed_df["cleaned_text"]

        full_corpus = " ".join(corpus_subset.dropna().tolist())
        if full_corpus.strip():
            wc_obj = visualizer.generate_wordcloud(full_corpus)
            if wc_obj:
                fig_wc, ax_wc = visualizer.plt.subplots(figsize=(10, 5))
                ax_wc.imshow(wc_obj, interpolation='bilinear')
                ax_wc.axis("off")
                st.pyplot(fig_wc)
            else:
                st.info("WordCloud library not available or wordcloud generator generated blank output.")
        else:
            st.info("No text content available for the selected filter.")

    with tab_records:
        st.subheader("Review Search & Advanced Filtering")
        f_col1, f_col2, f_col3 = st.columns([1, 1, 2])
        with f_col1:
            sent_filter = st.selectbox("Filter Sentiment:", ["All", "Positive", "Neutral", "Negative"])
        with f_col2:
            min_comp = st.slider("Minimum Compound Score:", -1.0, 1.0, -1.0, 0.1)
        with f_col3:
            search_query = st.text_input("Search in review text:", "")

        filtered_df = analyzed_df.copy()
        if sent_filter != "All":
            filtered_df = filtered_df[filtered_df["sentiment"] == sent_filter]
        filtered_df = filtered_df[filtered_df["compound"] >= min_comp]
        if search_query:
            filtered_df = filtered_df[filtered_df[text_column].str.contains(search_query, case=False, na=False)]

        st.caption(f"Displaying {len(filtered_df)} of {len(analyzed_df)} records.")
        st.dataframe(
            filtered_df[[text_column, "sentiment", "compound", "polarity", "dominant_emotion"]],
            use_container_width=True
        )

    with tab_insights:
        st.subheader("Actionable Business & Product Intelligence")
        st.markdown(f"**Brand Health Rating:** `{insights_dict['brand_health_status']}` | **Overall Public Tone:** `{insights_dict['overall_tone']}`")

        col_ins1, col_ins2 = st.columns(2)
        with col_ins1:
            st.markdown("#### 🛠️ Product Engineering Action Items")
            for item in insights_dict["product_action_items"]:
                st.markdown(f"- {item}")

            st.markdown("#### 🤝 Customer Retention & Support")
            for item in insights_dict["customer_success_items"]:
                st.markdown(f"- {item}")

        with col_ins2:
            st.markdown("#### 📣 Marketing & Growth Strategy")
            for item in insights_dict["marketing_action_items"]:
                st.markdown(f"- {item}")

    with tab_report:
        st.subheader("Download Project Deliverables")
        st.markdown("Export classified datasets with sentiment tags or generate an official PDF project summary report for academic/internship evaluation.")

        col_dl1, col_dl2 = st.columns(2)
        with col_dl1:
            csv_data = analyzed_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📥 Download Classified CSV Data",
                data=csv_data,
                file_name=f"sentiment_classified_{dataset_title.replace(' ', '_')}.csv",
                mime="text/csv",
                use_container_width=True
            )

        with col_dl2:
            pdf_bytes = report_gen.generate_pdf_report(
                dataset_name=dataset_title,
                metrics=metrics_dict,
                insights=insights_dict
            )
            st.download_button(
                label="📄 Download Official PDF Report",
                data=pdf_bytes,
                file_name=f"Sentiment_Analysis_Report_{datetime.date.today()}.pdf",
                mime="application/pdf",
                use_container_width=True
            )

st.markdown("---")
st.caption("AI-Based Sentiment Analysis Dashboard | Internship Project | Developed with Python, Streamlit, Pandas, NLTK, VADER & TextBlob")
