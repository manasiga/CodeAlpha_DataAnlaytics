"""
data_loader.py
==============
Everything related to getting a CSV file into a pandas DataFrame, plus a helper
that works out what "role" each column can play in a chart.

Design rules (important for honest analysis):
  * We NEVER invent data and NEVER fill in missing values.
  * Missing values stay missing (NaN). Each chart simply skips the rows that
    are missing the columns it needs, and says so.
  * The only change made while loading is converting obvious date columns
    (column name contains "date" or "time") to real datetimes.
"""
from __future__ import annotations

import warnings
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from pandas.api.types import (
    is_bool_dtype,
    is_datetime64_any_dtype,
    is_numeric_dtype,
)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
DEFAULT_DATASET = DATA_DIR / "books_data.csv"

# Encodings are tried in this order until one works.
_ENCODINGS = ("utf-8", "utf-8-sig", "cp1252", "latin-1")


class DataLoadError(Exception):
    """Raised with a friendly, beginner-readable message when a CSV cannot be loaded."""


# --------------------------------------------------------------------------- #
# Finding / reading the dataset
# --------------------------------------------------------------------------- #
def find_default_dataset() -> Optional[Path]:
    """Return the bundled dataset path, or None if there is no CSV in /data."""
    if DEFAULT_DATASET.exists():
        return DEFAULT_DATASET
    if DATA_DIR.exists():
        csvs = sorted(DATA_DIR.glob("*.csv"))
        if csvs:
            return csvs[0]
    return None


def load_csv(source) -> pd.DataFrame:
    """
    Read a CSV from a file path or a file-like object (e.g. a Streamlit upload).

    Raises DataLoadError with a clear message if the file is empty, unreadable
    or has no data rows.
    """
    df = None
    last_error: Optional[Exception] = None

    for encoding in _ENCODINGS:
        try:
            if hasattr(source, "seek"):
                source.seek(0)
            df = pd.read_csv(source, encoding=encoding)
            # A single column often means the delimiter is ";" or a tab.
            if df.shape[1] == 1:
                if hasattr(source, "seek"):
                    source.seek(0)
                sniffed = pd.read_csv(source, encoding=encoding, sep=None, engine="python")
                if sniffed.shape[1] > 1:
                    df = sniffed
            break
        except UnicodeDecodeError as exc:
            last_error = exc
            continue
        except pd.errors.EmptyDataError:
            raise DataLoadError("The file is empty. Please choose a CSV that contains data.")
        except pd.errors.ParserError as exc:
            raise DataLoadError(f"The file could not be parsed as a CSV: {exc}")
        except Exception as exc:  # pragma: no cover - unexpected problems
            raise DataLoadError(f"Could not read the file: {exc}")

    if df is None:
        raise DataLoadError(f"Could not decode the file with common encodings ({last_error}).")
    if df.shape[1] == 0 or df.shape[0] == 0:
        raise DataLoadError("The CSV has no data rows. Please check the file.")

    df.columns = [str(c).strip() for c in df.columns]
    return _convert_date_columns(df)


def _convert_date_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Convert text columns that clearly hold dates (>=95% parse) to datetime."""
    for col in df.columns:
        s = df[col]
        if is_numeric_dtype(s) or is_bool_dtype(s) or is_datetime64_any_dtype(s):
            continue
        name = col.lower()
        if "date" not in name and "time" not in name:
            continue
        non_null = s.notna().sum()
        if non_null == 0:
            continue
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parsed = pd.to_datetime(s, errors="coerce")
        if parsed.notna().sum() >= 0.95 * non_null:
            df[col] = parsed
    return df


# --------------------------------------------------------------------------- #
# Column roles
# --------------------------------------------------------------------------- #
def column_roles(df: pd.DataFrame) -> Dict[str, List[str]]:
    """
    Work out which columns are suitable for which chart controls.

    Returned keys (all lists of column names, in the original column order):
      numeric        numbers (not booleans)
      boolean        True/False columns
      datetime       date/time columns
      text_cols      everything that is not numeric / boolean / datetime
      id_like        text columns where almost every value is different
                     (titles, URLs, IDs) - useless as chart categories
      continuous     numeric columns with more than 12 distinct values
      low_card_numeric  numeric columns with 12 or fewer distinct values
                     (e.g. a 1-5 star rating) - can act like categories
      group_cols     columns good for colour / grouping / filters (2-30 values)
      category_cols  columns good for bar / pie categories
    """
    n = len(df)
    numeric: List[str] = []
    boolean: List[str] = []
    datetime_cols: List[str] = []
    text_cols: List[str] = []

    for c in df.columns:
        s = df[c]
        if is_bool_dtype(s):
            boolean.append(c)
        elif is_numeric_dtype(s):
            numeric.append(c)
        elif is_datetime64_any_dtype(s):
            datetime_cols.append(c)
        else:
            text_cols.append(c)

    nunique: Dict[str, int] = {}
    for c in df.columns:
        try:
            nunique[c] = int(df[c].nunique(dropna=True))
        except TypeError:  # unhashable values
            nunique[c] = n

    id_like = [c for c in text_cols if nunique[c] > 20 and nunique[c] > 0.5 * n]
    continuous = [c for c in numeric if nunique[c] > 12]
    low_card_numeric = [c for c in numeric if 1 <= nunique[c] <= 12]

    group_cols: List[str] = []
    category_cols: List[str] = []
    for c in df.columns:
        is_text_cat = c in text_cols and c not in id_like
        is_cat = is_text_cat or c in boolean or c in low_card_numeric
        if is_cat and nunique[c] >= 1:
            category_cols.append(c)
        if is_cat and 2 <= nunique[c] <= 30:
            group_cols.append(c)

    return {
        "numeric": numeric,
        "boolean": boolean,
        "datetime": datetime_cols,
        "text_cols": text_cols,
        "id_like": id_like,
        "continuous": continuous,
        "low_card_numeric": low_card_numeric,
        "group_cols": group_cols,
        "category_cols": category_cols,
    }
