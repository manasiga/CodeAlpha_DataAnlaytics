"""
charts_plotly.py
================
Interactive charts (zoom, hover, pan) built with Plotly Express.

Every function takes the DataFrame plus the chart settings and returns a Plotly
Figure. All functions accept **_ignored so the same settings dictionary can be
passed to both this module and charts_static.py.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import plotly.express as px
import plotly.graph_objects as go

from . import chart_data as cd


def _finish(fig: go.Figure, title: str, height: int = 520) -> go.Figure:
    fig.update_layout(title=dict(text=title, x=0.01), height=height,
                      margin=dict(l=40, r=20, t=70, b=40), legend_title_text="")
    return fig


# --------------------------------------------------------------------------- #
def bar_chart(df, cat, value=None, agg="count", sort="value", top_n=20,
              orientation="v", **_ignored) -> go.Figure:
    data, total = cd.prep_aggregate(df, cat, value, agg, sort, top_n)
    if data.empty:
        raise ValueError("There is no data to show for this selection.")
    ylabel = cd.metric_label(agg, value)
    fmt = "%{x:,}" if (orientation == "h" and agg == "count") else \
          "%{x:,.2f}" if orientation == "h" else \
          "%{y:,}" if agg == "count" else "%{y:,.2f}"
    labels = list(data["label"])
    if orientation == "h":
        fig = px.bar(data, x="value", y="label", orientation="h",
                     labels={"label": cat, "value": ylabel})
        fig.update_yaxes(type="category", categoryorder="array",
                         categoryarray=labels, autorange="reversed")
    else:
        fig = px.bar(data, x="label", y="value", labels={"label": cat, "value": ylabel})
        fig.update_xaxes(type="category", categoryorder="array", categoryarray=labels)
    fig.update_traces(texttemplate=fmt, textposition="outside", cliponaxis=False)
    return _finish(fig, cd.chart_title("bar", cat=cat, value=value, agg=agg))


def line_chart(df, x, y=None, agg="mean", group=None, markers=True, **_ignored) -> go.Figure:
    data, order = cd.prep_line(df, x, y, agg, group)
    ylabel = cd.metric_label(agg, y)
    fig = px.line(
        data, x="x", y="value", color="group" if group else None, markers=bool(markers),
        category_orders={"group": order} if group else None,
        labels={"x": x, "value": ylabel, "group": group or ""},
    )
    return _finish(fig, cd.chart_title("line", x=x, y=y, agg=agg, group=group))


def pie_chart(df, cat, value=None, agg="count", top_n=8, sort="value",
              donut=False, **_ignored) -> go.Figure:
    data, note = cd.prep_pie(df, cat, value, agg, top_n, sort)
    fig = px.pie(data, names="label", values="value", hole=0.45 if donut else 0)
    fig.update_traces(sort=False, direction="clockwise", textinfo="percent",
                      textposition="auto",
                      hovertemplate="%{label}<br>%{value:,.2f} (%{percent})<extra></extra>")
    fig.update_layout(uniformtext_minsize=10, uniformtext_mode="hide")
    title = cd.chart_title("pie", cat=cat, value=value, agg=agg)
    if note:
        title += f"<br><sup>{note}</sup>"
    return _finish(fig, title)


def hist_chart(df, col, bins=30, group=None, histnorm="count", marginal=None,
               **_ignored) -> go.Figure:
    data, order, dropped = cd.prep_hist(df, col, group)
    fig = px.histogram(
        data, x="x", nbins=int(bins), color="group" if group else None,
        histnorm="percent" if histnorm == "percent" else None,
        marginal=marginal if marginal in ("box", "violin", "rug") else None,
        opacity=0.75 if group else 1.0, barmode="overlay" if group else "relative",
        category_orders={"group": order} if group else None,
        labels={"x": col, "group": group or ""},
    )
    fig.update_layout(bargap=0.04, yaxis_title="Percent of rows" if histnorm == "percent" else "Count")
    fig.update_xaxes(title_text=col, row=1, col=1)
    title = cd.chart_title("hist", col=col, group=group)
    if dropped:
        title += f"<br><sup>{dropped:,} rows with missing values were skipped.</sup>"
    return _finish(fig, title)


def scatter_chart(df, x, y, color=None, size=None, trendline=True, opacity=0.65,
                  hover_name=None, max_points=20000, **_ignored) -> go.Figure:
    data, info = cd.prep_scatter(df, x, y, color, size, hover_name, int(max_points))
    fig = px.scatter(
        data, x="x", y="y",
        color="color" if color else None,
        size="size" if size else None,
        hover_name="hover" if "hover" in data.columns else None,
        opacity=float(opacity),
        category_orders={"color": info["color_order"]} if color else None,
        labels={"x": x, "y": y, "color": color or "", "size": size or ""},
    )
    if trendline and info["fit"]:
        slope, intercept, r = info["fit"]
        xs = np.array([data["x"].min(), data["x"].max()])
        fig.add_trace(go.Scatter(
            x=xs, y=slope * xs + intercept, mode="lines",
            name=f"Linear trend (r = {r:.2f})",
            line=dict(color="#444444", dash="dash", width=2),
        ))
    title = cd.chart_title("scatter", x=x, y=y)
    if info["sampled"]:
        title += f"<br><sup>Showing a random sample of {info['n']:,} points.</sup>"
    return _finish(fig, title)


def box_chart(df, y, group=None, points="outliers", **_ignored) -> go.Figure:
    data, order = cd.prep_box(df, y, group)
    pts = {"outliers": "outliers", "all": "all", "none": False}.get(points, "outliers")
    fig = px.box(
        data, y="y", x="group" if group else None, color="group" if group else None,
        points=pts, category_orders={"group": order} if group else None,
        labels={"y": y, "group": group or ""},
    )
    if group:
        fig.update_xaxes(title_text=group, type="category")
        fig.update_layout(showlegend=False)
    return _finish(fig, cd.chart_title("box", y=y, group=group))


_BUILDERS = {
    "bar": bar_chart, "line": line_chart, "pie": pie_chart,
    "hist": hist_chart, "scatter": scatter_chart, "box": box_chart,
}


def build(kind: str, df, **params: Any) -> go.Figure:
    """Build any chart by name: build('bar', df, cat='rating_stars')."""
    if kind not in _BUILDERS:
        raise ValueError(f"Unknown chart type '{kind}'.")
    return _BUILDERS[kind](df, **params)


def to_html_bytes(fig: go.Figure, full_offline: bool = True) -> bytes:
    """Standalone interactive HTML file. full_offline=True embeds Plotly (about 4 MB)."""
    export = go.Figure(fig)
    export.update_layout(template="plotly_white")
    html = export.to_html(include_plotlyjs=True if full_offline else "cdn", full_html=True)
    return html.encode("utf-8")
