"""
exports.py
==========
Helpers that turn charts and analysis results into downloadable files.
"""
from __future__ import annotations

import io
import zipfile
from datetime import datetime
from typing import Dict, List, Optional

import pandas as pd

from . import analysis as an
from . import charts_plotly as cp
from . import charts_static as cs
from . import chart_data as cd


def df_to_csv_bytes(df: pd.DataFrame, index: bool = False) -> bytes:
    return df.to_csv(index=index).encode("utf-8")


def analysis_markdown(df: pd.DataFrame, source_name: str, insights: List[str],
                      filters: Optional[List[str]] = None, total_rows: Optional[int] = None) -> str:
    """A human-readable text report of the analysis (Markdown format)."""
    ov = an.dataset_overview(df)
    lines = [
        "# Book Data Analysis Results",
        "",
        f"- Source file: {source_name}",
        f"- Generated: {datetime.now():%Y-%m-%d %H:%M}",
        f"- Rows analysed: {ov['rows']:,}" + (f" (of {total_rows:,} in the full file)"
                                              if total_rows and total_rows != ov['rows'] else ""),
        f"- Columns: {ov['columns']}",
        f"- Missing cells: {ov['missing_cells']:,}",
        f"- Duplicate rows: {ov['duplicate_rows']:,}",
    ]
    if filters:
        lines += ["", "## Filters applied", ""] + [f"- {f}" for f in filters]
    lines += ["", "## Key insights", ""] + [f"- {t}" for t in insights]
    for title, table in (
        ("Column summary", an.column_summary(df)),
        ("Numeric summary", an.numeric_summary(df)),
        ("Text / category summary", an.categorical_summary(df)),
    ):
        if table is not None and not table.empty:
            lines += ["", f"## {title}", "", table.to_csv(index=False).strip()]
    lines += ["", "_Missing values were never filled in; charts skip rows that lack the needed values._"]
    return "\n".join(lines)


def analysis_tables(df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """All summary tables, ready to save as CSV files."""
    tables: Dict[str, pd.DataFrame] = {
        "column_summary": an.column_summary(df),
        "numeric_summary": an.numeric_summary(df),
        "categorical_summary": an.categorical_summary(df),
    }
    corr = an.correlation_matrix(df, "pearson")
    if corr is not None:
        tables["correlation_pearson"] = corr.reset_index().rename(columns={"index": "column"})
    return {k: v for k, v in tables.items() if v is not None and not v.empty}


def build_zip(df: pd.DataFrame, specs: Dict[str, Optional[dict]], source_name: str,
              insights: List[str], filters: Optional[List[str]] = None,
              total_rows: Optional[int] = None) -> bytes:
    """
    ZIP containing: every valid chart as PNG + interactive HTML, all summary tables
    as CSV, the filtered data as CSV and the insights report.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        skipped: List[str] = []
        for kind in cd.KINDS:
            params = specs.get(kind)
            if not params:
                continue
            try:
                zf.writestr(f"charts/{kind}_chart.png", cs.render_png(kind, df, params))
                zf.writestr(f"charts/{kind}_chart.html",
                            cp.to_html_bytes(cp.build(kind, df, **params), full_offline=False))
            except Exception as exc:  # keep going even if one chart cannot be drawn
                skipped.append(f"{cd.KIND_NAMES[kind]}: {exc}")
        corr_fig = cs.correlation_figure(df)
        if corr_fig is not None:
            zf.writestr("charts/correlation_heatmap.png", cs.fig_to_png_bytes(corr_fig))
        for name, table in analysis_tables(df).items():
            zf.writestr(f"analysis/{name}.csv", df_to_csv_bytes(table))
        zf.writestr("analysis/filtered_data.csv", df_to_csv_bytes(df))
        report = analysis_markdown(df, source_name, insights, filters, total_rows)
        if skipped:
            report += "\n\n## Charts that could not be drawn\n\n" + "\n".join(f"- {s}" for s in skipped)
        zf.writestr("analysis/analysis_report.md", report)
        zf.writestr("README.txt",
                    "Exported from the Interactive Book Data Visualization Dashboard.\n"
                    "charts/    PNG images + interactive HTML (HTML files need internet to load Plotly).\n"
                    "analysis/  CSV tables and a Markdown report. filtered_data.csv holds the rows "
                    "that were selected by the sidebar filters when you exported.\n")
    return buf.getvalue()
