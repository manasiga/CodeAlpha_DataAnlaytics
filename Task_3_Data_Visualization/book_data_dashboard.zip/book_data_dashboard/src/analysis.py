"""
analysis.py
===========
Dataset summaries and statistical insights.

Everything here is computed from the real data that is loaded. Insights are
written as plain-English sentences, and every number in them comes straight
from a calculation - nothing is hard-coded or invented.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from pandas.api.types import is_bool_dtype, is_numeric_dtype

from . import data_loader as dl
from .chart_data import VALUE_PREFS, fmt_label, fmt_num, iqr_fences, pick_column, _strength


# --------------------------------------------------------------------------- #
# Overview + tables
# --------------------------------------------------------------------------- #
def dataset_overview(df: pd.DataFrame) -> Dict[str, object]:
    return {
        "rows": int(len(df)),
        "columns": int(df.shape[1]),
        "missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "memory_kb": float(df.memory_usage(deep=True).sum() / 1024),
        "numeric_columns": int(len(dl.column_roles(df)["numeric"])),
        "text_columns": int(len(dl.column_roles(df)["text_cols"])),
    }


def column_summary(df: pd.DataFrame) -> pd.DataFrame:
    """One row per column: type, missing values, unique values, an example value."""
    rows = []
    n = len(df)
    for c in df.columns:
        s = df[c]
        non_null = s.dropna()
        example = str(non_null.iloc[0])[:60] if len(non_null) else ""
        rows.append({
            "Column": c,
            "Type": str(s.dtype),
            "Non-null": int(s.notna().sum()),
            "Missing": int(s.isna().sum()),
            "Missing %": round(100 * s.isna().sum() / n, 2) if n else 0.0,
            "Unique": int(s.nunique(dropna=True)),
            "Example": example,
        })
    return pd.DataFrame(rows)


def numeric_summary(df: pd.DataFrame) -> pd.DataFrame:
    """describe() plus median, skewness, kurtosis and IQR-outlier counts."""
    cols = [c for c in df.columns if is_numeric_dtype(df[c]) and not is_bool_dtype(df[c])]
    if not cols:
        return pd.DataFrame()
    rows = []
    for c in cols:
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        if s.empty:
            continue
        lo, hi = iqr_fences(s)
        rows.append({
            "Column": c,
            "Count": int(s.count()),
            "Mean": s.mean(),
            "Std": s.std(),
            "Min": s.min(),
            "25%": s.quantile(0.25),
            "Median": s.median(),
            "75%": s.quantile(0.75),
            "Max": s.max(),
            "Skew": s.skew() if len(s) > 2 else np.nan,
            "Kurtosis": s.kurt() if len(s) > 3 else np.nan,
            "Outliers (IQR)": int(((s < lo) | (s > hi)).sum()),
        })
    return pd.DataFrame(rows).round(3)


def categorical_summary(df: pd.DataFrame) -> pd.DataFrame:
    """For non-numeric columns: distinct values, most common value and its share."""
    rows = []
    for c in df.columns:
        s = df[c]
        if is_numeric_dtype(s) and not is_bool_dtype(s):
            continue
        counts = s.value_counts(dropna=True)
        if counts.empty:
            continue
        rows.append({
            "Column": c,
            "Unique": int(s.nunique(dropna=True)),
            "Most common": str(counts.index[0])[:70],
            "Count": int(counts.iloc[0]),
            "Share %": round(100 * counts.iloc[0] / s.notna().sum(), 2),
        })
    return pd.DataFrame(rows)


def correlation_matrix(df: pd.DataFrame, method: str = "pearson") -> Optional[pd.DataFrame]:
    from .charts_static import cd_corr
    corr = cd_corr(df, method)
    return None if corr is None else corr.round(3)


def group_summary(df: pd.DataFrame, group: str, value: str) -> pd.DataFrame:
    """count / mean / median / std / min / max of `value` for each `group`."""
    d = pd.DataFrame({"group": df[group].map(lambda v: "(missing)" if pd.isna(v) else v),
                      "v": pd.to_numeric(df[value], errors="coerce")}).dropna(subset=["v"])
    out = d.groupby("group")["v"].agg(["count", "mean", "median", "std", "min", "max"])
    out.index.name = group
    return out.round(3).reset_index()


# --------------------------------------------------------------------------- #
# Insights
# --------------------------------------------------------------------------- #
def _skew_text(skew: float) -> str:
    if np.isnan(skew):
        return ""
    if abs(skew) < 0.5:
        return "roughly symmetric"
    return "right-skewed (a few unusually high values)" if skew > 0 else \
           "left-skewed (a few unusually low values)"


def _is_index_like(s: pd.Series) -> bool:
    """True for a column that is just 0,1,2,... or 1,2,3,... (a row counter)."""
    if not is_numeric_dtype(s) or s.isna().any() or len(s) < 3:
        return False
    v = s.to_numpy()
    return bool(np.all(np.diff(v) == 1)) and float(v[0]) in (0.0, 1.0)


def generate_insights(df: pd.DataFrame) -> List[str]:
    """Plain-English findings calculated from the (possibly filtered) data."""
    out: List[str] = []
    n = len(df)
    if n == 0:
        return ["There are no rows to analyse."]
    r = dl.column_roles(df)
    ov = dataset_overview(df)

    out.append(f"The data has {n:,} rows and {df.shape[1]} columns "
               f"({len(r['numeric'])} numeric, {len(r['text_cols'])} text"
               f"{', ' + str(len(r['datetime'])) + ' date' if r['datetime'] else ''}"
               f"{', ' + str(len(r['boolean'])) + ' true/false' if r['boolean'] else ''}).")

    miss = df.isna().sum()
    miss = miss[miss > 0].sort_values(ascending=False)
    if miss.empty:
        out.append("There are no missing values in any column.")
    else:
        parts = [f"{c} ({int(v):,}, {100 * v / n:.1f}%)" for c, v in miss.head(4).items()]
        out.append(f"{len(miss)} column(s) have missing values, most notably: " + "; ".join(parts) +
                   ". Missing values were left as they are (never filled in).")

    if ov["duplicate_rows"]:
        out.append(f"{ov['duplicate_rows']:,} rows are exact duplicates of another row.")
    else:
        out.append("There are no exact duplicate rows.")

    repeated = []
    for c in r["text_cols"]:
        u = df[c].nunique(dropna=True)
        if 0.9 * n <= u < df[c].notna().sum():
            repeated.append(f"'{c}' ({int(df[c].notna().sum() - u):,} repeated value(s))")
    if repeated:
        out.append("Columns that are almost unique but contain repeats: " + ", ".join(repeated[:3]) + ".")

    constant = [c for c in df.columns if df[c].nunique(dropna=True) == 1]
    if constant:
        out.append("Columns with only one distinct value (no variation, so not useful for "
                   "comparisons): " + ", ".join(constant) + ".")

    # numeric columns
    shown = 0
    for c in r["numeric"]:
        if shown >= 4:
            break
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        if s.empty or s.nunique() < 2 or _is_index_like(df[c]):
            continue
        lo, hi = iqr_fences(s)
        n_out = int(((s < lo) | (s > hi)).sum())
        sk = s.skew() if len(s) > 2 else np.nan
        txt = (f"{c}: mean {fmt_num(s.mean())}, median {fmt_num(s.median())}, "
               f"range {fmt_num(s.min())} to {fmt_num(s.max())}, standard deviation {fmt_num(s.std())}")
        st = _skew_text(sk)
        if st:
            txt += f"; the distribution is {st}"
        txt += f"; {n_out:,} outlier(s) by the 1.5xIQR rule." if n_out else "; no outliers by the 1.5xIQR rule."
        out.append(txt)
        shown += 1

    # categorical columns
    shown = 0
    for c in r["group_cols"]:
        if shown >= 2:
            break
        vc = df[c].value_counts(dropna=True)
        if vc.empty:
            continue
        top, cnt = vc.index[0], int(vc.iloc[0])
        out.append(f"{c}: {len(vc)} distinct values; the most common is '{top}' "
                   f"({cnt:,} rows, {100 * cnt / df[c].notna().sum():.1f}% of non-missing).")
        shown += 1

    # correlation
    from .charts_static import cd_corr
    corr = cd_corr(df, "pearson")
    if corr is not None:
        cols = [c for c in corr.columns if not _is_index_like(df[c])]
        best, pair = 0.0, None
        for i, a in enumerate(cols):
            for b in cols[i + 1:]:
                v = corr.loc[a, b]
                if pd.notna(v) and abs(v) > abs(best):
                    best, pair = float(v), (a, b)
        if pair:
            out.append(f"Strongest linear relationship between numeric columns: {pair[0]} and "
                       f"{pair[1]} (Pearson r = {best:.2f}, {_strength(best)}). "
                       "Correlation shows association only - not cause and effect.")

    # group comparison: first grouping column x the main value column (e.g. price)
    if r["group_cols"]:
        g = r["group_cols"][0]
        pool = [c for c in (r["continuous"] or []) if c != g]
        main_value = pick_column(pool, VALUE_PREFS) if pool else None
        for v in ([main_value] if main_value else []):
            tbl = group_summary(df, g, v)
            tbl = tbl[tbl["count"] >= 5]
            if len(tbl) >= 2:
                hi = tbl.loc[tbl["mean"].idxmax()]
                lo = tbl.loc[tbl["mean"].idxmin()]
                out.append(f"Average {v} by {g}: highest for {g} = {fmt_label(hi[g])} ({fmt_num(hi['mean'])}), "
                           f"lowest for {g} = {fmt_label(lo[g])} ({fmt_num(lo['mean'])}); "
                           f"gap = {fmt_num(hi['mean'] - lo['mean'])} "
                           f"(groups with fewer than 5 rows are ignored).")
    return out
