"""
report.py
=========
Builds the PDF report from the real data (all numbers and charts are computed
at the moment the report is generated - nothing is pre-written).

Used in two places:
  * generate_report.py  -> makes reports/Book_Data_Visualization_Report.pdf
  * the dashboard's "Downloads" tab -> report for the currently filtered data
"""
from __future__ import annotations

import io
from datetime import datetime
from typing import Dict, List, Optional
from xml.sax.saxutils import escape

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

from . import analysis as an
from . import chart_data as cd
from . import charts_static as cs

NAVY = colors.HexColor("#1F3A5F")
LIGHT = colors.HexColor("#EEF2F7")
GRID = colors.HexColor("#C9D2DE")

_base = getSampleStyleSheet()
STYLES = {
    "title": ParagraphStyle("t", parent=_base["Title"], fontSize=26, leading=32, textColor=NAVY,
                            alignment=TA_CENTER, spaceAfter=10),
    "subtitle": ParagraphStyle("st", parent=_base["Normal"], fontSize=13, leading=18,
                               alignment=TA_CENTER, textColor=colors.HexColor("#555555")),
    "h1": ParagraphStyle("h1", parent=_base["Heading1"], fontSize=16, leading=20, textColor=NAVY,
                         spaceBefore=14, spaceAfter=8, keepWithNext=1),
    "h2": ParagraphStyle("h2", parent=_base["Heading2"], fontSize=12, leading=15, textColor=NAVY,
                         spaceBefore=8, spaceAfter=4, keepWithNext=1),
    "body": ParagraphStyle("b", parent=_base["BodyText"], fontSize=10, leading=14, spaceAfter=6),
    "bullet": ParagraphStyle("bl", parent=_base["BodyText"], fontSize=10, leading=14,
                             leftIndent=14, bulletIndent=2, spaceAfter=3),
    "caption": ParagraphStyle("c", parent=_base["BodyText"], fontSize=8.5, leading=11,
                              textColor=colors.HexColor("#444444"), spaceAfter=10),
    "small": ParagraphStyle("sm", parent=_base["BodyText"], fontSize=8, leading=10),
}


def _p(text: str, style: str = "body") -> Paragraph:
    return Paragraph(escape(str(text)), STYLES[style])


def _bullets(items: List[str]) -> List[Paragraph]:
    return [Paragraph(escape(t), STYLES["bullet"], bulletText="\u2022") for t in items]


def _table(df: pd.DataFrame, col_widths: Optional[List[float]] = None, font: float = 8,
           max_chars: int = 28) -> Table:
    def cell(v):
        if isinstance(v, float):
            return cd.fmt_num(v, 2)
        return str(v)[:max_chars]

    data = [list(map(str, df.columns))] + [[cell(v) for v in row] for row in df.itertuples(index=False)]
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), font),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("GRID", (0, 0), (-1, -1), 0.4, GRID),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return t


def _png_image(png: bytes, max_w: float, max_h: float) -> Image:
    w, h = ImageReader(io.BytesIO(png)).getSize()
    scale = min(max_w / w, max_h / h)
    return Image(io.BytesIO(png), width=w * scale, height=h * scale)


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#777777"))
    canvas.drawString(2 * cm, 1.1 * cm, "Interactive Book Data Visualization Dashboard - Report")
    canvas.drawRightString(A4[0] - 2 * cm, 1.1 * cm, f"Page {doc.page}")
    canvas.restoreState()


def build_pdf(
    df: pd.DataFrame,
    source_name: str,
    specs: Optional[Dict[str, Optional[dict]]] = None,
    insights: Optional[List[str]] = None,
    filters: Optional[List[str]] = None,
    total_rows: Optional[int] = None,
) -> bytes:
    """Return the finished PDF as bytes."""
    if df is None or df.empty:
        raise ValueError("There is no data to put in a report.")
    specs = specs or cd.default_specs(df)
    insights = insights if insights is not None else an.generate_insights(df)
    ov = an.dataset_overview(df)
    page_w = A4[0] - 4 * cm

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=2 * cm, bottomMargin=2 * cm,
                            title="Interactive Book Data Visualization Report",
                            author="Book Data Visualization Dashboard")
    s: list = []

    # ---- cover ----------------------------------------------------------- #
    s += [Spacer(1, 5 * cm), _p("Interactive Book Data Visualization Dashboard", "title"),
          _p("Project Report", "subtitle"), Spacer(1, 1 * cm),
          _p(f"Dataset: {source_name}", "subtitle"),
          _p(f"{ov['rows']:,} rows  |  {ov['columns']} columns", "subtitle"),
          _p(f"Generated on {datetime.now():%d %B %Y}", "subtitle"), Spacer(1, 3 * cm),
          _p("Python  |  Pandas  |  NumPy  |  Matplotlib  |  Seaborn  |  Plotly  |  Streamlit",
             "subtitle"), PageBreak()]

    # ---- 1. introduction ------------------------------------------------- #
    s += [_p("1. Introduction", "h1"),
          _p("This report accompanies an interactive dashboard that turns a CSV file of book "
             "data into charts, summary statistics and downloadable results. The dashboard "
             "uses only the real data in the file: it never creates sample data and never fills "
             "in missing values. Rows that lack a value needed for a chart are skipped for that "
             "chart only."),
          _p("Main features: bar, line, pie, histogram, scatter and box charts; dataset summary "
             "and statistical insights; interactive sidebar filters; a CSV upload option; and "
             "downloads for charts (PNG / HTML), tables (CSV), a Markdown analysis report, a PDF "
             "report and a ZIP bundle.")]
    if filters:
        s += [_p("Filters applied to this report", "h2")] + _bullets(filters)
        if total_rows:
            s.append(_p(f"{ov['rows']:,} of {total_rows:,} rows are included."))

    # ---- 2. dataset overview -------------------------------------------- #
    overview = pd.DataFrame({
        "Measure": ["Rows", "Columns", "Numeric columns", "Text columns", "Missing cells",
                    "Duplicate rows", "Memory (KB)"],
        "Value": [f"{ov['rows']:,}", ov["columns"], ov["numeric_columns"], ov["text_columns"],
                  f"{ov['missing_cells']:,}", f"{ov['duplicate_rows']:,}", f"{ov['memory_kb']:,.1f}"],
    })
    s += [_p("2. Dataset Overview", "h1"),
          _table(overview, [6 * cm, 4 * cm], font=9), Spacer(1, 10),
          _p("Column summary", "h2"),
          _table(an.column_summary(df).drop(columns=["Example"]),
                 [4 * cm, 2.2 * cm, 2.2 * cm, 2 * cm, 2.2 * cm, 2.2 * cm], font=8)]

    # ---- 3. statistics --------------------------------------------------- #
    s.append(_p("3. Statistical Summary", "h1"))
    num = an.numeric_summary(df)
    if not num.empty:
        show = num[["Column", "Count", "Mean", "Std", "Min", "25%", "Median", "75%", "Max", "Skew"]]
        s += [_p("Numeric columns", "h2"),
              _table(show, [2.9 * cm] + [1.6 * cm] * 9, font=7.5, max_chars=16)]
    cat = an.categorical_summary(df)
    if not cat.empty:
        s += [Spacer(1, 8), _p("Text and true/false columns", "h2"),
              _table(cat, [3 * cm, 1.6 * cm, 7.2 * cm, 1.6 * cm, 1.8 * cm], font=7.5, max_chars=55)]

    # ---- 4. visualizations ----------------------------------------------- #
    s += [Spacer(1, 6), _p("4. Visualizations", "h1"),
          _p("Each chart below is drawn from the data with Matplotlib and Seaborn. The "
             "dashboard shows interactive Plotly versions of the same charts.")]
    figure_no = 0
    for kind in cd.KINDS:
        params = specs.get(kind)
        if not params:
            continue
        try:
            png = cs.render_png(kind, df, params, dpi=130)
        except Exception as exc:
            s.append(_p(f"{cd.KIND_NAMES[kind]} could not be drawn: {exc}", "small"))
            continue
        figure_no += 1
        caption = cd.describe_chart(kind, df, params)
        s.append(KeepTogether([
            _p(f"4.{figure_no} {cd.KIND_NAMES[kind]}", "h2"),
            _png_image(png, page_w, 8.6 * cm),
            _p(f"Figure {figure_no}. {caption}", "caption"),
        ]))
    heat = cs.correlation_figure(df)
    if heat is not None:
        figure_no += 1
        s.append(KeepTogether([
            _p(f"4.{figure_no} Correlation heatmap", "h2"),
            _png_image(cs.fig_to_png_bytes(heat, dpi=130), page_w * 0.8, 9 * cm),
            _p(f"Figure {figure_no}. Pearson correlation between numeric columns that vary.", "caption"),
        ]))

    # ---- 5. insights ----------------------------------------------------- #
    s += [_p("5. Key Insights", "h1"),
          _p("Every statement below was calculated from the data when this report was generated.")]
    s += _bullets(insights)

    # ---- 6. method ------------------------------------------------------- #
    s += [_p("6. Methodology and Tools", "h1")]
    s += _bullets([
        "Pandas reads the CSV and builds all summaries; NumPy supports the calculations.",
        "Plotly draws the interactive charts; Matplotlib and Seaborn draw the downloadable images.",
        "Streamlit provides the dashboard, filters and download buttons.",
        "Outliers use the 1.5 x IQR rule. Correlation uses Pearson's r (Spearman is available in the app).",
        "Category labels that are missing are shown as '(missing)'; numeric gaps are left empty, never filled.",
    ])

    # ---- 7. limitations -------------------------------------------------- #
    s += [_p("7. Limitations and Notes", "h1")]
    s += _bullets([
        "Results describe only the rows in the file (or the rows left after filtering); they do not "
        "necessarily describe all books everywhere.",
        "Correlations show association, not cause and effect.",
        "If the file has a column such as page_number, it is the position in the source listing, "
        "not a date, so line charts over it show order in the listing, not time.",
        "Columns where every value is the same show no variation and cannot be compared.",
    ])

    doc.build(s, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()
