"""
filters.py
==========
Builds the interactive sidebar filters and applies them to the data.

Filters are created automatically from the columns that exist:
  * numeric columns with many values  -> range slider
  * date columns                       -> date range slider
  * text / low-count number columns    -> multi-select box
  * one text column                    -> "contains" search box

A filter only affects the data when you change it from its default. (So rows
with missing values are only removed if you actually narrow that filter.)
"""
from __future__ import annotations

from typing import List, Tuple

import pandas as pd
import streamlit as st

from . import data_loader as dl
from .chart_data import fmt_num


def _reset_filters():
    st.session_state["filter_version"] = st.session_state.get("filter_version", 0) + 1


def _natural_unique(s: pd.Series) -> list:
    vals = s.dropna().unique().tolist()
    try:
        return sorted(vals)
    except TypeError:
        return sorted(vals, key=str)


def render_filters(df: pd.DataFrame, dataset_key: str) -> Tuple[pd.DataFrame, List[str]]:
    """Draw the filters in the sidebar. Returns (filtered_df, list of active-filter descriptions)."""
    roles = dl.column_roles(df)
    version = st.session_state.get("filter_version", 0)

    def key(*parts) -> str:
        return ":".join([dataset_key, f"v{version}", *map(str, parts)])

    mask = pd.Series(True, index=df.index)
    active: List[str] = []

    st.sidebar.header("🎛️ Filters")
    st.sidebar.button("Reset all filters", on_click=_reset_filters, key=key("reset"))

    # ---- text search ----------------------------------------------------- #
    search_cols = [c for c in roles["text_cols"]
                   if df[c].nunique(dropna=True) > 30 and "url" not in c.lower()]
    if search_cols:
        default_idx = 0
        for i, c in enumerate(search_cols):
            if any(w in c.lower() for w in ("title", "name")):
                default_idx = i
                break
        if len(search_cols) > 1:
            col = st.sidebar.selectbox("Search in column", search_cols, index=default_idx,
                                       key=key("search_col"))
        else:
            col = search_cols[0]
        text = st.sidebar.text_input(f"Search '{col}' (contains)", key=key("search_text"))
        if text.strip():
            mask &= df[col].astype(str).str.contains(text.strip(), case=False, regex=False, na=False)
            active.append(f"{col} contains \"{text.strip()}\"")

    # ---- sliders ----------------------------------------------------------#
    slider_cols = roles["continuous"] + roles["datetime"]
    for c in slider_cols:
        s = df[c].dropna()
        if s.empty or s.min() == s.max():
            continue
        if c in roles["datetime"]:
            lo, hi = s.min().to_pydatetime(), s.max().to_pydatetime()
            sel = st.sidebar.slider(c, min_value=lo, max_value=hi, value=(lo, hi),
                                    format="YYYY-MM-DD", key=key("dt", c))
            if sel != (lo, hi):
                mask &= (df[c] >= pd.Timestamp(sel[0])) & (df[c] <= pd.Timestamp(sel[1]))
                active.append(f"{c} between {sel[0]:%Y-%m-%d} and {sel[1]:%Y-%m-%d}")
            continue
        is_int = pd.api.types.is_integer_dtype(df[c])
        lo, hi = (int(s.min()), int(s.max())) if is_int else (float(s.min()), float(s.max()))
        if is_int:
            sel = st.sidebar.slider(c, min_value=lo, max_value=hi, value=(lo, hi), step=1,
                                    key=key("num", c))
        else:
            step = max((hi - lo) / 200, 1e-9)
            sel = st.sidebar.slider(c, min_value=lo, max_value=hi, value=(lo, hi), step=step,
                                    key=key("num", c))
        if sel != (lo, hi):
            mask &= df[c].between(sel[0], sel[1])
            active.append(f"{c} between {fmt_num(sel[0])} and {fmt_num(sel[1])}")

    # ---- multi-selects ----------------------------------------------------#
    multi_cols = [c for c in roles["group_cols"]]
    shown = 0
    container = st.sidebar
    for c in multi_cols:
        if shown == 4:
            container = st.sidebar.expander("More filters")
        options = _natural_unique(df[c])
        if len(options) < 2:
            continue
        chosen = container.multiselect(c, options, default=options, key=key("multi", c))
        if set(chosen) != set(options):
            mask &= df[c].isin(chosen)
            active.append(f"{c} in {', '.join(map(str, chosen)) if chosen else '(nothing selected)'}")
        shown += 1

    filtered = df[mask]
    st.sidebar.caption(f"Showing **{len(filtered):,}** of **{len(df):,}** rows")
    return filtered, active
