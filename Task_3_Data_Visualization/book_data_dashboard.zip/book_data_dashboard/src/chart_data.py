"""
chart_data.py
=============
Prepares the numbers behind every chart.

Both the interactive Plotly charts and the downloadable Matplotlib/Seaborn
charts call the functions in this file, so the two versions always show exactly
the same data.

Rules:
  * Missing values are never filled in. Rows that lack a needed value are
    dropped for THAT chart only, and (where useful) the count is reported.
  * Missing category labels are shown honestly as "(missing)".
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pandas.api.types import is_bool_dtype, is_numeric_dtype

from . import data_loader as dl

KINDS = ["bar", "line", "pie", "hist", "scatter", "box"]
KIND_NAMES = {
    "bar": "Bar chart",
    "line": "Line chart",
    "pie": "Pie chart",
    "hist": "Histogram",
    "scatter": "Scatter plot",
    "box": "Box plot",
}
AGG_FUNCS = ["count", "mean", "median", "sum", "min", "max"]
AGG_LABELS = {
    "count": "Count of rows",
    "mean": "Mean",
    "median": "Median",
    "sum": "Sum",
    "min": "Minimum",
    "max": "Maximum",
}


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def fmt_num(x: Any, decimals: int = 2) -> str:
    """Format a number for display (thousands separators, sensible decimals)."""
    try:
        if x is None or (isinstance(x, float) and np.isnan(x)):
            return "n/a"
        if float(x).is_integer() and abs(float(x)) < 1e15:
            return f"{int(x):,}"
        return f"{float(x):,.{decimals}f}"
    except (TypeError, ValueError):
        return str(x)


def fmt_label(v: Any) -> str:
    """Turn any cell value into a clean text label."""
    if v is None or (not isinstance(v, str) and pd.isna(v)):
        return "(missing)"
    if isinstance(v, (float, np.floating)) and float(v).is_integer():
        return str(int(v))
    if isinstance(v, pd.Timestamp):
        return v.strftime("%Y-%m-%d")
    return str(v)


def label_series(s: pd.Series) -> pd.Series:
    return s.map(fmt_label)


def ordered_labels(s: pd.Series) -> List[str]:
    """Distinct labels of a column in natural order (1,2,3.. or A,B,C..), missing last."""
    frame = pd.DataFrame({"k": s.values, "l": label_series(s).values}).drop_duplicates("l")
    try:
        frame = frame.sort_values("k", na_position="last", kind="stable")
    except TypeError:
        frame = frame.sort_values("l", kind="stable")
    return frame["l"].tolist()


def metric_label(agg: str, value: Optional[str]) -> str:
    if agg == "count" or not value:
        return "Count of rows"
    return f"{AGG_LABELS.get(agg, agg)} of {value}"


def _require(df: pd.DataFrame, col: Optional[str], what: str = "column") -> None:
    if col is None or col not in df.columns:
        raise ValueError(f"Please choose a valid {what}.")


def _require_numeric(df: pd.DataFrame, col: Optional[str], what: str = "column") -> None:
    _require(df, col, what)
    if not is_numeric_dtype(df[col]) or is_bool_dtype(df[col]):
        raise ValueError(f"'{col}' is not a numeric column. Please choose a numeric {what}.")


def chart_title(kind: str, **p: Any) -> str:
    """A readable default title for each chart type."""
    if kind in ("bar", "pie"):
        what = metric_label(p.get("agg", "count"), p.get("value"))
        return f"{what} by {p.get('cat')}"
    if kind == "line":
        what = metric_label(p.get("agg", "mean"), p.get("y"))
        extra = f" (split by {p['group']})" if p.get("group") else ""
        return f"{what} by {p.get('x')}{extra}"
    if kind == "hist":
        extra = f" by {p['group']}" if p.get("group") else ""
        return f"Distribution of {p.get('col')}{extra}"
    if kind == "scatter":
        return f"{p.get('y')} vs {p.get('x')}"
    if kind == "box":
        extra = f" by {p['group']}" if p.get("group") else ""
        return f"Box plot of {p.get('y')}{extra}"
    return kind


# --------------------------------------------------------------------------- #
# Bar / Pie
# --------------------------------------------------------------------------- #
def prep_aggregate(
    df: pd.DataFrame,
    cat: str,
    value: Optional[str] = None,
    agg: str = "count",
    sort: str = "value",
    top_n: Optional[int] = None,
) -> Tuple[pd.DataFrame, int]:
    """
    Group by `cat` and aggregate. Returns (table with columns label,value, total_categories).

    sort: "value" (largest first) or "label" (natural order 1,2,3 / A,B,C)
    """
    _require(df, cat, "category column")
    if agg not in AGG_FUNCS:
        raise ValueError(f"Unknown aggregation '{agg}'.")
    if agg != "count":
        _require_numeric(df, value, "value column")

    work = pd.DataFrame({"label": label_series(df[cat]).values})
    if agg != "count":
        work["v"] = pd.to_numeric(df[value], errors="coerce").values

    grouped = work.groupby("label", sort=False)
    if agg == "count":
        out = grouped.size().rename("value").reset_index()
    elif agg == "sum":
        out = grouped["v"].sum(min_count=1).rename("value").reset_index()
    else:
        out = grouped["v"].agg(agg).rename("value").reset_index()
    out = out.dropna(subset=["value"])
    total_categories = len(out)

    rank = {lab: i for i, lab in enumerate(ordered_labels(df[cat]))}
    out["_o"] = out["label"].map(rank)
    out = out.sort_values(["value", "_o"], ascending=[False, True], kind="stable")
    if top_n and len(out) > top_n:
        out = out.head(int(top_n))
    if sort == "label":
        out = out.sort_values("_o", kind="stable")
    return out[["label", "value"]].reset_index(drop=True), total_categories


def prep_pie(
    df: pd.DataFrame,
    cat: str,
    value: Optional[str] = None,
    agg: str = "count",
    top_n: int = 8,
    sort: str = "value",
) -> Tuple[pd.DataFrame, str]:
    """Pie data: only Count or Sum make sense. Small slices are merged into 'Other'."""
    if agg not in ("count", "sum"):
        raise ValueError("Pie charts support only 'count' or 'sum'.")
    full, _ = prep_aggregate(df, cat, value, agg, sort="value", top_n=None)
    note = ""
    non_positive = int((full["value"] <= 0).sum())
    if non_positive:
        full = full[full["value"] > 0]
        note += f"{non_positive} categories with zero or negative totals were left out. "
    if full.empty:
        raise ValueError("There is nothing positive to show in a pie chart for this selection.")

    other_total = None
    if top_n and len(full) > top_n:
        rest = full.iloc[int(top_n):]
        other_total = float(rest["value"].sum())
        note += f"The smallest {len(rest)} categories are grouped as 'Other'."
        full = full.head(int(top_n))
    if sort == "label":
        rank = {lab: i for i, lab in enumerate(ordered_labels(df[cat]))}
        full = full.assign(_o=full["label"].map(rank)).sort_values("_o").drop(columns="_o")
    if other_total is not None:
        full = pd.concat(
            [full, pd.DataFrame({"label": ["Other"], "value": [other_total]})], ignore_index=True
        )
    return full.reset_index(drop=True), note.strip()


# --------------------------------------------------------------------------- #
# Line
# --------------------------------------------------------------------------- #
def prep_line(
    df: pd.DataFrame,
    x: str,
    y: Optional[str] = None,
    agg: str = "mean",
    group: Optional[str] = None,
) -> Tuple[pd.DataFrame, Optional[List[str]]]:
    """Aggregate y for every distinct x (optionally per group). Columns: x, value, [group]."""
    _require(df, x, "X column")
    if agg not in AGG_FUNCS:
        raise ValueError(f"Unknown aggregation '{agg}'.")
    if agg != "count":
        _require_numeric(df, y, "Y column")

    work = pd.DataFrame({"x": df[x].values})
    needed = ["x"]
    if agg != "count":
        work["v"] = pd.to_numeric(df[y], errors="coerce").values
        needed.append("v")
    if group:
        _require(df, group, "group column")
        work["group"] = label_series(df[group]).values
    work = work.dropna(subset=needed)
    if work.empty:
        raise ValueError("No rows have both an X and a Y value for this selection.")

    keys = ["x"] + (["group"] if group else [])
    grouped = work.groupby(keys, sort=True)
    if agg == "count":
        out = grouped.size().rename("value").reset_index()
    elif agg == "sum":
        out = grouped["v"].sum(min_count=1).rename("value").reset_index()
    else:
        out = grouped["v"].agg(agg).rename("value").reset_index()
    out = out.dropna(subset=["value"])
    order = ordered_labels(df[group]) if group else None
    return out.reset_index(drop=True), order


# --------------------------------------------------------------------------- #
# Histogram
# --------------------------------------------------------------------------- #
def prep_hist(
    df: pd.DataFrame, col: str, group: Optional[str] = None
) -> Tuple[pd.DataFrame, Optional[List[str]], int]:
    """Returns (table with x[,group], group order, number of rows dropped for missing values)."""
    _require_numeric(df, col, "column")
    d = pd.DataFrame({"x": pd.to_numeric(df[col], errors="coerce").values})
    if group:
        _require(df, group, "group column")
        d["group"] = label_series(df[group]).values
    before = len(d)
    d = d.dropna(subset=["x"])
    if d.empty:
        raise ValueError(f"'{col}' has no values to plot.")
    order = ordered_labels(df[group]) if group else None
    return d.reset_index(drop=True), order, before - len(d)


def gaussian_kde_curve(values: np.ndarray, grid: np.ndarray) -> Optional[np.ndarray]:
    """Small NumPy-only Gaussian KDE (Silverman bandwidth). Returns None if not computable."""
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    if len(v) < 3:
        return None
    if len(v) > 5000:
        v = np.random.default_rng(0).choice(v, 5000, replace=False)
    std = v.std(ddof=1)
    iqr = np.subtract(*np.percentile(v, [75, 25]))
    spread = min(std, iqr / 1.34) if iqr > 0 else std
    if not np.isfinite(spread) or spread <= 0:
        return None
    bw = 0.9 * spread * len(v) ** (-0.2)
    z = (grid[:, None] - v[None, :]) / bw
    return np.exp(-0.5 * z ** 2).sum(axis=1) / (len(v) * bw * np.sqrt(2 * np.pi))


# --------------------------------------------------------------------------- #
# Scatter
# --------------------------------------------------------------------------- #
def prep_scatter(
    df: pd.DataFrame,
    x: str,
    y: str,
    color: Optional[str] = None,
    size: Optional[str] = None,
    hover_name: Optional[str] = None,
    max_points: int = 20000,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Returns (points table, info). Table columns: x, y, [color], [size], [hover].
    info: n, n_dropped, sampled, fit=(slope, intercept, r) or None, color_order.
    """
    _require_numeric(df, x, "X column")
    _require_numeric(df, y, "Y column")
    d = pd.DataFrame(
        {"x": pd.to_numeric(df[x], errors="coerce").values,
         "y": pd.to_numeric(df[y], errors="coerce").values}
    )
    if color:
        _require(df, color, "colour column")
        d["color"] = label_series(df[color]).values
    if size:
        _require_numeric(df, size, "size column")
        d["size"] = pd.to_numeric(df[size], errors="coerce").values
    if hover_name and hover_name in df.columns:
        d["hover"] = df[hover_name].astype(str).values

    before = len(d)
    needed = ["x", "y"] + (["size"] if size else [])
    d = d.dropna(subset=needed)
    if d.empty:
        raise ValueError("No rows have values for both axes.")
    if size and (d["size"] < 0).any():
        raise ValueError(f"'{size}' contains negative numbers, so it cannot be used for point size.")

    n_dropped = before - len(d)
    fit = None
    if len(d) >= 3 and d["x"].nunique() > 1 and d["y"].nunique() > 1:
        slope, intercept = np.polyfit(d["x"], d["y"], 1)
        r = float(np.corrcoef(d["x"], d["y"])[0, 1])
        fit = (float(slope), float(intercept), r)

    sampled = False
    if len(d) > max_points:
        d = d.sample(int(max_points), random_state=0)
        sampled = True
    info = {
        "n": len(d),
        "n_dropped": n_dropped,
        "sampled": sampled,
        "fit": fit,
        "color_order": ordered_labels(df[color]) if color else None,
    }
    return d.reset_index(drop=True), info


# --------------------------------------------------------------------------- #
# Box
# --------------------------------------------------------------------------- #
def prep_box(
    df: pd.DataFrame, y: str, group: Optional[str] = None
) -> Tuple[pd.DataFrame, Optional[List[str]]]:
    _require_numeric(df, y, "numeric column")
    d = pd.DataFrame({"y": pd.to_numeric(df[y], errors="coerce").values})
    if group:
        _require(df, group, "group column")
        d["group"] = label_series(df[group]).values
    d = d.dropna(subset=["y"])
    if d.empty:
        raise ValueError(f"'{y}' has no values to plot.")
    return d.reset_index(drop=True), (ordered_labels(df[group]) if group else None)


def iqr_fences(values: pd.Series) -> Tuple[float, float]:
    q1, q3 = values.quantile(0.25), values.quantile(0.75)
    iqr = q3 - q1
    return float(q1 - 1.5 * iqr), float(q3 + 1.5 * iqr)


# --------------------------------------------------------------------------- #
# Plain-English "what does this chart say" captions (computed from the data)
# --------------------------------------------------------------------------- #
def _strength(r: float) -> str:
    a = abs(r)
    if a < 0.1:
        return "negligible"
    if a < 0.3:
        return "weak"
    if a < 0.5:
        return "moderate"
    if a < 0.7:
        return "strong"
    return "very strong"


def describe_chart(kind: str, df: pd.DataFrame, params: Dict[str, Any]) -> str:
    """Return a short factual caption for a chart. Never raises: returns '' on any problem."""
    try:
        if kind == "bar":
            data, total = prep_aggregate(
                df, params["cat"], params.get("value"), params.get("agg", "count"),
                "value", None,
            )
            hi, lo = data.iloc[0], data.iloc[-1]
            c = params["cat"]
            txt = (f"Highest: {c} = {hi['label']} ({fmt_num(hi['value'])}). "
                   f"Lowest: {c} = {lo['label']} ({fmt_num(lo['value'])}).")
            top_n = params.get("top_n")
            if top_n and total > top_n:
                txt += f" Showing the top {top_n} of {total} categories."
            return txt
        if kind == "pie":
            data, note = prep_pie(
                df, params["cat"], params.get("value"), params.get("agg", "count"), 10**6, "value"
            )
            tot = data["value"].sum()
            top = data.iloc[0]
            return (f"Largest slice: {params['cat']} = {top['label']} ({top['value'] / tot:.1%} of the total). "
                    f"{len(data)} slices in total.")
        if kind == "line":
            data, _ = prep_line(df, params["x"], params.get("y"), params.get("agg", "mean"),
                                params.get("group"))
            hi = data.loc[data["value"].idxmax()]
            lo = data.loc[data["value"].idxmin()]
            return (f"Highest point: {fmt_label(hi['x'])} ({fmt_num(hi['value'])}). "
                    f"Lowest point: {fmt_label(lo['x'])} ({fmt_num(lo['value'])}). "
                    f"{data['x'].nunique()} distinct X values.")
        if kind == "hist":
            data, _, dropped = prep_hist(df, params["col"], None)
            x = data["x"]
            counts, edges = np.histogram(x, bins=int(params.get("bins", 30)))
            i = int(counts.argmax())
            txt = (f"{len(x):,} values; mean {fmt_num(x.mean())}, median {fmt_num(x.median())}, "
                   f"range {fmt_num(x.min())} to {fmt_num(x.max())}. "
                   f"Most common range: {fmt_num(edges[i])} to {fmt_num(edges[i + 1])} "
                   f"({int(counts[i]):,} values).")
            if dropped:
                txt += f" {dropped:,} rows with missing values were skipped."
            return txt
        if kind == "scatter":
            _, info = prep_scatter(df, params["x"], params["y"], None, None, None,
                                   int(params.get("max_points", 20000)))
            txt = f"{info['n']:,} points plotted."
            if info["fit"]:
                slope, _, r = info["fit"]
                direction = "positive" if r > 0 else "negative"
                txt += (f" Pearson r = {r:.2f} ({_strength(r)} {direction} linear relationship). "
                        f"On average, y changes by {fmt_num(slope, 3)} for each +1 in x. "
                        "This shows association, not cause and effect.")
            if info["sampled"]:
                txt += " (A random sample is displayed for speed; the statistics use all rows.)"
            return txt
        if kind == "box":
            data, _ = prep_box(df, params["y"], params.get("group"))
            lo_f, hi_f = iqr_fences(data["y"])
            outliers = int(((data["y"] < lo_f) | (data["y"] > hi_f)).sum())
            if params.get("group"):
                med = data.groupby("group")["y"].median()
                g = params["group"]
                return (f"Highest median: {g} = {med.idxmax()} ({fmt_num(med.max())}). "
                        f"Lowest median: {g} = {med.idxmin()} ({fmt_num(med.min())}). "
                        f"{outliers:,} values fall outside the overall 1.5xIQR fences.")
            return (f"Median {fmt_num(data['y'].median())}; middle 50% between "
                    f"{fmt_num(data['y'].quantile(.25))} and {fmt_num(data['y'].quantile(.75))}; "
                    f"{outliers:,} outliers by the 1.5xIQR rule.")
    except Exception:
        return ""
    return ""


# --------------------------------------------------------------------------- #
# Smart default settings for each chart (based on the real columns)
# --------------------------------------------------------------------------- #
VALUE_PREFS = ["price", "amount", "revenue", "sales", "cost", "value", "score", "total"]
CAT_PREFS = ["category", "genre", "rating", "type", "status", "group", "class", "region"]
X_PREFS = ["date", "time", "page", "year", "month", "day"]
HOVER_PREFS = ["title", "name", "label"]


def pick_column(cands: List[str], prefs: List[str], fallback: bool = True) -> Optional[str]:
    for p in prefs:
        for c in cands:
            if p in str(c).lower():
                return c
    return cands[0] if (cands and fallback) else None


def default_specs(df: pd.DataFrame) -> Dict[str, Optional[Dict[str, Any]]]:
    """Sensible starting settings for each chart; None if the data cannot support that chart."""
    r = dl.column_roles(df)
    numeric = r["numeric"]
    numeric_pool = r["continuous"] or numeric
    value = pick_column(numeric_pool, VALUE_PREFS)
    cat = pick_column(r["category_cols"], CAT_PREFS)
    cat_is_numeric = cat in numeric if cat else False
    specs: Dict[str, Optional[Dict[str, Any]]] = {k: None for k in KINDS}

    if cat:
        specs["bar"] = dict(cat=cat, value=None, agg="count",
                            sort="label" if cat_is_numeric else "value",
                            top_n=20, orientation="v")
        specs["pie"] = dict(cat=cat, value=None, agg="count", top_n=8,
                            sort="label" if cat_is_numeric else "value", donut=False)

    x_pool = r["datetime"] + numeric + [c for c in r["category_cols"] if c not in numeric]
    x_line = pick_column(x_pool, X_PREFS)
    if x_line:
        y_line = pick_column([c for c in numeric_pool if c != x_line], VALUE_PREFS, fallback=True)
        if y_line:
            specs["line"] = dict(x=x_line, y=y_line, agg="mean", group=None, markers=True)
        else:
            specs["line"] = dict(x=x_line, y=None, agg="count", group=None, markers=True)

    if value:
        group = cat if (cat in r["group_cols"]) else None
        specs["hist"] = dict(col=value, bins=30, group=None, histnorm="count",
                             marginal=None, show_kde=True)
        specs["box"] = dict(y=value, group=group, points="outliers")

    if value and len(numeric) >= 2:
        others = [c for c in numeric if c != value]
        non_cat = [c for c in others if c in r["continuous"]] or others
        x_sc = pick_column(non_cat, X_PREFS)
        color = cat if (cat in r["group_cols"] and cat not in (x_sc, value)) else None
        hover = pick_column(r["text_cols"], HOVER_PREFS, fallback=False)
        specs["scatter"] = dict(x=x_sc, y=value, color=color, size=None, trendline=True,
                                opacity=0.65, hover_name=hover, max_points=20000)
    return specs
