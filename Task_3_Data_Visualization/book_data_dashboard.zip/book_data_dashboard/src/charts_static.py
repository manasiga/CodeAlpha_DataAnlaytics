"""
charts_static.py
================
Static (image) versions of the same six charts using Matplotlib + Seaborn.

Used for:
  * PNG downloads of each chart,
  * the correlation heatmap,
  * charts inside the PDF report.

Figures are created with matplotlib.figure.Figure (not pyplot) so they are safe
to build inside a web app that handles several users at once.
"""
from __future__ import annotations

import io
from typing import Any, Optional

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter

from . import chart_data as cd

PALETTE_NAME = "deep"
FIGSIZE = (9, 5.2)


def _new_fig(figsize=FIGSIZE):
    fig = Figure(figsize=figsize, dpi=100)
    ax = fig.subplots()
    return fig, ax


def _style(ax, title: str, xlabel: str = "", ylabel: str = ""):
    ax.set_title(title, fontsize=13, fontweight="bold", loc="left", pad=12)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(True, axis="y", alpha=0.3)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def _thousands(ax, axis="y"):
    fmt = FuncFormatter(lambda v, _: f"{v:,.0f}" if float(v).is_integer() else f"{v:,.2f}")
    (ax.yaxis if axis == "y" else ax.xaxis).set_major_formatter(fmt)


def _legend_outside(ax, title: Optional[str] = None):
    handles, labels = ax.get_legend_handles_labels()
    if handles:
        ax.legend(handles, labels, loc="center left", bbox_to_anchor=(1.01, 0.5),
                  frameon=False, fontsize=9, title=title)


# --------------------------------------------------------------------------- #
def bar_figure(df, cat, value=None, agg="count", sort="value", top_n=20,
               orientation="v", **_ignored) -> Figure:
    data, _ = cd.prep_aggregate(df, cat, value, agg, sort, top_n)
    if data.empty:
        raise ValueError("There is no data to show for this selection.")
    fig, ax = _new_fig()
    order = list(data["label"])
    colors = sns.color_palette(PALETTE_NAME, 1) * len(data)
    ylabel = cd.metric_label(agg, value)
    fmt = "{:,.0f}" if agg == "count" else "{:,.2f}"
    if orientation == "h":
        ax.barh(data["label"], data["value"], color=colors)
        ax.invert_yaxis()
        ax.bar_label(ax.containers[0], labels=[fmt.format(v) for v in data["value"]],
                     padding=3, fontsize=9)
        _style(ax, cd.chart_title("bar", cat=cat, value=value, agg=agg), ylabel, cat)
        ax.grid(True, axis="x", alpha=0.3)
        ax.grid(False, axis="y")
        _thousands(ax, "x")
    else:
        ax.bar(data["label"], data["value"], color=colors)
        ax.bar_label(ax.containers[0], labels=[fmt.format(v) for v in data["value"]],
                     padding=3, fontsize=9)
        _style(ax, cd.chart_title("bar", cat=cat, value=value, agg=agg), cat, ylabel)
        _thousands(ax, "y")
        if len(order) > 6 or max(len(s) for s in order) > 10:
            ax.tick_params(axis="x", rotation=45)
            for lab in ax.get_xticklabels():
                lab.set_ha("right")
    ax.margins(y=0.12)
    fig.tight_layout()
    return fig


def line_figure(df, x, y=None, agg="mean", group=None, markers=True, **_ignored) -> Figure:
    data, order = cd.prep_line(df, x, y, agg, group)
    fig, ax = _new_fig()
    palette = sns.color_palette(PALETTE_NAME, max(1, len(order) if order else 1))
    npts = data["x"].nunique()
    ms = 4 if (markers and npts <= 60) else 0
    if group:
        for i, g in enumerate(order):
            sub = data[data["group"] == g]
            if len(sub):
                ax.plot(sub["x"], sub["value"], marker="o", ms=ms, lw=1.8,
                        color=palette[i % len(palette)], label=g)
        _legend_outside(ax, title=group)
    else:
        ax.plot(data["x"], data["value"], marker="o", ms=ms, lw=1.8, color=palette[0])
    _style(ax, cd.chart_title("line", x=x, y=y, agg=agg, group=group), x, cd.metric_label(agg, y))
    _thousands(ax, "y")
    if not pd.api.types.is_numeric_dtype(data["x"]):
        ax.tick_params(axis="x", rotation=45)
        for lab in ax.get_xticklabels():
            lab.set_ha("right")
    fig.tight_layout()
    return fig


def pie_figure(df, cat, value=None, agg="count", top_n=8, sort="value",
               donut=False, **_ignored) -> Figure:
    data, note = cd.prep_pie(df, cat, value, agg, top_n, sort)
    fig, ax = _new_fig((8, 5.2))
    colors = sns.color_palette(PALETTE_NAME, len(data))
    total = data["value"].sum()
    wedges, _t, autotexts = ax.pie(
        data["value"], colors=colors, startangle=90, counterclock=False,
        autopct=lambda p: f"{p:.1f}%" if p >= 3 else "",
        pctdistance=0.78 if donut else 0.65,
        wedgeprops=dict(edgecolor="white", linewidth=1.5, width=0.45 if donut else None),
        textprops=dict(fontsize=9, color="white", fontweight="bold"),
    )
    ax.legend(wedges, [f"{l} ({v / total:.1%})" for l, v in zip(data["label"], data["value"])],
              loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False, fontsize=9)
    ax.set_title(cd.chart_title("pie", cat=cat, value=value, agg=agg),
                 fontsize=13, fontweight="bold", loc="left")
    ax.set_aspect("equal")
    if note:
        fig.text(0.01, 0.01, note, fontsize=8, color="gray")
    fig.tight_layout()
    return fig


def hist_figure(df, col, bins=30, group=None, histnorm="count", show_kde=True,
                **_ignored) -> Figure:
    data, order, dropped = cd.prep_hist(df, col, group)
    fig, ax = _new_fig()
    stat = "percent" if histnorm == "percent" else "count"
    bins = int(bins)
    if group:
        sns.histplot(data=data, x="x", hue="group", hue_order=order, bins=bins, stat=stat,
                     multiple="layer", alpha=0.55, palette=PALETTE_NAME, ax=ax, edgecolor="white")
        if ax.get_legend() is not None:
            sns.move_legend(ax, "center left", bbox_to_anchor=(1.01, 0.5), title=None,
                            frameon=False)
    else:
        sns.histplot(data=data, x="x", bins=bins, stat=stat, color=sns.color_palette(PALETTE_NAME)[0],
                     alpha=0.85, ax=ax, edgecolor="white")
        if show_kde:
            lo, hi = float(data["x"].min()), float(data["x"].max())
            if hi > lo:
                grid = np.linspace(lo, hi, 200)
                dens = cd.gaussian_kde_curve(data["x"].to_numpy(), grid)
                if dens is not None:
                    width = (hi - lo) / bins
                    scale = len(data) * width if stat == "count" else width * 100
                    ax.plot(grid, dens * scale, color="#C44E52", lw=2, label="Density curve")
                    ax.legend(frameon=False)
    _style(ax, cd.chart_title("hist", col=col, group=group), col,
           "Percent of rows" if stat == "percent" else "Count")
    _thousands(ax, "y")
    if dropped:
        fig.text(0.01, 0.01, f"{dropped:,} rows with missing values were skipped.",
                 fontsize=8, color="gray")
    fig.tight_layout()
    return fig


def scatter_figure(df, x, y, color=None, size=None, trendline=True, opacity=0.65,
                   max_points=20000, **_ignored) -> Figure:
    data, info = cd.prep_scatter(df, x, y, color, size, None, int(max_points))
    fig, ax = _new_fig()
    kwargs = dict(data=data, x="x", y="y", alpha=float(opacity), ax=ax, linewidth=0.3,
                  edgecolor="white")
    if color:
        kwargs.update(hue="color", hue_order=info["color_order"], palette=PALETTE_NAME)
    else:
        kwargs.update(color=sns.color_palette(PALETTE_NAME)[0])
    if size:
        kwargs.update(size="size", sizes=(20, 220))
    else:
        kwargs.update(s=28)
    sns.scatterplot(**kwargs)
    if trendline and info["fit"]:
        slope, intercept, r = info["fit"]
        xs = np.array([data["x"].min(), data["x"].max()])
        ax.plot(xs, slope * xs + intercept, color="#333333", ls="--", lw=2,
                label=f"Linear trend (r = {r:.2f})")
    _legend_outside(ax, title=color)
    _style(ax, cd.chart_title("scatter", x=x, y=y), x, y)
    ax.grid(True, axis="x", alpha=0.3)
    if info["sampled"]:
        fig.text(0.01, 0.01, f"Random sample of {info['n']:,} points shown.", fontsize=8, color="gray")
    fig.tight_layout()
    return fig


def box_figure(df, y, group=None, points="outliers", **_ignored) -> Figure:
    data, order = cd.prep_box(df, y, group)
    fig, ax = _new_fig()
    show_fliers = points == "outliers"
    if group:
        sns.boxplot(data=data, x="group", y="y", order=order, hue="group", hue_order=order,
                    palette=PALETTE_NAME, legend=False, showfliers=show_fliers, ax=ax,
                    linewidth=1.2)
        if points == "all" and len(data) <= 3000:
            sns.stripplot(data=data, x="group", y="y", order=order, color="0.25", size=2,
                          alpha=0.4, ax=ax)
        _style(ax, cd.chart_title("box", y=y, group=group), group, y)
    else:
        sns.boxplot(data=data, y="y", color=sns.color_palette(PALETTE_NAME)[0],
                    showfliers=show_fliers, ax=ax, linewidth=1.2)
        if points == "all" and len(data) <= 3000:
            sns.stripplot(data=data, y="y", color="0.25", size=2, alpha=0.4, ax=ax)
        _style(ax, cd.chart_title("box", y=y, group=group), "", y)
    fig.tight_layout()
    return fig


def correlation_figure(df: pd.DataFrame, method: str = "pearson") -> Optional[Figure]:
    """Seaborn heatmap of numeric-column correlations. Returns None if fewer than 2 columns."""
    corr = cd_corr(df, method)
    if corr is None:
        return None
    k = len(corr)
    size = min(11, max(5, 0.9 * k + 2))
    fig = Figure(figsize=(size, size * 0.85), dpi=100)
    ax = fig.subplots()
    sns.heatmap(corr, annot=k <= 12, fmt=".2f", cmap="coolwarm", vmin=-1, vmax=1, center=0,
                square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
    ax.set_title(f"Correlation heatmap ({method.title()})", fontsize=13, fontweight="bold",
                 loc="left", pad=12)
    ax.tick_params(axis="x", rotation=45)
    for lab in ax.get_xticklabels():
        lab.set_ha("right")
    fig.tight_layout()
    return fig


def cd_corr(df: pd.DataFrame, method: str = "pearson") -> Optional[pd.DataFrame]:
    """Correlation matrix of numeric columns that actually vary (max 20 columns)."""
    num = df.select_dtypes(include="number")
    num = num.loc[:, num.nunique(dropna=True) > 1]
    if num.shape[1] < 2:
        return None
    num = num.iloc[:, :20]
    if method == "spearman":
        return num.rank().corr()
    return num.corr()


# --------------------------------------------------------------------------- #
_BUILDERS = {
    "bar": bar_figure, "line": line_figure, "pie": pie_figure,
    "hist": hist_figure, "scatter": scatter_figure, "box": box_figure,
}


def build(kind: str, df, **params: Any) -> Figure:
    if kind not in _BUILDERS:
        raise ValueError(f"Unknown chart type '{kind}'.")
    with sns.axes_style("whitegrid"):
        return _BUILDERS[kind](df, **params)


def fig_to_png_bytes(fig: Figure, dpi: int = 150) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight", facecolor="white")
    return buf.getvalue()


def render_png(kind: str, df, params: dict, dpi: int = 150) -> bytes:
    """Build a static chart and return it as PNG bytes."""
    return fig_to_png_bytes(build(kind, df, **params), dpi=dpi)
