# Book Data Analysis Results

- Source file: books_data.csv
- Generated: 2026-11-06 07:01
- Rows analysed: 1,000
- Columns: 8
- Missing cells: 0
- Duplicate rows: 0

## Key insights

- The data has 1,000 rows and 8 columns (3 numeric, 4 text, 1 true/false).
- There are no missing values in any column.
- There are no exact duplicate rows.
- Columns that are almost unique but contain repeats: 'title' (1 repeated value(s)).
- Columns with only one distinct value (no variation, so not useful for comparisons): availability, in_stock.
- price_gbp: mean 35.07, median 35.98, range 10 to 59.99, standard deviation 14.45; the distribution is roughly symmetric; no outliers by the 1.5xIQR rule.
- rating_stars: mean 2.92, median 3, range 1 to 5, standard deviation 1.43; the distribution is roughly symmetric; no outliers by the 1.5xIQR rule.
- page_number: mean 25.50, median 25.50, range 1 to 50, standard deviation 14.44; the distribution is roughly symmetric; no outliers by the 1.5xIQR rule.
- rating_stars: 5 distinct values; the most common is '1' (226 rows, 22.6% of non-missing).
- rating_text: 5 distinct values; the most common is 'One' (226 rows, 22.6% of non-missing).
- Strongest linear relationship between numeric columns: price_gbp and rating_stars (Pearson r = 0.03, negligible). Correlation shows association only - not cause and effect.
- Average price_gbp by rating_stars: highest for rating_stars = 4 (36.09), lowest for rating_stars = 1 (34.56); gap = 1.53 (groups with fewer than 5 rows are ignored).

## Column summary

Column,Type,Non-null,Missing,Missing %,Unique,Example
title,str,1000,0,0.0,999,A Light in the Attic
price_gbp,float64,1000,0,0.0,903,51.77
rating_stars,int64,1000,0,0.0,5,3
rating_text,str,1000,0,0.0,5,Three
availability,str,1000,0,0.0,1,In stock
in_stock,bool,1000,0,0.0,1,True
page_number,int64,1000,0,0.0,50,1
product_url,str,1000,0,0.0,1000,https://books.toscrape.com/catalogue/a-light-in-the-attic_10

## Numeric summary

Column,Count,Mean,Std,Min,25%,Median,75%,Max,Skew,Kurtosis,Outliers (IQR)
price_gbp,1000,35.07,14.447,10.0,22.108,35.98,47.457,59.99,-0.038,-1.21,0
rating_stars,1000,2.923,1.435,1.0,2.0,3.0,4.0,5.0,0.074,-1.318,0
page_number,1000,25.5,14.438,1.0,13.0,25.5,38.0,50.0,0.0,-1.201,0

## Text / category summary

Column,Unique,Most common,Count,Share %
title,999,The Star-Touched Queen,2,0.2
rating_text,5,One,226,22.6
availability,1,In stock,1000,100.0
in_stock,1,True,1000,100.0
product_url,1000,https://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.h,1,0.1

_Missing values were never filled in; charts skip rows that lack the needed values._