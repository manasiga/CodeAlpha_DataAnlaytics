"""
Basic self-checks for the project.

Run with either:
    python tests/test_core.py
    python -m pytest tests            (if you have pytest installed)
"""
import io
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd

from src import analysis as an
from src import chart_data as cd
from src import charts_plotly as cp
from src import charts_static as cs
from src import data_loader as dl
from src import exports as ex
from src import report as rp


def _books():
    path = dl.find_default_dataset()
    assert path is not None, "data/books_data.csv is missing"
    return dl.load_csv(str(path))


def test_dataset_loads_and_is_real():
    df = _books()
    raw = pd.read_csv(dl.find_default_dataset())
    assert df.shape == raw.shape
    assert df.isna().sum().sum() == raw.isna().sum().sum()  # nothing filled in


def test_loader_friendly_errors():
    for raw in (b"", b"a,b,c\n"):
        try:
            dl.load_csv(io.BytesIO(raw))
        except dl.DataLoadError:
            continue
        raise AssertionError("expected DataLoadError")


def test_bar_counts_match_pandas():
    df = _books()
    data, total = cd.prep_aggregate(df, "rating_stars", sort="label")
    expected = df["rating_stars"].value_counts().sort_index()
    assert data["value"].tolist() == expected.tolist()
    assert data["value"].sum() == len(df)


def test_mean_by_group_matches_pandas():
    df = _books()
    data, _ = cd.prep_aggregate(df, "rating_stars", "price_gbp", "mean", sort="label")
    expected = df.groupby("rating_stars")["price_gbp"].mean()
    assert np.allclose(data["value"].to_numpy(), expected.to_numpy())


def test_pie_sums_to_total_and_groups_other():
    df = _books()
    data, note = cd.prep_pie(df, "rating_stars", top_n=3)
    assert data["value"].sum() == len(df)
    assert data["label"].iloc[-1] == "Other"


def test_missing_values_are_not_filled():
    df = pd.DataFrame({"g": ["a", "a", "b", None], "v": [1.0, np.nan, 3.0, 4.0]})
    data, _ = cd.prep_aggregate(df, "g", "v", "mean", sort="label")
    assert dict(zip(data["label"], data["value"])) == {"a": 1.0, "b": 3.0, "(missing)": 4.0}
    d, _, dropped = cd.prep_hist(df, "v")
    assert len(d) == 3 and dropped == 1


def test_every_default_chart_builds_both_ways():
    df = _books()
    specs = cd.default_specs(df)
    for kind in cd.KINDS:
        assert specs[kind] is not None, kind
        fig = cp.build(kind, df, **specs[kind])
        assert len(fig.data) >= 1
        png = cs.render_png(kind, df, specs[kind], dpi=60)
        assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_bad_settings_raise_clear_errors():
    df = _books()
    for bad in ({"cat": "nope"}, {"cat": "rating_stars", "agg": "mean", "value": "title"}):
        try:
            cp.build("bar", df, **bad)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_insights_and_tables():
    df = _books()
    insights = an.generate_insights(df)
    assert any("1,000 rows" in s for s in insights)
    assert not an.numeric_summary(df).empty
    assert not an.categorical_summary(df).empty
    assert an.correlation_matrix(df) is not None


def test_exports_and_pdf():
    df = _books()
    specs = cd.default_specs(df)
    import zipfile
    z = zipfile.ZipFile(io.BytesIO(ex.build_zip(df, specs, "books_data.csv", an.generate_insights(df))))
    names = z.namelist()
    assert "charts/bar_chart.png" in names and "analysis/analysis_report.md" in names
    assert rp.build_pdf(df, "books_data.csv")[:4] == b"%PDF"


def test_filtered_subset_still_works():
    df = _books()
    sub = df[df["rating_stars"] >= 4]
    assert len(sub) == 375
    assert rp.build_pdf(sub, "books_data.csv", total_rows=len(df))[:4] == b"%PDF"


def test_streamlit_app_runs_without_errors():
    try:
        from streamlit.testing.v1 import AppTest
    except Exception:
        print("  (streamlit.testing not available - skipped)")
        return
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=120).run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(at.tabs) == 9


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"PASS  {name}")
        except Exception as exc:
            failed += 1
            print(f"FAIL  {name}: {exc!r}")
    print(f"\n{len(tests) - failed}/{len(tests)} tests passed")
    sys.exit(1 if failed else 0)
