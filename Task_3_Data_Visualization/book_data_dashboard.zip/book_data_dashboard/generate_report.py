"""
generate_report.py
==================
Creates the PDF report (and a set of sample chart images) from the real dataset,
without opening the dashboard.

Usage:
    python generate_report.py                    # uses data/books_data.csv
    python generate_report.py --csv my_file.csv  # uses another CSV file

Output:
    reports/Book_Data_Visualization_Report.pdf
    sample_outputs/*.png, sample_outputs/analysis_report.md
"""
import argparse
import sys
from pathlib import Path

from src import analysis as an
from src import chart_data as cd
from src import charts_static as cs
from src import data_loader as dl
from src import exports as ex
from src import report as rp

ROOT = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the PDF report from a CSV file.")
    parser.add_argument("--csv", help="Path to a CSV file (default: the bundled data/ dataset).")
    args = parser.parse_args()

    path = Path(args.csv) if args.csv else dl.find_default_dataset()
    if path is None or not Path(path).exists():
        print("No dataset found. Put your CSV in the data/ folder or pass --csv path/to/file.csv")
        return 1
    try:
        df = dl.load_csv(str(path))
    except dl.DataLoadError as exc:
        print(f"Could not load the dataset: {exc}")
        return 1

    specs = cd.default_specs(df)
    insights = an.generate_insights(df)

    reports_dir = ROOT / "reports"
    samples_dir = ROOT / "sample_outputs"
    reports_dir.mkdir(exist_ok=True)
    samples_dir.mkdir(exist_ok=True)

    pdf_path = reports_dir / "Book_Data_Visualization_Report.pdf"
    pdf_path.write_bytes(rp.build_pdf(df, Path(path).name, specs, insights))
    print(f"PDF report written to: {pdf_path}")

    for kind, params in specs.items():
        if params:
            (samples_dir / f"{kind}_chart.png").write_bytes(cs.render_png(kind, df, params))
    heat = cs.correlation_figure(df)
    if heat is not None:
        (samples_dir / "correlation_heatmap.png").write_bytes(cs.fig_to_png_bytes(heat))
    (samples_dir / "analysis_report.md").write_text(
        ex.analysis_markdown(df, Path(path).name, insights), encoding="utf-8")
    print(f"Sample charts and analysis written to: {samples_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
