# Project Documentation – Interactive Book Data Visualization Dashboard

## 1. Purpose

Provide an interactive, beginner-friendly way to explore a CSV of book data: visual charts, statistical summaries,
automatically written insights, filters and downloadable results. The project follows one rule above all:
**use only the real dataset – no fake data, no assumed or filled-in missing values.**

## 2. Dataset discovery

The EDA project contained one data file, `books_data.csv`, which is bundled as `data/books_data.csv`.

| Column | Type | Meaning | Observed values |
|---|---|---|---|
| `title` | text | Book title | 999 distinct for 1,000 rows (one title appears twice) |
| `price_gbp` | decimal | Price in British pounds | 10.00 – 59.99 |
| `rating_stars` | integer | Star rating | 1 – 5 |
| `rating_text` | text | Rating as a word | One … Five |
| `availability` | text | Stock status text | "In stock" in every row |
| `in_stock` | true/false | Stock flag | True in every row |
| `page_number` | integer | Catalogue page the book was listed on | 1 – 50 (20 books per page) |
| `product_url` | text | Link to the product page | unique per row |

Quality checks (calculated, not assumed): 1,000 rows, 0 missing cells, 0 duplicate rows.

If the `data/` folder holds no CSV the app shows an upload prompt and nothing else; no placeholder charts are drawn.

## 3. Architecture

```
                 ┌────────────┐   CSV bytes    ┌─────────────────┐
 data/ or upload ─▶ data_loader ├───DataFrame───▶ filters (sidebar)│
                 └────────────┘                └────────┬────────┘
                                                        │ filtered DataFrame
        ┌───────────────────────┬───────────────────────┼──────────────────────┐
        ▼                       ▼                       ▼                      ▼
  chart_data.py           analysis.py             exports.py              report.py
 (prep numbers)      (summaries, insights)   (CSV / MD / ZIP)          (PDF report)
   │         │
   ▼         ▼
charts_plotly   charts_static
(interactive)   (PNG: Matplotlib+Seaborn)
        └──────────── app.py (Streamlit UI) ────────────┘
```

**Key design idea:** `chart_data.py` prepares the numbers once. Both chart engines draw from the same prepared
table, so the interactive chart, the PNG download and the PDF figure always agree.

## 4. Module reference

| File | Responsibility |
|---|---|
| `app.py` | Page layout, widgets, tabs, download buttons. Contains no analysis logic. |
| `src/data_loader.py` | `load_csv()` (tries several encodings, detects `;`/tab delimiters, friendly `DataLoadError`s); `find_default_dataset()`; `column_roles()` – classifies columns (numeric, category, group-able, ID-like…). |
| `src/chart_data.py` | `prep_aggregate`, `prep_pie`, `prep_line`, `prep_hist`, `prep_scatter`, `prep_box`; chart titles; `describe_chart()` captions; `default_specs()` picks sensible starting columns. |
| `src/charts_plotly.py` | `build(kind, df, **settings)` → Plotly figure; `to_html_bytes()`. |
| `src/charts_static.py` | `build()` → Matplotlib figure, `render_png()`, `correlation_figure()` (Seaborn heatmap). |
| `src/analysis.py` | `dataset_overview`, `column_summary`, `numeric_summary`, `categorical_summary`, `correlation_matrix`, `group_summary`, `generate_insights`. |
| `src/filters.py` | Builds sidebar filters from the columns and returns the filtered DataFrame + a list of active filters. |
| `src/exports.py` | CSV bytes, Markdown analysis report, ZIP bundle. |
| `src/report.py` | `build_pdf()` using ReportLab. |
| `generate_report.py` | Command-line PDF + sample-image generator. |
| `tests/test_core.py` | Self-checks (see §9). |

## 5. How each chart works

| Chart | Data preparation | Notes |
|---|---|---|
| **Bar** | Group by a category column; show row count or Mean/Median/Sum/Min/Max of a numeric column. | Order: largest first or natural (1,2,3 / A,B,C). Max categories slider. Vertical or horizontal. |
| **Line** | Group by X (number, date or category); aggregate Y; optional split into several lines. | Points are joined in order of X. For this dataset X = `page_number`, which is *listing order, not time*. |
| **Pie** | Count (or sum) per category; smallest slices merged into "Other" beyond *Max slices*. | Only count/sum are offered because averages cannot form a "whole". Zero/negative totals are excluded and reported. |
| **Histogram** | Numeric column split into N bins; optional colour by group. | Seaborn version adds a density curve (NumPy Gaussian KDE). |
| **Scatter** | Two numeric columns; optional colour, size and hover label. | Linear trend uses `numpy.polyfit`; Pearson r is shown. More than 20,000 points → random sample displayed, statistics use all rows. |
| **Box** | Numeric column, optionally grouped. | Whiskers follow the 1.5 × IQR rule. |

## 6. Missing values & honesty rules

* Values are **never imputed**.
* A chart drops only the rows lacking the columns *that chart* needs.
* Missing category labels appear as `(missing)`, never silently removed.
* Histograms/scatter plots state how many rows were skipped where relevant.
* Filters only act when you change them from their default, so rows with missing values are not removed by accident.
* The only conversion done on load: text columns whose name contains "date"/"time" and where ≥95% of values parse as dates become real dates.

## 7. Statistics & insights

The *Statistics & Insights* tab and the PDF/Markdown reports use `analysis.py`:

* Numeric summary: count, mean, std, min, quartiles, median, max, skewness, kurtosis, IQR-outlier count.
* Text summary: distinct values, most common value, share.
* Correlation: Pearson or Spearman (Spearman = Pearson on ranks); shown as a Seaborn heatmap.
* Insights are sentences built from computed values: size, missing values, duplicates, repeated near-unique values,
  constant columns, distribution shape, most common categories, strongest numeric correlation (with a reminder that
  correlation ≠ causation) and the biggest group difference in the main value column (groups under 5 rows ignored).

## 8. Filters

| Column type | Filter |
|---|---|
| Numeric with > 12 distinct values | Range slider |
| Date columns | Date-range slider |
| Text / true-false / numeric with 2–30 distinct values | Multi-select (first 4 visible, others under "More filters") |
| Long text (e.g. title) | "Contains" search box |

Columns with only one value, and ID-like columns (e.g. URLs), get no filter widget.

## 9. Verification performed during development

* `tests/test_core.py` – 12 checks: data loads unchanged; bar counts and group means equal plain-pandas results;
  pie slices sum to the total; missing values are not filled; all six charts build in Plotly and Matplotlib;
  bad settings give clear errors; ZIP/PDF exports build; the Streamlit app starts without errors.
* Interactive stress test with Streamlit's `AppTest`: every dropdown option, radio and checkbox was cycled
  (about 90 combinations) on the real dataset and again on a deliberately messy test file (missing values, dates,
  negative numbers, a constant column) – no errors.
* Clean-install checks: `pip install -r requirements.txt` in a fresh virtual environment (Python 3.12, Streamlit 1.67,
  Pandas 3, Plotly 7) and in a second environment with older versions (Streamlit 1.40, Pandas 2.2, Plotly 5.24);
  all 12 self-checks passed in both. The app does not need SciPy.
* Server check: `streamlit run app.py` starts and answers HTTP 200.
* Loader edge cases: empty file, header-only file, semicolon-delimited and Latin-1 files.
* Insight numbers were cross-checked against direct pandas calculations.

## 10. Limitations

* Results describe the supplied file only – not all books everywhere.
* A line chart over a non-time column (such as `page_number`) shows order, not a trend over time.
* Category order for text categories (e.g. month names) is alphabetical; use *Largest first* or numeric columns for other orders.
* HTML chart downloads load Plotly from the internet.
* Very large CSVs (hundreds of thousands of rows) work but chart rendering slows down.

## 11. Extending the project

* **New chart type:** add a `prep_…` function in `chart_data.py`, a builder in `charts_plotly.py` and `charts_static.py`, add it to `KINDS`, then add a tab in `app.py`.
* **New insight:** append a sentence in `analysis.generate_insights()`.
* **New filter type:** extend `filters.render_filters()`.
* **Different dataset:** just upload it – columns are detected automatically.
