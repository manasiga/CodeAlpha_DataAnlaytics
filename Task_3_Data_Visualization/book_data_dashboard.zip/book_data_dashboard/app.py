"""
Interactive Book Data Visualization Dashboard
=============================================
Run with:   streamlit run app.py

Layout of this file (top to bottom):
  1. Page setup
  2. Load the data (bundled CSV, or a CSV you upload in the sidebar)
  3. Sidebar filters
  4. Summary numbers
  5. One tab per chart + statistics + downloads
"""
from __future__ import annotations

import hashlib
import io
import json

import pandas as pd
import streamlit as st

from src import analysis as an
from src import chart_data as cd
from src import charts_plotly as cp
from src import charts_static as cs
from src import data_loader as dl
from src import exports as ex
from src import filters as flt
from src import report as rp

# --------------------------------------------------------------------------- #
# 1. Page setup
# --------------------------------------------------------------------------- #
st.set_page_config(page_title="Book Data Visualization Dashboard", page_icon="📚", layout="wide")

st.title("📚 Interactive Book Data Visualization Dashboard")
st.caption("Explore your book data with interactive charts, statistics and downloads. "
           "Only your real data is used - nothing is made up and missing values are never filled in.")


# --------------------------------------------------------------------------- #
# 2. Load the data
# --------------------------------------------------------------------------- #
@st.cache_data(show_spinner="Reading the CSV file...")
def load_bundled(path: str, modified: float) -> pd.DataFrame:
    return dl.load_csv(path)


@st.cache_data(show_spinner="Reading the uploaded CSV...")
def load_uploaded(raw: bytes, name: str) -> pd.DataFrame:
    return dl.load_csv(io.BytesIO(raw))


@st.cache_data(show_spinner=False, max_entries=64)
def png_for(kind: str, df: pd.DataFrame, params: dict) -> bytes:
    """Static PNG of a chart (cached so it is not redrawn on every click)."""
    return cs.render_png(kind, df, params)


st.sidebar.header("📂 Data")
uploaded = st.sidebar.file_uploader(
    "Upload your own CSV (optional)", type=["csv"],
    help="Leave empty to use the bundled dataset in the data/ folder.")

df_full = None
source_name = ""
try:
    if uploaded is not None:
        df_full = load_uploaded(uploaded.getvalue(), uploaded.name)
        source_name = uploaded.name
    else:
        default_path = dl.find_default_dataset()
        if default_path is not None:
            df_full = load_bundled(str(default_path), default_path.stat().st_mtime)
            source_name = default_path.name
except dl.DataLoadError as exc:
    st.sidebar.error(str(exc))
    st.error(f"⚠️ {exc}")
    st.stop()

if df_full is None:
    st.warning("📂 **No dataset found.** Upload your CSV file using the sidebar on the left "
               "(or place it in the `data/` folder as `books_data.csv`). "
               "No charts or statistics are shown until real data is loaded.")
    st.stop()

dataset_key = hashlib.md5((source_name + "|" + "|".join(df_full.columns) + f"|{len(df_full)}")
                          .encode()).hexdigest()[:8]
st.sidebar.success(f"Using **{source_name}** ({len(df_full):,} rows × {df_full.shape[1]} columns)")

# --------------------------------------------------------------------------- #
# 3. Filters
# --------------------------------------------------------------------------- #
df, active_filters = flt.render_filters(df_full, dataset_key)

if df.empty:
    st.warning("No rows match the current filters. Widen a filter or press **Reset all filters** "
               "in the sidebar.")
    st.stop()

roles = dl.column_roles(df_full)
defaults = cd.default_specs(df_full)
specs: dict = {}          # the settings of every chart that is currently drawn

# --------------------------------------------------------------------------- #
# 4. Summary numbers
# --------------------------------------------------------------------------- #
ov = an.dataset_overview(df)
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Rows shown", f"{len(df):,}")
if len(df) != len(df_full):
    m1.caption(f"out of {len(df_full):,} in the file")
m2.metric("Columns", ov["columns"])
m3.metric("Numeric columns", ov["numeric_columns"])
m4.metric("Missing cells", f"{ov['missing_cells']:,}")
m5.metric("Duplicate rows", f"{ov['duplicate_rows']:,}")
if active_filters:
    st.info("**Active filters:** " + " · ".join(active_filters))


# --------------------------------------------------------------------------- #
# Helpers for the chart tabs
# --------------------------------------------------------------------------- #
def k(*parts) -> str:
    """Unique widget key (includes the dataset id so options never get mixed up)."""
    return ":".join([dataset_key, *map(str, parts)])


def idx(options, value) -> int:
    """Index of `value` inside `options` (0 if not found)."""
    try:
        return list(options).index(value)
    except ValueError:
        return 0


NONE = "(none)"


def opt_with_none(options):
    return [NONE] + list(options)


def none_to_none(v):
    return None if v == NONE else v


def show_chart(kind: str, params: dict, file_stub: str):
    """Draw the interactive chart, a caption, and the download buttons."""
    try:
        fig = cp.build(kind, df, **params)
    except Exception as exc:
        st.warning(f"This chart cannot be drawn with the current settings: {exc}")
        return
    specs[kind] = params
    st.plotly_chart(fig, key=k(kind, "chart"))
    caption = cd.describe_chart(kind, df, params)
    if caption:
        st.caption("📝 " + caption)
    c1, c2, _ = st.columns([1, 1, 3])
    try:
        c1.download_button("⬇️ Download PNG", png_for(kind, df, params), f"{file_stub}.png",
                           "image/png", key=k(kind, "png"))
    except Exception as exc:
        c1.caption(f"PNG unavailable: {exc}")
    c2.download_button("⬇️ Download interactive HTML", cp.to_html_bytes(fig, full_offline=False),
                       f"{file_stub}.html", "text/html", key=k(kind, "html"),
                       help="Open in any browser. Needs an internet connection to load the Plotly library.")


def needs(message: str):
    st.info(message)


# --------------------------------------------------------------------------- #
# 5. Tabs
# --------------------------------------------------------------------------- #
tabs = st.tabs(["🏠 Overview", "📊 Bar", "📈 Line", "🥧 Pie", "📉 Histogram", "🔵 Scatter",
                "📦 Box", "🧮 Statistics & Insights", "⬇️ Downloads"])
(t_over, t_bar, t_line, t_pie, t_hist, t_scatter, t_box, t_stats, t_down) = tabs

AGG_OPTIONS = cd.AGG_FUNCS
numeric_cols = roles["numeric"]
category_cols = roles["category_cols"]
group_cols = roles["group_cols"]

# ---- Overview ------------------------------------------------------------- #
with t_over:
    st.subheader("Dataset preview")
    st.caption("This is the data after your sidebar filters. Click a column header to sort.")
    st.dataframe(df.head(1000))
    if len(df) > 1000:
        st.caption(f"Showing the first 1,000 of {len(df):,} rows.")
    st.subheader("Columns")
    st.caption("Type, missing values and number of distinct values for every column.")
    st.dataframe(an.column_summary(df))

# ---- Bar ------------------------------------------------------------------ #
with t_bar:
    st.subheader("📊 Bar chart")
    d = defaults["bar"]
    if not d:
        needs("A bar chart needs at least one category column (text, true/false or a number with few distinct values).")
    else:
        c1, c2, c3, c4 = st.columns(4)
        cat = c1.selectbox("Category (X axis)", category_cols, idx(category_cols, d["cat"]), key=k("bar", "cat"))
        agg = c2.selectbox("What to show", AGG_OPTIONS, idx(AGG_OPTIONS, "count"),
                           format_func=lambda a: cd.AGG_LABELS[a], key=k("bar", "agg"))
        value = None
        if agg != "count":
            if numeric_cols:
                default_value = cd.pick_column(roles["continuous"] or numeric_cols, cd.VALUE_PREFS)
                value = c3.selectbox("Numeric column", numeric_cols, idx(numeric_cols, default_value),
                                     key=k("bar", "value"))
            else:
                c3.warning("No numeric columns available.")
                agg = "count"
        sort = c4.radio("Order", ["value", "label"], idx(["value", "label"], d["sort"]),
                        format_func=lambda s: "Largest first" if s == "value" else "Natural (1,2,3 / A,B,C)",
                        key=k("bar", "sort"))
        c5, c6, _ = st.columns([1, 1, 2])
        top_n = c5.slider("Max categories", 3, 50, d["top_n"], key=k("bar", "top"))
        orient = c6.radio("Direction", ["v", "h"], format_func=lambda o: "Vertical" if o == "v" else "Horizontal",
                          horizontal=True, key=k("bar", "orient"))
        show_chart("bar", dict(cat=cat, value=value, agg=agg, sort=sort, top_n=top_n, orientation=orient),
                   "bar_chart")

# ---- Line ----------------------------------------------------------------- #
with t_line:
    st.subheader("📈 Line chart")
    d = defaults["line"]
    if not d:
        needs("A line chart needs a column for the X axis (number, date or category).")
    else:
        x_pool = roles["datetime"] + numeric_cols + [c for c in category_cols if c not in numeric_cols]
        c1, c2, c3, c4 = st.columns(4)
        x = c1.selectbox("X axis", x_pool, idx(x_pool, d["x"]), key=k("line", "x"))
        agg = c2.selectbox("What to show", AGG_OPTIONS, idx(AGG_OPTIONS, d["agg"]),
                           format_func=lambda a: cd.AGG_LABELS[a], key=k("line", "agg"))
        y = None
        if agg != "count":
            y_pool = [c for c in numeric_cols if c != x] or numeric_cols
            y = c3.selectbox("Y axis (numeric)", y_pool, idx(y_pool, d["y"]), key=k("line", "y"))
        group_opts = opt_with_none([c for c in group_cols if c != x])
        group = none_to_none(c4.selectbox("Split into lines by", group_opts, 0, key=k("line", "group")))
        markers = st.checkbox("Show markers", d["markers"], key=k("line", "markers"))
        if x in roles["category_cols"] and x not in numeric_cols:
            st.caption("ℹ️ The X axis is a category, so points are joined in alphabetical order.")
        elif x in numeric_cols or x in roles["datetime"]:
            st.caption(f"ℹ️ Each point is the {cd.AGG_LABELS[agg].lower()} for one distinct value of {x}, "
                       "joined in order of that value.")
        show_chart("line", dict(x=x, y=y, agg=agg, group=group, markers=markers), "line_chart")

# ---- Pie ------------------------------------------------------------------ #
with t_pie:
    st.subheader("🥧 Pie chart")
    d = defaults["pie"]
    if not d:
        needs("A pie chart needs at least one category column.")
    else:
        c1, c2, c3, c4 = st.columns(4)
        cat = c1.selectbox("Category", category_cols, idx(category_cols, d["cat"]), key=k("pie", "cat"))
        agg = c2.selectbox("Slice size =", ["count", "sum"], 0,
                           format_func=lambda a: "Number of rows" if a == "count" else "Sum of a numeric column",
                           key=k("pie", "agg"))
        value = None
        if agg == "sum":
            if numeric_cols:
                value = c3.selectbox("Numeric column", numeric_cols, 0, key=k("pie", "value"))
            else:
                c3.warning("No numeric columns available.")
                agg = "count"
        top_n = c4.slider("Max slices", 2, 15, d["top_n"], key=k("pie", "top"))
        c5, c6, _ = st.columns([1, 1, 2])
        sort = c5.radio("Order", ["value", "label"], idx(["value", "label"], d["sort"]),
                        format_func=lambda s: "Largest first" if s == "value" else "Natural",
                        key=k("pie", "sort"))
        donut = c6.checkbox("Donut style", d["donut"], key=k("pie", "donut"))
        show_chart("pie", dict(cat=cat, value=value, agg=agg, top_n=top_n, sort=sort, donut=donut),
                   "pie_chart")

# ---- Histogram ------------------------------------------------------------ #
with t_hist:
    st.subheader("📉 Histogram")
    d = defaults["hist"]
    if not d:
        needs("A histogram needs at least one numeric column.")
    else:
        c1, c2, c3, c4 = st.columns(4)
        col = c1.selectbox("Numeric column", numeric_cols, idx(numeric_cols, d["col"]), key=k("hist", "col"))
        bins = c2.slider("Number of bins", 5, 100, d["bins"], key=k("hist", "bins"))
        group = none_to_none(c3.selectbox("Colour by", opt_with_none([c for c in group_cols if c != col]), 0,
                                          key=k("hist", "group")))
        norm = c4.radio("Y axis", ["count", "percent"], format_func=str.title, horizontal=True,
                        key=k("hist", "norm"))
        marg = st.selectbox("Extra plot above histogram", [NONE, "box", "violin", "rug"], 0,
                            key=k("hist", "marg"))
        show_chart("hist", dict(col=col, bins=bins, group=group, histnorm=norm,
                                marginal=none_to_none(marg), show_kde=True), "histogram")

# ---- Scatter -------------------------------------------------------------- #
with t_scatter:
    st.subheader("🔵 Scatter plot")
    d = defaults["scatter"]
    if not d:
        needs("A scatter plot needs at least two numeric columns.")
    else:
        c1, c2, c3, c4 = st.columns(4)
        x = c1.selectbox("X axis", numeric_cols, idx(numeric_cols, d["x"]), key=k("sc", "x"))
        y_pool = [c for c in numeric_cols if c != x] or numeric_cols
        y = c2.selectbox("Y axis", y_pool, idx(y_pool, d["y"]), key=k("sc", "y"))
        color_opts = opt_with_none(group_cols)
        color = none_to_none(c3.selectbox("Colour by", color_opts, idx(color_opts, d["color"] or NONE),
                                          key=k("sc", "color")))
        size_opts = opt_with_none(numeric_cols)
        size = none_to_none(c4.selectbox("Point size by", size_opts, 0, key=k("sc", "size")))
        c5, c6, c7 = st.columns(3)
        trend = c5.checkbox("Show linear trend line", True, key=k("sc", "trend"))
        opacity = c6.slider("Point opacity", 0.1, 1.0, 0.65, 0.05, key=k("sc", "opacity"))
        hover_opts = opt_with_none(roles["text_cols"])
        hover = none_to_none(c7.selectbox("Hover label", hover_opts, idx(hover_opts, d["hover_name"] or NONE),
                                          key=k("sc", "hover")))
        show_chart("scatter", dict(x=x, y=y, color=color, size=size, trendline=trend, opacity=opacity,
                                   hover_name=hover, max_points=20000), "scatter_plot")

# ---- Box ------------------------------------------------------------------ #
with t_box:
    st.subheader("📦 Box plot")
    d = defaults["box"]
    if not d:
        needs("A box plot needs at least one numeric column.")
    else:
        c1, c2, c3 = st.columns(3)
        y = c1.selectbox("Numeric column", numeric_cols, idx(numeric_cols, d["y"]), key=k("box", "y"))
        g_opts = opt_with_none([c for c in group_cols if c != y])
        group = none_to_none(c2.selectbox("Group by", g_opts, idx(g_opts, d["group"] or NONE),
                                          key=k("box", "group")))
        points = c3.selectbox("Show points", ["outliers", "all", "none"], 0, key=k("box", "points"))
        show_chart("box", dict(y=y, group=group, points=points), "box_plot")

# ---- Statistics & insights ------------------------------------------------ #
insights = an.generate_insights(df)
with t_stats:
    st.subheader("💡 Key insights")
    st.caption("Every sentence below is calculated from the rows currently shown (after filters).")
    for line in insights:
        st.markdown(f"- {line}")

    st.subheader("Numeric summary")
    num_tbl = an.numeric_summary(df)
    if num_tbl.empty:
        st.info("This data has no numeric columns.")
    else:
        st.dataframe(num_tbl)
        st.caption("Skew near 0 = symmetric; positive = long tail of high values; negative = long tail of low "
                   "values. Outliers use the 1.5 × IQR rule.")

    st.subheader("Text and true/false columns")
    cat_tbl = an.categorical_summary(df)
    if cat_tbl.empty:
        st.info("This data has no text columns.")
    else:
        st.dataframe(cat_tbl)

    st.subheader("Correlation heatmap")
    method = st.radio("Method", ["pearson", "spearman"], horizontal=True, format_func=str.title,
                      key=k("corr", "method"),
                      help="Pearson = straight-line relationship. Spearman = ranks (any steadily rising/falling pattern).")
    heat = cs.correlation_figure(df, method)
    if heat is None:
        st.info("At least two numeric columns that vary are needed for a correlation heatmap.")
    else:
        st.pyplot(heat)
        st.download_button("⬇️ Download heatmap PNG", cs.fig_to_png_bytes(heat), "correlation_heatmap.png",
                           "image/png", key=k("corr", "png"))

    st.subheader("Compare groups")
    if group_cols and roles["numeric"]:
        g1, g2 = st.columns(2)
        gcol = g1.selectbox("Group by", group_cols, 0, key=k("grp", "g"))
        vcols = [c for c in roles["numeric"] if c != gcol] or roles["numeric"]
        vcol = g2.selectbox("Numeric column", vcols, idx(vcols, cd.pick_column(vcols, cd.VALUE_PREFS)),
                            key=k("grp", "v"))
        st.dataframe(an.group_summary(df, gcol, vcol))
    else:
        st.info("Group comparison needs one grouping column and one numeric column.")

# ---- Downloads ------------------------------------------------------------ #
with t_down:
    st.subheader("⬇️ Download your results")
    st.caption("Individual charts can be downloaded under each chart tab. Everything here reflects the "
               "rows currently shown (after filters).")

    d1, d2 = st.columns(2)
    with d1:
        st.markdown("**Data and tables (CSV)**")
        st.download_button("Filtered data", ex.df_to_csv_bytes(df), "filtered_data.csv", "text/csv",
                           key=k("dl", "data"))
        for name, table in ex.analysis_tables(df).items():
            st.download_button(name.replace("_", " ").title(), ex.df_to_csv_bytes(table),
                               f"{name}.csv", "text/csv", key=k("dl", name))
    with d2:
        st.markdown("**Analysis report (Markdown / text)**")
        md = ex.analysis_markdown(df, source_name, insights, active_filters, len(df_full))
        st.download_button("Analysis report (.md)", md.encode("utf-8"), "analysis_report.md",
                           "text/markdown", key=k("dl", "md"))

    st.divider()
    sig = hashlib.md5((json.dumps(specs, sort_keys=True, default=str) + f"|{len(df)}|{df.shape}|{source_name}|"
                       + "|".join(active_filters)).encode()).hexdigest()

    b1, b2 = st.columns(2)
    with b1:
        st.markdown("**📄 PDF report**")
        st.caption("Full report with charts, tables and insights for the rows currently shown.")
        if st.button("Generate PDF report", key=k("dl", "pdfbtn")):
            with st.spinner("Building PDF..."):
                try:
                    st.session_state["pdf"] = (sig, rp.build_pdf(df, source_name, specs, insights,
                                                                 active_filters, len(df_full)))
                except Exception as exc:
                    st.error(f"Could not build the PDF: {exc}")
        pdf = st.session_state.get("pdf")
        if pdf and pdf[0] == sig:
            st.download_button("⬇️ Download PDF report", pdf[1], "book_data_report.pdf",
                               "application/pdf", key=k("dl", "pdf"))
        elif pdf:
            st.caption("Settings or filters changed - press the button again to refresh the PDF.")
    with b2:
        st.markdown("**🗜️ Everything in one ZIP**")
        st.caption("All charts (PNG + HTML), all tables (CSV), filtered data and the analysis report.")
        if st.button("Prepare ZIP bundle", key=k("dl", "zipbtn")):
            with st.spinner("Packing files..."):
                try:
                    st.session_state["zip"] = (sig, ex.build_zip(df, specs, source_name, insights,
                                                                 active_filters, len(df_full)))
                except Exception as exc:
                    st.error(f"Could not build the ZIP: {exc}")
        zp = st.session_state.get("zip")
        if zp and zp[0] == sig:
            st.download_button("⬇️ Download ZIP", zp[1], "book_dashboard_results.zip", "application/zip",
                               key=k("dl", "zip"))
        elif zp:
            st.caption("Settings or filters changed - press the button again to refresh the ZIP.")
