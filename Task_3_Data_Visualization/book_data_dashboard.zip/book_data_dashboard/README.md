# 📚 Interactive Book Data Visualization Dashboard

A beginner-friendly **Streamlit** dashboard that turns a CSV file of book data into interactive charts,
statistics and downloadable results. Built with **Python, Pandas, NumPy, Matplotlib, Seaborn, Plotly and Streamlit**.

> **Honest-data promise:** the dashboard only ever uses the real CSV file. It never generates sample data,
> never guesses, and **never fills in missing values**.

---

## What data does this project use?

The only dataset found in your EDA files was the uploaded **`books_data.csv`**, so it is bundled at
`data/books_data.csv` and used automatically.

| Fact | Value |
|---|---|
| Rows × columns | 1,000 × 8 |
| Missing values | 0 |
| Duplicate rows | 0 |
| Columns | `title`, `price_gbp`, `rating_stars`, `rating_text`, `availability`, `in_stock`, `page_number`, `product_url` |

No other processed/cleaned dataset was found, so nothing else was used.
If you later want to analyse a **different CSV**, use the **upload box in the sidebar** – no code changes needed.
If the `data/` folder has no CSV at all, the app shows an upload prompt and displays **no charts or statistics**
until real data is loaded.

---

## Features

| # | Feature | Where |
|---|---|---|
| 1 | Interactive dashboard (9 tabs) | `app.py` |
| 2 | Bar chart (count, mean, median, sum, min, max) | 📊 Bar tab |
| 3 | Line chart (aggregate by any X, optional split into several lines) | 📈 Line tab |
| 4 | Pie / donut chart (small slices merged into "Other") | 🥧 Pie tab |
| 5 | Histogram (bins, colour by group, box/violin/rug on top) | 📉 Histogram tab |
| 6 | Scatter plot (colour, size, hover label, linear trend line, r value) | 🔵 Scatter tab |
| 7 | Box plot (grouped, show outliers / all points) | 📦 Box tab |
| 8 | Dataset summary, statistics, correlation heatmap, auto-written insights, group comparison | 🏠 Overview + 🧮 Statistics tabs |
| 9 | Interactive filters (sliders, multi-selects, text search, reset button) | Sidebar |
| 10 | Downloads: chart PNG + interactive HTML, CSV tables, Markdown report, PDF report, ZIP bundle | under each chart + ⬇️ Downloads tab |

Every chart has a one-line, data-driven caption (for example the highest/lowest category or the correlation value).

---

## Project folder

```
book_data_dashboard/
├── app.py                  ← the Streamlit dashboard (start here)
├── generate_report.py      ← builds the PDF report from the command line
├── requirements.txt        ← libraries to install
├── README.md               ← this file
├── data/
│   └── books_data.csv      ← your real dataset
├── src/
│   ├── data_loader.py      ← reads the CSV, detects column types
│   ├── chart_data.py       ← prepares numbers for charts (shared by both chart engines)
│   ├── charts_plotly.py    ← interactive charts (Plotly)
│   ├── charts_static.py    ← image charts (Matplotlib + Seaborn)
│   ├── analysis.py         ← summaries, statistics, insights
│   ├── filters.py          ← sidebar filters
│   ├── exports.py          ← CSV / Markdown / ZIP exports
│   └── report.py           ← PDF report builder
├── tests/test_core.py      ← self-checks
├── docs/PROJECT_DOCUMENTATION.md
├── reports/Book_Data_Visualization_Report.pdf
└── sample_outputs/         ← example PNG charts + analysis report
```

---

## How to run (step by step)

You need **Python 3.9 or newer**. Check with `python --version` (or `python3 --version`).

### 1. Open a terminal in the project folder
Unzip the project, then open a terminal (Windows: *Command Prompt* or *PowerShell*; macOS/Linux: *Terminal*) and move into the folder:

```bash
cd book_data_dashboard
```

### 2. (Recommended) create a virtual environment

**Windows**
```bash
python -m venv venv
venv\Scripts\activate
```
**macOS / Linux**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install the libraries
```bash
pip install -r requirements.txt
```

### 4. Start the dashboard
```bash
streamlit run app.py
```
Your browser opens at **http://localhost:8501**. (If it does not, copy that address into your browser.)
Press **Ctrl + C** in the terminal to stop the app.

---

## Using the dashboard

1. **Sidebar → 📂 Data** – the bundled `books_data.csv` loads automatically. To use another file, drop a CSV into *Upload your own CSV*.
2. **Sidebar → 🎛️ Filters** – narrow the data (price range, rating, page range, title search…). Every tab updates instantly. *Reset all filters* puts everything back.
3. **Tabs** – each chart tab has dropdowns/sliders at the top. Hover, zoom, pan and click legend items on the chart.
4. **🧮 Statistics & Insights** – plain-English insights, summary tables, correlation heatmap and group comparison.
5. **⬇️ Downloads** – CSV tables, analysis report, a PDF report and a ZIP with everything. Each chart tab also has *Download PNG* and *Download interactive HTML* buttons.

> Filters, chart settings and downloads always describe the rows **currently shown**.

### Notes about this dataset
* `page_number` is the page of the catalogue the book was listed on – **not a date** – so the line chart shows how the average price changes across catalogue pages.
* `availability` and `in_stock` have the same value in every row, so they carry no variation (the insights panel says so).
* `title` and `product_url` are almost all unique, so they are used for searching/hover labels rather than as chart categories.

### Using your own CSV
Any CSV with a header row works. Numeric columns, text columns, true/false columns and date columns
(column name containing "date" or "time") are detected automatically, and charts adapt to the columns that exist.
Missing values stay missing; a chart just skips rows that lack a needed value.

---

## Create the PDF report without opening the dashboard

```bash
python generate_report.py                   # uses data/books_data.csv
python generate_report.py --csv other.csv   # use another file
```
Creates `reports/Book_Data_Visualization_Report.pdf` and example images in `sample_outputs/`.

## Run the self-checks (optional)

```bash
python tests/test_core.py
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `streamlit: command not found` | Activate the virtual environment, or run `python -m streamlit run app.py` |
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again inside the activated environment |
| Page shows "No dataset found" | Put your CSV at `data/books_data.csv` or use the sidebar upload |
| "The file is empty / has no data rows" | Check the CSV opens correctly in Excel and has a header row and data |
| A chart says it cannot be drawn | Read the message – usually a column choice does not fit that chart (e.g. a non-numeric column for a mean). Pick another column. |
| "Download interactive HTML" shows a blank page offline | The HTML loads the Plotly library from the internet; open it while online |
| Port 8501 already in use | `streamlit run app.py --server.port 8502` |

## Tech stack
Python · Pandas · NumPy · Matplotlib · Seaborn · Plotly · Streamlit · ReportLab (PDF)
