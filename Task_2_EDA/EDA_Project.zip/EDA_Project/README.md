# Exploratory Data Analysis of Book Dataset

A beginner-friendly Python project that explores the **1,000 books** collected in the earlier
web scraping project from [books.toscrape.com](https://books.toscrape.com).
The project uses only the real scraped data in `data/books_data.csv`. No data is made up.

**Tools:** Python 3.13, Pandas, NumPy, Matplotlib, Seaborn

---

## 1. Project structure

```
EDA_Project/
├── main.py                  <- run this file; it does every step in order
├── eda_analysis.py          <- all the calculations (one function per step)
├── visualization.py         <- all the charts
├── requirements.txt         <- libraries to install
├── README.md                <- this guide
├── data/
│   └── books_data.csv       <- ORIGINAL scraped data (read only, never changed)
└── output/                  <- created/overwritten every time you run main.py
    ├── cleaned_data.csv         <- cleaned copy of the dataset
    ├── summary_statistics.csv   <- mean, median, mode, min, max, quartiles...
    ├── eda_report.txt           <- full written EDA report
    └── charts/
        ├── 01_price_distribution_histogram.png
        ├── 02_rating_distribution_bar_chart.png
        ├── 03_price_box_plot.png
        ├── 04_correlation_heatmap.png
        └── 05_average_price_by_rating.png
```

---

## 2. How to run it in VS Code (Windows / macOS / Linux)

1. **Install Python 3.13** from <https://www.python.org/downloads/>.
   On Windows, tick **"Add python.exe to PATH"** in the installer.
2. **Install VS Code** and the **Python** extension (by Microsoft) from the Extensions tab.
3. In VS Code, choose **File → Open Folder…** and open the `EDA_Project` folder.
4. Open a terminal: **Terminal → New Terminal**.
5. Create a virtual environment (a private box for this project's libraries):

   ```bash
   # Windows
   python -m venv .venv
   .venv\Scripts\activate

   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate
   ```

   You should now see `(.venv)` at the start of the terminal line.
   If VS Code asks *"We noticed a new environment… select it for the workspace?"*, click **Yes**.
   (Or press `Ctrl+Shift+P` → **Python: Select Interpreter** → pick the one with `.venv`.)

   > Windows PowerShell error "running scripts is disabled"? Run
   > `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once, then activate again.

6. Install the libraries:

   ```bash
   pip install -r requirements.txt
   ```

7. Run the analysis:

   ```bash
   python main.py
   ```

   (Or open `main.py` and click the **▶ Run Python File** button in the top-right corner.)

8. Open the `output` folder to see the cleaned CSV, the report and the charts.
   PNG charts open directly inside VS Code.

---

## 3. What each analysis step does (and why)

| Step | What it does | Why it matters |
|---|---|---|
| 1. Load data | Reads `books_data.csv` with pandas (`utf-8-sig` removes a hidden character at the start of the file). | All the analysis starts from the real scraped data. |
| 2. First & last 10 rows | Shows `head(10)` and `tail(10)`. | Confirms the file loaded correctly, from page 1 to page 50. |
| 3. Shape | Counts rows and columns. | Tells us how big the dataset is. |
| 4. Columns & data types | Lists every column with its type and number of unique values. | Numbers can be averaged; text cannot. |
| 5. Missing values | Counts empty cells per column. | Gaps can break calculations or skew results. |
| 6. Duplicates | Checks exact copies, repeated URLs and repeated titles. | The same book counted twice would distort averages. |
| 7. Cleaning | Makes a **separate copy**, trims spaces, fixes number types, drops empty or duplicate rows. | Clean data gives reliable results, and the original file stays safe. |
| 8. Mean / median / mode / min / max | Basic statistics for price and rating. | Shows the "typical" value and the extremes. |
| 9. Statistical summary | Quartiles (25%, 50%, 75%) and skewness. | Shows how values are spread and whether they lean one way. |
| 10. Price analysis | Groups prices into GBP 10 bands and checks for outliers with the IQR rule. | Shows how prices are spread across the shop. |
| 11. Rating analysis | Books and average price per star rating. | Shows how ratings are spread and if price changes with rating. |
| 12. Extremes | Top 5 most expensive and cheapest books. | Shows the top and bottom of the price range. |
| 13. Correlation & stock | Checks if price and rating move together, and the share of books in stock. | Tests whether pricier books are rated higher. |
| 14. Charts | Saves 5 PNG charts. | Patterns are easier to see than to read. |
| 15. Insights | Writes findings in plain English, calculated from the data. | Turns numbers into conclusions. |
| 16. Save outputs | Saves the cleaned CSV, summary statistics and report, and checks the original file is unchanged. | Gives you files you can reuse and share. |

---

## 4. Results in simple English

*(From the run on the provided `books_data.csv`. Exact values are in `output/eda_report.txt`.)*

**Data quality**
- 1,000 books, 8 columns, scraped from 50 catalogue pages.
- **No missing values** and **no duplicate records** (no repeated rows or URLs).
- One title, *The Star-Touched Queen*, appears twice. The two have different prices
  (GBP 46.02 and GBP 32.30) and different URLs, so they are separate listings and both are kept.
- The number rating (`rating_stars`) and the word rating (`rating_text`) match on every row.
- The cleaned dataset therefore still has all 1,000 books. Cleaning confirmed the data was already in good shape.

**Prices**
- Average price **GBP 35.07**, median **GBP 35.98**, from **GBP 10.00** to **GBP 59.99**.
- Prices are spread almost **evenly**: every GBP 10 band (10-20, 20-30 … 50-60) holds about 20% of the books.
- No unusual prices (outliers).
- Almost every price is unique (903 different prices), so the "mode" price appears only 3 times and is not useful here.
- Most expensive: *The Perfect Play (Play by Play #1)* at GBP 59.99.
  Cheapest: *An Abundance of Katherines* at GBP 10.00, which also has 5 stars, making it the best-value book.

**Ratings**
- Average rating **2.92 stars**. Median 3 stars.
- **1 star is the most common** rating (226 books, 22.6%). **4 stars is the least common** (179 books, 17.9%).
- 37.5% of books have 4-5 stars and 42.2% have 1-2 stars. Ratings are spread fairly evenly.

**Price vs rating**
- Correlation = **0.028**, which is basically **zero**.
  **A more expensive book is not more likely to have a better rating.**
- The average price per rating only ranges from GBP 34.56 (1 star) to GBP 36.09 (4 stars).

**Stock**
- **100% of books are in stock.**

> Note: books.toscrape.com is a practice website made for learning web scraping, so its prices
> and ratings are spread very evenly. Real shops usually show clearer patterns.

---

## 5. Notes

- The original `data/books_data.csv` is **never modified**. The script checks the file's
  fingerprint (MD5 hash) before and after running and confirms it in the report.
- Re-running `main.py` overwrites everything in `output/`.
- To analyse a newer scrape, replace `data/books_data.csv` with a file that has the same columns
  and run `python main.py` again. All numbers and insights are recalculated automatically.
