"""
eda_analysis.py
---------------
All the "number crunching" for the Book Dataset EDA lives in this file.

Each function does ONE analysis step and returns its result, so that
main.py can print it on screen and also write it into the EDA report.

Dataset columns (from the books.toscrape.com web scraping project):
    title         - book title
    price_gbp     - price in British Pounds (GBP)
    rating_stars  - star rating as a number (1 to 5)
    rating_text   - star rating as a word ("One" ... "Five")
    availability  - stock text, e.g. "In stock"
    in_stock      - True / False
    page_number   - catalogue page the book was scraped from (1 to 50)
    product_url   - link to the book's page (unique for every book)
"""

from pathlib import Path

import numpy as np
import pandas as pd


# Columns we will analyse as numbers
PRICE_COL = "price_gbp"
RATING_COL = "rating_stars"


# ---------------------------------------------------------------------------
# STEP 1 - Load the dataset
# ---------------------------------------------------------------------------
def load_data(csv_path: Path) -> pd.DataFrame:
    """
    Read the CSV file into a pandas DataFrame (a table in memory).

    - encoding="utf-8-sig" removes the invisible "BOM" character that some
      tools (like Excel) put at the very start of a CSV file. Without it the
      first column could be named "\\ufefftitle" instead of "title".
    - We only READ the file. The original CSV on disk is never changed.
    """
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Could not find the dataset at: {csv_path}\n"
            "Please put books_data.csv inside the 'data' folder."
        )
    df = pd.read_csv(csv_path, encoding="utf-8-sig")
    return df


# ---------------------------------------------------------------------------
# STEP 2 - First 10 and last 10 records
# ---------------------------------------------------------------------------
def first_and_last_records(df: pd.DataFrame, n: int = 10) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return the first n rows (head) and the last n rows (tail)."""
    # We hide the long URL column so the table fits nicely on screen.
    columns_to_show = [c for c in df.columns if c != "product_url"]
    return df[columns_to_show].head(n), df[columns_to_show].tail(n)


# ---------------------------------------------------------------------------
# STEP 3 - Shape (rows and columns)
# ---------------------------------------------------------------------------
def dataset_shape(df: pd.DataFrame) -> tuple[int, int]:
    """df.shape gives (number_of_rows, number_of_columns)."""
    rows, cols = df.shape
    return rows, cols


# ---------------------------------------------------------------------------
# STEP 4 - Column names and data types
# ---------------------------------------------------------------------------
def column_info(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build a small table describing each column:
    its data type, how many non-empty values it has and how many unique values.
    """
    info = pd.DataFrame(
        {
            "data_type": df.dtypes.astype(str),
            "non_null_count": df.notna().sum(),
            "unique_values": df.nunique(),
        }
    )
    info.index.name = "column"
    return info


# ---------------------------------------------------------------------------
# STEP 5 - Missing values
# ---------------------------------------------------------------------------
def missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Count empty (NaN) cells in each column and show it as a percentage."""
    missing_count = df.isna().sum()
    missing_percent = (missing_count / len(df) * 100).round(2)
    result = pd.DataFrame({"missing_count": missing_count, "missing_percent": missing_percent})
    result.index.name = "column"
    return result


# ---------------------------------------------------------------------------
# STEP 6 - Duplicate records
# ---------------------------------------------------------------------------
def find_duplicates(df: pd.DataFrame) -> dict:
    """
    Look for duplicates in three different ways:

    1. Exact duplicates   - the whole row is identical to another row.
    2. Same product_url   - the same book page was scraped twice
                            (the URL is the book's unique ID on the website).
    3. Same title         - two rows share a title. This is NOT always a
                            mistake: a shop can list two different editions
                            with the same name (different price / URL).
    """
    exact_dupes = df[df.duplicated(keep=False)]
    url_dupes = df[df.duplicated(subset="product_url", keep=False)]
    title_dupes = df[df.duplicated(subset="title", keep=False)].sort_values("title")

    return {
        "exact_count": int(df.duplicated().sum()),
        "url_count": int(df.duplicated(subset="product_url").sum()),
        "title_count": int(df.duplicated(subset="title").sum()),
        "exact_rows": exact_dupes,
        "url_rows": url_dupes,
        "title_rows": title_dupes,
    }


# ---------------------------------------------------------------------------
# STEP 7 - Clean the data (into a SEPARATE DataFrame)
# ---------------------------------------------------------------------------
def clean_data(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """
    Create a cleaned COPY of the data. The original DataFrame and the
    original CSV file stay exactly as they were.

    Returns the cleaned DataFrame and a list of the cleaning actions taken.
    """
    steps = []
    cleaned = df.copy()  # .copy() makes sure we never touch the original
    start_rows = len(cleaned)

    # a) Remove extra spaces at the start/end of text values
    text_columns = ["title", "rating_text", "availability", "product_url"]
    for col in text_columns:
        cleaned[col] = cleaned[col].astype(str).str.strip()
    steps.append("Trimmed extra spaces from text columns: " + ", ".join(text_columns) + ".")

    # b) Make sure number columns really are numbers.
    #    errors="coerce" turns anything that is not a number into NaN.
    cleaned[PRICE_COL] = pd.to_numeric(cleaned[PRICE_COL], errors="coerce")
    cleaned[RATING_COL] = pd.to_numeric(cleaned[RATING_COL], errors="coerce")
    steps.append(f"Converted '{PRICE_COL}' and '{RATING_COL}' to numeric types.")

    # c) Drop rows that have no price or no rating (they cannot be analysed)
    before = len(cleaned)
    cleaned = cleaned.dropna(subset=[PRICE_COL, RATING_COL])
    steps.append(f"Removed {before - len(cleaned)} row(s) with a missing price or rating.")

    # d) Remove exact duplicate rows (keep the first one)
    before = len(cleaned)
    cleaned = cleaned.drop_duplicates()
    steps.append(f"Removed {before - len(cleaned)} exact duplicate row(s).")

    # e) Remove rows that point to the same book page (same product_url)
    before = len(cleaned)
    cleaned = cleaned.drop_duplicates(subset="product_url")
    steps.append(f"Removed {before - len(cleaned)} row(s) with a repeated product_url.")

    # f) Rows with the same title but a different URL are kept on purpose:
    #    they are separate listings on the website.
    steps.append("Kept books that share a title but have different URLs (separate listings).")

    # g) Store the rating as a whole number (1-5) and reset the row numbers
    cleaned[RATING_COL] = cleaned[RATING_COL].astype(int)
    cleaned = cleaned.reset_index(drop=True)

    steps.append(f"Rows before cleaning: {start_rows}  ->  rows after cleaning: {len(cleaned)}.")
    return cleaned, steps


# ---------------------------------------------------------------------------
# STEP 8 - Mean, median, mode, minimum, maximum
# ---------------------------------------------------------------------------
def central_tendency(df: pd.DataFrame) -> pd.DataFrame:
    """
    For each numeric column calculate:
      mean   - the average
      median - the middle value when everything is sorted
      mode   - the most common value (there can be more than one)
      min / max, plus range and standard deviation (how spread out values are)
    """
    rows = {}
    for col in [PRICE_COL, RATING_COL]:
        series = df[col]
        modes = series.mode().tolist()  # can return several values (a "tie")
        mode_frequency = int((series == modes[0]).sum())  # how often the mode appears
        rows[col] = {
            "mean": round(series.mean(), 2),
            "median": round(series.median(), 2),
            "mode": ", ".join(str(m) for m in modes),
            "mode_frequency": mode_frequency,
            "min": series.min(),
            "max": series.max(),
            "range": round(series.max() - series.min(), 2),
            "std_dev": round(series.std(), 2),
        }
    return pd.DataFrame(rows).T  # .T flips it so each column is one row


# ---------------------------------------------------------------------------
# STEP 9 - Statistical summary (describe)
# ---------------------------------------------------------------------------
def statistical_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    pandas' describe() gives count, mean, std, min, 25%, 50%, 75% and max.
    We add skewness:
      ~0        -> values are spread evenly / symmetric
      positive  -> a long tail of high values
      negative  -> a long tail of low values
    """
    summary = df[[PRICE_COL, RATING_COL]].describe().T
    summary["skewness"] = df[[PRICE_COL, RATING_COL]].skew()
    return summary.round(2)


# ---------------------------------------------------------------------------
# STEP 10 - Price analysis
# ---------------------------------------------------------------------------
def price_analysis(df: pd.DataFrame) -> dict:
    """Look at how book prices are spread out."""
    prices = df[PRICE_COL]

    # Group prices into GBP 10 "bands" so we can count books in each band
    bins = [10, 20, 30, 40, 50, 60]
    labels = ["GBP 10-20", "GBP 20-30", "GBP 30-40", "GBP 40-50", "GBP 50-60"]
    bands = pd.cut(prices, bins=bins, labels=labels, include_lowest=True)
    band_counts = bands.value_counts().reindex(labels)
    band_table = pd.DataFrame(
        {"books": band_counts, "percent": (band_counts / len(df) * 100).round(1)}
    )
    band_table.index.name = "price_band"

    # Interquartile range (IQR) method to look for unusual prices (outliers)
    q1, q3 = prices.quantile(0.25), prices.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers = df[(prices < lower) | (prices > upper)]

    return {
        "q1": round(q1, 2),
        "q3": round(q3, 2),
        "iqr": round(iqr, 2),
        "lower_fence": round(lower, 2),
        "upper_fence": round(upper, 2),
        "outlier_count": len(outliers),
        "band_table": band_table,
        "total_value": round(prices.sum(), 2),
        "under_20": int((prices < 20).sum()),
        "over_50": int((prices > 50).sum()),
    }


# ---------------------------------------------------------------------------
# STEP 11 - Rating analysis and rating distribution
# ---------------------------------------------------------------------------
def rating_analysis(df: pd.DataFrame) -> dict:
    """Count books per star rating and see how price relates to rating."""
    counts = df[RATING_COL].value_counts().sort_index()
    distribution = pd.DataFrame(
        {
            "books": counts,
            "percent": (counts / len(df) * 100).round(1),
            "avg_price_gbp": df.groupby(RATING_COL)[PRICE_COL].mean().round(2),
            "median_price_gbp": df.groupby(RATING_COL)[PRICE_COL].median().round(2),
        }
    )
    distribution.index.name = "stars"

    high_rated = int((df[RATING_COL] >= 4).sum())
    low_rated = int((df[RATING_COL] <= 2).sum())

    # Check that the number rating and the word rating always agree
    word_to_number = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
    mismatches = int((df["rating_text"].map(word_to_number) != df[RATING_COL]).sum())

    return {
        "distribution": distribution,
        "most_common_rating": int(counts.idxmax()),
        "least_common_rating": int(counts.idxmin()),
        "high_rated": high_rated,
        "low_rated": low_rated,
        "text_number_mismatches": mismatches,
    }


# ---------------------------------------------------------------------------
# STEP 12 - Most expensive and cheapest books
# ---------------------------------------------------------------------------
def price_extremes(df: pd.DataFrame, n: int = 5) -> dict:
    """Return the n most expensive and n cheapest books."""
    cols = ["title", PRICE_COL, RATING_COL]
    most_expensive = df.nlargest(n, PRICE_COL)[cols].reset_index(drop=True)
    cheapest = df.nsmallest(n, PRICE_COL)[cols].reset_index(drop=True)
    # Start numbering at 1 instead of 0 - easier to read
    most_expensive.index += 1
    cheapest.index += 1
    return {"most_expensive": most_expensive, "cheapest": cheapest}


# ---------------------------------------------------------------------------
# STEP 13 - Correlation and stock
# ---------------------------------------------------------------------------
def correlation_and_stock(df: pd.DataFrame) -> dict:
    """
    Correlation tells us if two numbers move together:
      +1 -> when one goes up the other goes up
       0 -> no relationship
      -1 -> when one goes up the other goes down
    """
    corr_matrix = df[[PRICE_COL, RATING_COL, "page_number"]].corr().round(3)
    price_rating_corr = round(df[PRICE_COL].corr(df[RATING_COL]), 3)

    stock_counts = df["availability"].value_counts()
    in_stock_percent = round(df["in_stock"].mean() * 100, 1)

    return {
        "corr_matrix": corr_matrix,
        "price_rating_corr": price_rating_corr,
        "stock_counts": stock_counts,
        "in_stock_percent": in_stock_percent,
        "pages_scraped": int(df["page_number"].nunique()),
    }


# ---------------------------------------------------------------------------
# STEP 14 - Meaningful insights (written automatically from the numbers)
# ---------------------------------------------------------------------------
def describe_correlation(value: float) -> str:
    """Turn a correlation number into plain English."""
    size = abs(value)
    if size < 0.1:
        strength = "no meaningful"
    elif size < 0.3:
        strength = "a weak"
    elif size < 0.5:
        strength = "a moderate"
    else:
        strength = "a strong"
    direction = "positive" if value > 0 else "negative"
    return f"{strength} {direction}" if strength != "no meaningful" else "no meaningful"


def generate_insights(df, ct, price, rating, extremes, corr) -> list[str]:
    """
    Build a list of insights. Every number here is calculated from the data,
    nothing is typed in by hand - so the insights stay correct even if the
    dataset changes.
    """
    insights = []
    mean_p = df[PRICE_COL].mean()
    median_p = df[PRICE_COL].median()
    skew_p = df[PRICE_COL].skew()

    # Price level
    insights.append(
        f"The average book costs GBP {mean_p:.2f} and the median is GBP {median_p:.2f}. "
        f"Prices range from GBP {df[PRICE_COL].min():.2f} to GBP {df[PRICE_COL].max():.2f}."
    )

    # Price shape
    shape = "almost symmetric" if abs(skew_p) < 0.2 else ("right-skewed" if skew_p > 0 else "left-skewed")
    insights.append(
        f"Prices are spread fairly evenly (skewness {skew_p:.2f}, {shape}): "
        f"there is no single 'typical' price point - the store has books at every level between GBP 10 and GBP 60."
    )

    # Price bands
    bands = price["band_table"]
    top_band = bands["books"].idxmax()
    insights.append(
        f"The most common price band is {top_band} with {int(bands.loc[top_band, 'books'])} books "
        f"({bands.loc[top_band, 'percent']}%), but every GBP 10 band holds between "
        f"{bands['percent'].min()}% and {bands['percent'].max()}% of books. "
        f"{price['under_20']} books cost under GBP 20 and {price['over_50']} cost over GBP 50."
    )

    # Mode
    insights.append(
        f"Almost every price is unique ({df[PRICE_COL].nunique()} different prices for {len(df)} books). "
        f"The 'mode' price ({ct.loc[PRICE_COL, 'mode']}) appears only {ct.loc[PRICE_COL, 'mode_frequency']} "
        "times, so the mode is not a useful summary for price - the mean and median are better."
    )

    # Outliers
    if price["outlier_count"] == 0:
        insights.append(
            "No price outliers were found using the IQR method, which suggests the scraped prices are clean and realistic."
        )
    else:
        insights.append(f"{price['outlier_count']} price outlier(s) were found using the IQR method.")

    # Ratings
    dist = rating["distribution"]
    insights.append(
        f"{rating['most_common_rating']}-star is the most common rating "
        f"({int(dist.loc[rating['most_common_rating'], 'books'])} books) and "
        f"{rating['least_common_rating']}-star is the least common "
        f"({int(dist.loc[rating['least_common_rating'], 'books'])} books). "
        f"The average rating is {df[RATING_COL].mean():.2f} stars."
    )
    insights.append(
        f"{rating['high_rated']} books ({rating['high_rated'] / len(df) * 100:.1f}%) are rated 4 stars or more, "
        f"while {rating['low_rated']} books ({rating['low_rated'] / len(df) * 100:.1f}%) are rated 2 stars or less. "
        "Ratings are spread quite evenly across all five levels."
    )

    # Price vs rating
    insights.append(
        f"The correlation between price and rating is {corr['price_rating_corr']}, meaning "
        f"{describe_correlation(corr['price_rating_corr'])} relationship: a more expensive book is NOT "
        "more likely to be rated higher."
    )
    best_value_rating = dist["avg_price_gbp"].idxmin()
    priciest_rating = dist["avg_price_gbp"].idxmax()
    insights.append(
        f"{priciest_rating}-star books have the highest average price (GBP {dist.loc[priciest_rating, 'avg_price_gbp']:.2f}) "
        f"and {best_value_rating}-star books the lowest (GBP {dist.loc[best_value_rating, 'avg_price_gbp']:.2f}) - "
        "a small gap compared to the overall price range."
    )

    # Best value
    five_star = df[df[RATING_COL] == 5]
    if not five_star.empty:
        best = five_star.nsmallest(1, PRICE_COL).iloc[0]
        insights.append(
            f"Best value pick: '{best['title']}' is rated 5 stars and costs only GBP {best[PRICE_COL]:.2f}."
        )

    # Extremes
    top = extremes["most_expensive"].iloc[0]
    low = extremes["cheapest"].iloc[0]
    insights.append(
        f"The most expensive book is '{top['title']}' (GBP {top[PRICE_COL]:.2f}, {top[RATING_COL]} stars); "
        f"the cheapest is '{low['title']}' (GBP {low[PRICE_COL]:.2f}, {low[RATING_COL]} stars)."
    )

    # Stock / data quality
    insights.append(
        f"{corr['in_stock_percent']}% of books are in stock, across {corr['pages_scraped']} catalogue pages scraped."
    )
    return insights
