"""
visualization.py
----------------
Creates the charts for the Book Dataset EDA and saves them as PNG images
inside output/charts/.

We use the "Agg" backend so the charts are saved straight to files without
opening any windows - this works the same in VS Code, a terminal or a server.
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # save to files, do not open pop-up windows
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

PRICE_COL = "price_gbp"
RATING_COL = "rating_stars"

# One consistent, clean style for every chart
sns.set_theme(style="whitegrid", palette="crest")


def _save(fig, charts_dir: Path, filename: str) -> Path:
    """Helper: tidy the layout, save the figure and close it to free memory."""
    path = charts_dir / filename
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def price_histogram(df: pd.DataFrame, charts_dir: Path) -> Path:
    """Histogram: how many books fall into each price range."""
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.histplot(df[PRICE_COL], bins=25, kde=True, color="#2a7f62", ax=ax)
    # Dashed lines show where the mean and median are
    ax.axvline(df[PRICE_COL].mean(), color="#c0392b", linestyle="--",
               label=f"Mean: GBP {df[PRICE_COL].mean():.2f}")
    ax.axvline(df[PRICE_COL].median(), color="#2c3e50", linestyle=":",
               label=f"Median: GBP {df[PRICE_COL].median():.2f}")
    ax.set_title("Price Distribution of Books", fontsize=15, weight="bold")
    ax.set_xlabel("Price (GBP)")
    ax.set_ylabel("Number of books")
    ax.legend()
    return _save(fig, charts_dir, "01_price_distribution_histogram.png")


def rating_bar_chart(df: pd.DataFrame, charts_dir: Path) -> Path:
    """Bar chart: number of books for each star rating."""
    counts = df[RATING_COL].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(9, 6))
    bars = ax.bar([f"{s} star" for s in counts.index], counts.values,
                  color=sns.color_palette("crest", len(counts)))
    # Write the exact count on top of each bar
    ax.bar_label(bars, labels=[f"{v} ({v / len(df) * 100:.1f}%)" for v in counts.values], padding=3)
    ax.set_title("Distribution of Book Ratings", fontsize=15, weight="bold")
    ax.set_xlabel("Rating")
    ax.set_ylabel("Number of books")
    ax.set_ylim(0, counts.max() * 1.15)
    return _save(fig, charts_dir, "02_rating_distribution_bar_chart.png")


def price_box_plot(df: pd.DataFrame, charts_dir: Path) -> Path:
    """Box plot: overall price spread, and price spread for each rating."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 6), gridspec_kw={"width_ratios": [1, 2.5]})

    # Left: all books together
    sns.boxplot(y=df[PRICE_COL], color="#8fd1b5", ax=axes[0])
    axes[0].set_title("All Books", weight="bold")
    axes[0].set_ylabel("Price (GBP)")

    # Right: one box per star rating
    sns.boxplot(data=df, x=RATING_COL, y=PRICE_COL, hue=RATING_COL,
                palette="crest", legend=False, ax=axes[1])
    axes[1].set_title("Price by Star Rating", weight="bold")
    axes[1].set_xlabel("Rating (stars)")
    axes[1].set_ylabel("Price (GBP)")

    fig.suptitle("Book Price Box Plots", fontsize=15, weight="bold")
    return _save(fig, charts_dir, "03_price_box_plot.png")


def correlation_heatmap(df: pd.DataFrame, charts_dir: Path) -> Path:
    """Heatmap: correlation between the numeric columns."""
    corr = df[[PRICE_COL, RATING_COL, "page_number"]].corr()
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(corr, annot=True, fmt=".3f", cmap="vlag", vmin=-1, vmax=1,
                square=True, linewidths=0.5, ax=ax)
    ax.set_title("Correlation Heatmap", fontsize=15, weight="bold")
    return _save(fig, charts_dir, "04_correlation_heatmap.png")


def average_price_by_rating(df: pd.DataFrame, charts_dir: Path) -> Path:
    """Bar chart: average price for each star rating."""
    avg = df.groupby(RATING_COL)[PRICE_COL].mean()
    fig, ax = plt.subplots(figsize=(9, 6))
    bars = ax.bar([f"{s} star" for s in avg.index], avg.values,
                  color=sns.color_palette("flare", len(avg)))
    # Write the value inside each bar so it does not clash with the dashed line
    ax.bar_label(bars, labels=[f"GBP {v:.2f}" for v in avg.values],
                 label_type="center", color="white", weight="bold")
    ax.axhline(df[PRICE_COL].mean(), color="#2c3e50", linestyle="--",
               label=f"Overall average: GBP {df[PRICE_COL].mean():.2f}")
    ax.set_title("Average Price by Rating", fontsize=15, weight="bold")
    ax.set_xlabel("Rating")
    ax.set_ylabel("Average price (GBP)")
    ax.set_ylim(0, avg.max() * 1.3)
    ax.legend(loc="upper left")
    return _save(fig, charts_dir, "05_average_price_by_rating.png")


def create_all_charts(df: pd.DataFrame, charts_dir: Path) -> list[Path]:
    """Create every chart and return the list of saved file paths."""
    charts_dir.mkdir(parents=True, exist_ok=True)
    return [
        price_histogram(df, charts_dir),
        rating_bar_chart(df, charts_dir),
        price_box_plot(df, charts_dir),
        correlation_heatmap(df, charts_dir),
        average_price_by_rating(df, charts_dir),
    ]
