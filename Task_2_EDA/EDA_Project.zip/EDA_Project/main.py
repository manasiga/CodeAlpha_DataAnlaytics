"""
main.py
-------
Exploratory Data Analysis of Book Dataset

Run this file to perform the full analysis:

    python main.py

What it does, in order:
  1.  Loads data/books_data.csv (the original file is only read, never changed)
  2.  Shows the first 10 and last 10 records
  3.  Shows the number of rows and columns
  4.  Shows column names and data types
  5.  Checks for missing values
  6.  Finds duplicate records
  7.  Creates a separate cleaned dataset
  8.  Calculates mean, median, mode, minimum and maximum
  9.  Builds a statistical summary
  10. Analyses book prices
  11. Analyses book ratings and their distribution
  12. Finds the most expensive and cheapest books
  13. Checks correlation and stock levels
  14. Writes meaningful insights
  15. Creates charts
  16. Saves the cleaned CSV, summary statistics and the EDA report

Every section is printed on screen AND written into output/eda_report.txt.
"""

import hashlib
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

import eda_analysis as eda
import visualization as viz

# ---------------------------------------------------------------------------
# File locations
# Path(__file__).parent = the folder this script is in, so the project works
# no matter which folder you run it from.
# ---------------------------------------------------------------------------
PROJECT_DIR = Path(__file__).resolve().parent
DATA_FILE = PROJECT_DIR / "data" / "books_data.csv"
OUTPUT_DIR = PROJECT_DIR / "output"
CHARTS_DIR = OUTPUT_DIR / "charts"
CLEANED_FILE = OUTPUT_DIR / "cleaned_data.csv"
SUMMARY_FILE = OUTPUT_DIR / "summary_statistics.csv"
REPORT_FILE = OUTPUT_DIR / "eda_report.txt"

# Make wide tables print on one line instead of wrapping
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 20)
pd.set_option("display.max_colwidth", 60)


class Report:
    """
    Collects text for the EDA report.
    Everything we add is printed to the screen and saved for the report file.
    """

    def __init__(self):
        self.lines = []

    def add(self, text: str = "") -> None:
        print(text)
        self.lines.append(text)

    def section(self, number: int, title: str, explanation: str) -> None:
        """Print a big heading plus a short 'what & why' explanation."""
        self.add()
        self.add("=" * 90)
        self.add(f"STEP {number}: {title.upper()}")
        self.add("=" * 90)
        self.add(f"What & why: {explanation}")
        self.add("-" * 90)

    def table(self, df) -> None:
        self.add(df.to_string())

    def save(self, path: Path) -> None:
        path.write_text("\n".join(self.lines), encoding="utf-8")


def file_fingerprint(path: Path) -> str:
    """Return an MD5 'fingerprint' of a file. If the file changes, so does this."""
    return hashlib.md5(path.read_bytes()).hexdigest()


def main() -> None:
    # Avoid crashes when printing special characters on some Windows terminals
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)

    report = Report()
    report.add("#" * 90)
    report.add("EXPLORATORY DATA ANALYSIS OF BOOK DATASET".center(90))
    report.add("#" * 90)
    report.add(f"Generated on : {datetime.now():%Y-%m-%d %H:%M:%S}")
    report.add(f"Source file  : data/{DATA_FILE.name}")
    report.add("Data source  : books.toscrape.com (from the earlier web scraping project)")

    # Remember the original file's fingerprint so we can prove it was not changed
    original_fingerprint = file_fingerprint(DATA_FILE) if DATA_FILE.exists() else None

    # ---------------- STEP 1: Load ----------------
    report.section(1, "Load the dataset",
                   "Read the scraped CSV into a pandas DataFrame so we can analyse it. "
                   "The original file is opened read-only.")
    df = eda.load_data(DATA_FILE)
    report.add(f"Loaded {len(df)} records from {DATA_FILE.name}.")

    # ---------------- STEP 2: Head & tail ----------------
    report.section(2, "First 10 and last 10 records",
                   "A quick look at real rows confirms the data loaded correctly and shows "
                   "what each column contains. (product_url is hidden to keep the table narrow.)")
    head, tail = eda.first_and_last_records(df, n=10)
    report.add("First 10 records:")
    report.table(head)
    report.add()
    report.add("Last 10 records:")
    report.table(tail)

    # ---------------- STEP 3: Shape ----------------
    report.section(3, "Total rows and columns",
                   "The size of the dataset tells us how much data we are working with.")
    rows, cols = eda.dataset_shape(df)
    report.add(f"Total rows (books) : {rows}")
    report.add(f"Total columns      : {cols}")

    # ---------------- STEP 4: Columns & types ----------------
    report.section(4, "Column names and data types",
                   "Data types tell us which columns are numbers (can be averaged) and which are text. "
                   "'unique_values' shows how many different values each column has.")
    report.table(eda.column_info(df))

    # ---------------- STEP 5: Missing values ----------------
    report.section(5, "Missing values",
                   "Empty cells can break calculations or bias results, so we count them per column.")
    missing = eda.missing_values(df)
    report.table(missing)
    total_missing = int(missing["missing_count"].sum())
    report.add()
    report.add(f"Total missing cells: {total_missing}"
               + ("  -> The dataset is complete, no values are missing." if total_missing == 0 else ""))

    # ---------------- STEP 6: Duplicates ----------------
    report.section(6, "Duplicate records",
                   "Duplicates would count the same book twice and distort averages. "
                   "We check exact copies, repeated URLs (same book page) and repeated titles.")
    dupes = eda.find_duplicates(df)
    report.add(f"Exact duplicate rows        : {dupes['exact_count']}")
    report.add(f"Repeated product URLs       : {dupes['url_count']}")
    report.add(f"Repeated titles             : {dupes['title_count']}")
    if dupes["title_count"] > 0:
        report.add()
        report.add("Books sharing the same title:")
        report.table(dupes["title_rows"][["title", "price_gbp", "rating_stars", "page_number", "product_url"]])
        report.add("Note: these rows have different prices and URLs, so they are separate listings "
                   "on the website (not scraping mistakes). They are kept in the cleaned data.")

    # ---------------- STEP 7: Clean ----------------
    report.section(7, "Create a separate cleaned dataset",
                   "We clean a COPY of the data. The original CSV is left untouched, and all "
                   "following steps use the cleaned copy.")
    cleaned, cleaning_steps = eda.clean_data(df)
    for i, step in enumerate(cleaning_steps, start=1):
        report.add(f"  {i}. {step}")

    # ---------------- STEP 8: Central tendency ----------------
    report.section(8, "Mean, median, mode, minimum and maximum",
                   "Mean = average, median = middle value, mode = most frequent value "
                   "(mode_frequency = how many times it appears; several modes means a tie). "
                   "Min/max show the extremes; standard deviation shows how spread out the values are.")
    ct = eda.central_tendency(cleaned)
    report.table(ct)

    # ---------------- STEP 9: Summary ----------------
    report.section(9, "Statistical summary",
                   "describe() adds quartiles: 25% of books are below the '25%' value, half are below "
                   "the '50%' value (median), and 75% are below the '75%' value. "
                   "Skewness near 0 means the values are balanced around the middle.")
    summary = eda.statistical_summary(cleaned)
    report.table(summary)

    # ---------------- STEP 10: Prices ----------------
    report.section(10, "Price analysis",
                   "We group prices into GBP 10 bands and use the IQR (interquartile range) rule "
                   "to look for unusually low or high prices (outliers).")
    price = eda.price_analysis(cleaned)
    report.add("Books per price band:")
    report.table(price["band_table"])
    report.add()
    report.add(f"Lower quartile (Q1)          : GBP {price['q1']}")
    report.add(f"Upper quartile (Q3)          : GBP {price['q3']}")
    report.add(f"Interquartile range (IQR)    : GBP {price['iqr']}")
    report.add(f"Outlier limits (IQR rule)    : below GBP {price['lower_fence']} or above GBP {price['upper_fence']}")
    report.add(f"Number of price outliers     : {price['outlier_count']}")
    report.add(f"Books under GBP 20           : {price['under_20']}")
    report.add(f"Books over GBP 50            : {price['over_50']}")
    report.add(f"Total value of all books     : GBP {price['total_value']:,.2f}")

    # ---------------- STEP 11: Ratings ----------------
    report.section(11, "Rating analysis and rating distribution",
                   "We count how many books have each star rating, their share of the total, "
                   "and the average/median price for each rating.")
    rating = eda.rating_analysis(cleaned)
    report.table(rating["distribution"])
    report.add()
    report.add(f"Most common rating            : {rating['most_common_rating']} stars")
    report.add(f"Least common rating           : {rating['least_common_rating']} stars")
    report.add(f"Books rated 4-5 stars         : {rating['high_rated']}")
    report.add(f"Books rated 1-2 stars         : {rating['low_rated']}")
    report.add(f"rating_text vs rating_stars mismatches: {rating['text_number_mismatches']}"
               + ("  (both rating columns agree)" if rating["text_number_mismatches"] == 0 else ""))

    # ---------------- STEP 12: Extremes ----------------
    report.section(12, "Most expensive and cheapest books",
                   "Sorting by price shows the top and bottom of the price range.")
    extremes = eda.price_extremes(cleaned, n=5)
    report.add("Top 5 most expensive books:")
    report.table(extremes["most_expensive"])
    report.add()
    report.add("Top 5 cheapest books:")
    report.table(extremes["cheapest"])

    # ---------------- STEP 13: Correlation & stock ----------------
    report.section(13, "Correlation and stock availability",
                   "Correlation (-1 to +1) shows whether two numbers rise and fall together. "
                   "We also check how many books are in stock.")
    corr = eda.correlation_and_stock(cleaned)
    report.add("Correlation matrix:")
    report.table(corr["corr_matrix"])
    report.add()
    report.add(f"Price vs rating correlation: {corr['price_rating_corr']} "
               f"({eda.describe_correlation(corr['price_rating_corr'])} relationship)")
    report.add()
    report.add("Availability:")
    report.table(corr["stock_counts"].to_frame("books"))
    report.add(f"In stock: {corr['in_stock_percent']}%")

    # ---------------- STEP 14: Charts ----------------
    report.section(14, "Visualizations",
                   "Charts make patterns easy to see at a glance. They are saved in output/charts/.")
    chart_paths = viz.create_all_charts(cleaned, CHARTS_DIR)
    for path in chart_paths:
        report.add(f"  Saved: output/charts/{path.name}")

    # ---------------- STEP 15: Insights ----------------
    report.section(15, "Key insights",
                   "Plain-English findings, calculated directly from the data.")
    insights = eda.generate_insights(cleaned, ct, price, rating, extremes, corr)
    for i, text in enumerate(insights, start=1):
        report.add(f"  {i:>2}. {text}")

    # ---------------- STEP 16: Save outputs ----------------
    report.section(16, "Save outputs",
                   "Save the cleaned dataset and summary statistics, and confirm the original file is unchanged.")

    # Cleaned CSV. utf-8-sig lets Excel show special characters correctly.
    cleaned.to_csv(CLEANED_FILE, index=False, encoding="utf-8-sig")
    report.add(f"  Cleaned dataset     : output/{CLEANED_FILE.name} ({len(cleaned)} rows, {cleaned.shape[1]} columns)")

    # Summary statistics CSV: describe() + mode + range, one row per numeric column
    summary_out = summary.copy()
    summary_out["mode"] = ct["mode"]
    summary_out["mode_frequency"] = ct["mode_frequency"]
    summary_out["range"] = ct["range"]
    summary_out.index.name = "column"
    summary_out.to_csv(SUMMARY_FILE, encoding="utf-8-sig")
    report.add(f"  Summary statistics  : output/{SUMMARY_FILE.name}")

    # Prove the original CSV was not modified
    if original_fingerprint == file_fingerprint(DATA_FILE):
        report.add("  Original dataset    : unchanged (file fingerprint matches)")
    else:
        report.add("  WARNING: the original dataset fingerprint changed!")

    report.add(f"  EDA report          : output/{REPORT_FILE.name}")
    report.add()
    report.add("Analysis complete.")
    report.save(REPORT_FILE)


if __name__ == "__main__":
    main()
